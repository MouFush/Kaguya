# 辉夜AI平台 (Kaguya AI Platform)

企业级AI对话平台 - 现代化重构版本

## 架构概览

```
┌─────────────────────────────────────────────────────────────┐
│                        前端层 (Frontend)                      │
│  React 18 + TypeScript + Vite + Ant Design + Zustand         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      API网关层 (Gateway)                      │
│  Kong / Nginx + Rate Limiting + Auth + Load Balancing       │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      微服务层 (Services)                      │
├─────────────┬─────────────┬─────────────┬───────────────────┤
│ 用户服务     │ 对话服务     │ 模型服务     │ 文件服务          │
│  User Svc   │  Chat Svc   │  Model Svc  │  File Svc         │
├─────────────┼─────────────┼─────────────┼───────────────────┤
│ 认证授权     │ 消息管理     │ LLM路由      │ 文件上传/解析     │
│ 用户管理     │ 历史记录     │ 模型管理     │ 向量存储          │
│ 权限控制     │ 收藏标签     │ 微调训练     │ RAG检索           │
└─────────────┴─────────────┴─────────────┴───────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      数据层 (Data Layer)                      │
├─────────────┬─────────────┬─────────────┬───────────────────┤
│ PostgreSQL  │    Redis    │   Milvus    │     MinIO         │
│  关系数据    │    缓存     │  向量数据库  │    对象存储        │
└─────────────┴─────────────┴─────────────┴───────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      AI层 (AI Layer)                          │
├─────────────┬─────────────┬─────────────┬───────────────────┤
│  LiteLLM    │    vLLM     │  LangChain  │  Transformers     │
│  模型网关    │  推理加速   │  工作流引擎  │   嵌入模型        │
└─────────────┴─────────────┴─────────────┴───────────────────┘
```

## 技术栈

### 前端
- **框架**: React 18 + TypeScript
- **构建**: Vite
- **UI库**: Ant Design 5.x
- **状态管理**: Zustand
- **路由**: React Router 6
- **HTTP客户端**: Axios + React Query
- **样式**: Tailwind CSS + CSS Modules

### 后端
- **框架**: FastAPI + Python 3.11
- **异步**: AsyncIO + Uvicorn
- **ORM**: SQLAlchemy 2.0 + Alembic
- **缓存**: Redis + aioredis
- **消息队列**: Celery + RabbitMQ
- **认证**: JWT + OAuth2

### 基础设施
- **容器化**: Docker + Docker Compose
- **编排**: Kubernetes (生产环境)
- **监控**: Prometheus + Grafana
- **日志**: ELK Stack
- **CI/CD**: GitHub Actions

## 快速开始

### 环境要求
- Node.js 18+
- Python 3.11+
- Docker & Docker Compose
- PostgreSQL 15+
- Redis 7+

### 本地开发

```bash
# 1. 克隆项目
git clone https://github.com/your-org/kaguya-ai-platform.git
cd kaguya-ai-platform

# 2. 启动基础设施
docker-compose -f infra/docker-compose.dev.yml up -d

# 3. 安装后端依赖
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 4. 运行数据库迁移
alembic upgrade head

# 5. 启动后端服务
python run.py

# 6. 安装前端依赖 (新终端)
cd frontend
npm install

# 7. 启动前端开发服务器
npm run dev
```

访问 http://localhost:5173

## 项目结构

```
kaguya-ai-platform/
├── frontend/          # React前端应用
├── backend/           # FastAPI后端服务
├── services/          # 微服务模块
│   ├── user-service/
│   ├── chat-service/
│   ├── model-service/
│   └── file-service/
├── infra/             # 基础设施配置
│   ├── docker/
│   ├── k8s/
│   └── terraform/
├── docs/              # 文档
└── scripts/           # 脚本工具
```

## 功能特性

- [x] 多角色对话系统
- [x] 消息编辑/删除/收藏
- [x] 对话标签分类
- [x] 多模型支持 (OpenAI/DeepSeek/本地)
- [x] RAG知识库
- [x] Agent工作流
- [ ] 多模态支持 (图像/语音)
- [ ] 主题市场
- [ ] 插件系统

## 许可证

MIT License
