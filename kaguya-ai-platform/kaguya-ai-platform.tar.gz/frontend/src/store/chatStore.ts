import { create } from 'zustand'

interface Message {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  reasoning?: string
  created_at: string
}

interface Chat {
  id: string
  title: string
  role_id?: string
  tags: string[]
  is_starred: boolean
  model: string
  temperature: number
  max_tokens: number
  created_at: string
  updated_at: string
}

interface ChatState {
  chats: Chat[]
  currentChat: Chat | null
  messages: Message[]
  isLoading: boolean
  streamingMessage: string
  
  // Actions
  setChats: (chats: Chat[]) => void
  setCurrentChat: (chat: Chat | null) => void
  setMessages: (messages: Message[]) => void
  addMessage: (message: Message) => void
  updateMessage: (id: string, content: string) => void
  setIsLoading: (loading: boolean) => void
  setStreamingMessage: (message: string) => void
  appendStreamingMessage: (chunk: string) => void
}

export const useChatStore = create<ChatState>((set) => ({
  chats: [],
  currentChat: null,
  messages: [],
  isLoading: false,
  streamingMessage: '',
  
  setChats: (chats) => set({ chats }),
  setCurrentChat: (chat) => set({ currentChat: chat }),
  setMessages: (messages) => set({ messages }),
  addMessage: (message) => set((state) => ({ 
    messages: [...state.messages, message] 
  })),
  updateMessage: (id, content) => set((state) => ({
    messages: state.messages.map(m => 
      m.id === id ? { ...m, content } : m
    )
  })),
  setIsLoading: (loading) => set({ isLoading: loading }),
  setStreamingMessage: (message) => set({ streamingMessage: message }),
  appendStreamingMessage: (chunk) => set((state) => ({ 
    streamingMessage: state.streamingMessage + chunk 
  })),
}))
