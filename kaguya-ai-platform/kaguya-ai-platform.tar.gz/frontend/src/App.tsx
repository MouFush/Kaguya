import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Layout } from 'antd'
import ChatPage from './pages/Chat'
import SettingsPage from './pages/Settings'
import KnowledgeBasePage from './pages/KnowledgeBase'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import './App.css'

const { Content } = Layout

function App() {
  return (
    <Router>
      <Layout className="app-layout">
        <Sidebar />
        <Layout className="main-layout">
          <Header />
          <Content className="main-content">
            <Routes>
              <Route path="/" element={<ChatPage />} />
              <Route path="/chat/:chatId" element={<ChatPage />} />
              <Route path="/settings" element={<SettingsPage />} />
              <Route path="/knowledge-base" element={<KnowledgeBasePage />} />
            </Routes>
          </Content>
        </Layout>
      </Layout>
    </Router>
  )
}

export default App
