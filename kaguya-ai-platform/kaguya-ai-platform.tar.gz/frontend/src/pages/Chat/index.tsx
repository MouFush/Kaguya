import { useEffect, useState, useRef } from 'react'
import { useParams } from 'react-router-dom'
import { Layout, Input, Button, List, Avatar, Spin, Tag, Space } from 'antd'
import { SendOutlined, StarOutlined, StarFilled, DeleteOutlined, TagOutlined } from '@ant-design/icons'
import { useChatStore } from '@/store/chatStore'
import { chatApi, Message } from '@/api/chat'
import ReactMarkdown from 'react-markdown'
import './index.css'

const { Content, Sider } = Layout
const { TextArea } = Input

export default function ChatPage() {
  const { chatId } = useParams<{ chatId: string }>()
  const [inputValue, setInputValue] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)
  
  const {
    currentChat,
    messages,
    isLoading,
    streamingMessage,
    setCurrentChat,
    setMessages,
    addMessage,
    setIsLoading,
    setStreamingMessage,
    appendStreamingMessage,
  } = useChatStore()

  // 加载对话和消息
  useEffect(() => {
    if (chatId) {
      loadChat(chatId)
    }
  }, [chatId])

  // 滚动到底部
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, streamingMessage])

  const loadChat = async (id: string) => {
    try {
      const chat = await chatApi.getChat(id)
      setCurrentChat(chat)
      
      const msgs = await chatApi.getMessages(id)
      setMessages(msgs)
    } catch (error) {
      console.error('加载对话失败:', error)
    }
  }

  const handleSend = async () => {
    if (!inputValue.trim() || !chatId || isLoading) return

    const content = inputValue.trim()
    setInputValue('')
    setIsLoading(true)
    setStreamingMessage('')

    // 添加用户消息到列表
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      created_at: new Date().toISOString(),
    }
    addMessage(userMessage)

    try {
      // 流式发送消息
      await chatApi.sendMessageStream(chatId, content, (chunk) => {
        appendStreamingMessage(chunk)
      })

      // 重新加载消息列表
      const msgs = await chatApi.getMessages(chatId)
      setMessages(msgs)
      setStreamingMessage('')
    } catch (error) {
      console.error('发送消息失败:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const toggleStar = async () => {
    if (!currentChat) return
    try {
      await chatApi.updateChat(currentChat.id, {
        is_starred: !currentChat.is_starred,
      })
      setCurrentChat({
        ...currentChat,
        is_starred: !currentChat.is_starred,
      })
    } catch (error) {
      console.error('更新失败:', error)
    }
  }

  return (
    <Layout className="chat-page">
      <Content className="chat-content">
        {/* 消息列表 */}
        <div className="messages-container">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`message-item ${msg.role}`}
            >
              <Avatar
                className="message-avatar"
                style={{
                  backgroundColor: msg.role === 'user' ? '#1890ff' : '#52c41a',
                }}
              >
                {msg.role === 'user' ? '我' : 'AI'}
              </Avatar>
              <div className="message-content">
                <div className="message-header">
                  <span className="message-role">
                    {msg.role === 'user' ? '我' : 'AI助手'}
                  </span>
                  <span className="message-time">
                    {new Date(msg.created_at).toLocaleTimeString()}
                  </span>
                </div>
                <div className="message-body">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>
              </div>
            </div>
          ))}
          
          {/* 流式消息 */}
          {streamingMessage && (
            <div className="message-item assistant">
              <Avatar className="message-avatar" style={{ backgroundColor: '#52c41a' }}>
                AI
              </Avatar>
              <div className="message-content">
                <div className="message-header">
                  <span className="message-role">AI助手</span>
                  <Spin size="small" />
                </div>
                <div className="message-body">
                  <ReactMarkdown>{streamingMessage}</ReactMarkdown>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* 输入区域 */}
        <div className="input-container">
          <TextArea
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="输入消息... (Enter发送, Shift+Enter换行)"
            autoSize={{ minRows: 2, maxRows: 6 }}
            disabled={isLoading}
          />
          <Button
            type="primary"
            icon={<SendOutlined />}
            onClick={handleSend}
            loading={isLoading}
            disabled={!inputValue.trim()}
          >
            发送
          </Button>
        </div>
      </Content>

      {/* 右侧信息栏 */}
      {currentChat && (
        <Sider width={300} className="chat-sider">
          <div className="sider-content">
            <h3>{currentChat.title}</h3>
            
            <Space direction="vertical" style={{ width: '100%' }}>
              <Button
                icon={currentChat.is_starred ? <StarFilled /> : <StarOutlined />}
                onClick={toggleStar}
                block
              >
                {currentChat.is_starred ? '已收藏' : '收藏'}
              </Button>
              
              <div className="info-item">
                <span className="label">模型:</span>
                <Tag>{currentChat.model}</Tag>
              </div>
              
              <div className="info-item">
                <span className="label">温度:</span>
                <span>{currentChat.temperature}</span>
              </div>
              
              <div className="info-item">
                <span className="label">Max Tokens:</span>
                <span>{currentChat.max_tokens}</span>
              </div>
              
              {currentChat.tags && currentChat.tags.length > 0 && (
                <div className="info-item">
                  <span className="label">标签:</span>
                  <Space wrap>
                    {currentChat.tags.map((tag) => (
                      <Tag key={tag} icon={<TagOutlined />}>
                        {tag}
                      </Tag>
                    ))}
                  </Space>
                </div>
              )}
            </Space>
          </div>
        </Sider>
      )}
    </Layout>
  )
}
