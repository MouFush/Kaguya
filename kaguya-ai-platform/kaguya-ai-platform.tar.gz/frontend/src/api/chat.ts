import apiClient from './client'

export interface Chat {
  id: string
  title: string
  role_id?: string
  tags: string[]
  is_starred: boolean
  model: string
  temperature: number
  max_tokens: number
  created_at: string
  updated_at: string
}

export interface Message {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  reasoning?: string
  created_at: string
}

export const chatApi = {
  // 获取对话列表
  getChats: (params?: { tag?: string; search?: string }) =>
    apiClient.get<Chat[]>('/chats', { params }),
  
  // 创建对话
  createChat: (data: Partial<Chat>) =>
    apiClient.post<Chat>('/chats', data),
  
  // 获取对话详情
  getChat: (id: string) =>
    apiClient.get<Chat>(`/chats/${id}`),
  
  // 更新对话
  updateChat: (id: string, data: Partial<Chat>) =>
    apiClient.put<Chat>(`/chats/${id}`, data),
  
  // 删除对话
  deleteChat: (id: string) =>
    apiClient.delete(`/chats/${id}`),
  
  // 获取消息
  getMessages: (chatId: string) =>
    apiClient.get<Message[]>(`/chats/${chatId}/messages`),
  
  // 发送消息（流式）
  sendMessageStream: async (
    chatId: string,
    content: string,
    onChunk: (chunk: string) => void
  ) => {
    const response = await fetch(`/api/v1/messages/stream?chat_id=${chatId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({ content }),
    })
    
    const reader = response.body?.getReader()
    const decoder = new TextDecoder()
    
    if (!reader) return
    
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      
      const text = decoder.decode(value)
      const lines = text.split('\n')
      
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          try {
            const data = JSON.parse(line.slice(6))
            if (data.content) {
              onChunk(data.content)
            }
          } catch (e) {
            // 忽略解析错误
          }
        }
      }
    }
  },
  
  // 获取可用模型
  getModels: () =>
    apiClient.get<{ models: Array<{ id: string; name: string; provider: string }> }>('/messages/models'),
}
