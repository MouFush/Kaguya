#!/bin/bash
# Kaguya AI Platform DL环境部署脚本
# 适用于: AutoDL / 恒源云 / 阿里云 / 腾讯云等GPU云服务器

set -e

echo "========================================"
echo "Kaguya AI Platform DL环境部署脚本"
echo "========================================"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 配置变量
PROJECT_NAME="kaguya-ai-platform"
DEPLOY_DIR="/opt/${PROJECT_NAME}"
BACKUP_DIR="/backup/${PROJECT_NAME}"
LOG_DIR="/var/log/${PROJECT_NAME}"

# 检查root权限
check_root() {
    if [[ $EUID -ne 0 ]]; then
        echo -e "${RED}错误: 请使用root权限运行此脚本${NC}"
        exit 1
    fi
}

# 检查系统环境
check_environment() {
    echo -e "${YELLOW}检查系统环境...${NC}"
    
    # 检查操作系统
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$NAME
        VERSION=$VERSION_ID
        echo "操作系统: $OS $VERSION"
    else
        echo -e "${RED}无法检测操作系统${NC}"
        exit 1
    fi
    
    # 检查Docker
    if ! command -v docker &> /dev/null; then
        echo -e "${YELLOW}Docker未安装，正在安装...${NC}"
        install_docker
    else
        echo "Docker版本: $(docker --version)"
    fi
    
    # 检查Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        echo -e "${YELLOW}Docker Compose未安装，正在安装...${NC}"
        install_docker_compose
    else
        echo "Docker Compose版本: $(docker-compose --version)"
    fi
    
    echo -e "${GREEN}环境检查完成${NC}"
}

# 安装Docker
install_docker() {
    curl -fsSL https://get.docker.com | bash
    systemctl enable docker
    systemctl start docker
    usermod -aG docker $USER
}

# 安装Docker Compose
install_docker_compose() {
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
}

# 创建目录结构
create_directories() {
    echo -e "${YELLOW}创建项目目录...${NC}"
    
    mkdir -p ${DEPLOY_DIR}/{backend,frontend,deploy,infra}
    mkdir -p ${BACKUP_DIR}/{database,uploads}
    mkdir -p ${LOG_DIR}
    mkdir -p /etc/${PROJECT_NAME}
    
    echo -e "${GREEN}目录创建完成${NC}"
}

# 复制项目文件
copy_project_files() {
    echo -e "${YELLOW}复制项目文件...${NC}"
    
    # 假设项目文件在当前目录
    if [[ -d "./backend" ]]; then
        cp -r ./backend/* ${DEPLOY_DIR}/backend/
    fi
    
    if [[ -d "./frontend" ]]; then
        cp -r ./frontend/* ${DEPLOY_DIR}/frontend/
    fi
    
    if [[ -d "./deploy" ]]; then
        cp -r ./deploy/* ${DEPLOY_DIR}/deploy/
    fi
    
    if [[ -d "./infra" ]]; then
        cp -r ./infra/* ${DEPLOY_DIR}/infra/
    fi
    
    echo -e "${GREEN}文件复制完成${NC}"
}

# 创建环境配置文件
create_env_file() {
    echo -e "${YELLOW}创建环境配置文件...${NC}"
    
    cat > ${DEPLOY_DIR}/.env << 'EOF'
# 数据库配置
DB_USER=kaguya
DB_PASSWORD=KaguyaAI@2024!Secure
DB_NAME=kaguya_ai
DATABASE_URL=postgresql+asyncpg://kaguya:KaguyaAI@2024!Secure@postgres:5432/kaguya_ai

# Redis配置
REDIS_URL=redis://redis:6379/0
CELERY_BROKER_URL=redis://redis:6379/1
CELERY_RESULT_BACKEND=redis://redis:6379/2

# Milvus配置
MILVUS_HOST=milvus-standalone
MILVUS_PORT=19530

# MinIO配置
MINIO_ROOT_USER=kaguyaadmin
MINIO_ROOT_PASSWORD=KaguyaMinIO@2024!
MINIO_ENDPOINT=minio:9000

# JWT配置
JWT_SECRET_KEY=$(openssl rand -hex 32)
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7

# AI API Keys
OPENAI_API_KEY=your-openai-api-key-here
DEEPSEEK_API_KEY=your-deepseek-api-key-here
ANTHROPIC_API_KEY=your-anthropic-api-key-here

# 监控配置
GRAFANA_ADMIN_PASSWORD=KaguyaGrafana@2024!

# 环境配置
ENV=production
DEBUG=false
LOG_LEVEL=INFO

# 资源限制
BACKEND_WORKERS=4
CELERY_CONCURRENCY=4
EOF

    echo -e "${GREEN}环境配置文件创建完成${NC}"
    echo -e "${YELLOW}警告: 请编辑 ${DEPLOY_DIR}/.env 文件，填入真实的API密钥${NC}"
}

# 创建系统服务
create_systemd_services() {
    echo -e "${YELLOW}创建系统服务...${NC}"
    
    # 创建启动服务
    cat > /etc/systemd/system/${PROJECT_NAME}.service << EOF
[Unit]
Description=Kaguya AI Platform
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=${DEPLOY_DIR}/deploy
ExecStart=/usr/local/bin/docker-compose -f docker-compose.prod.yml up -d
ExecStop=/usr/local/bin/docker-compose -f docker-compose.prod.yml down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

    # 创建备份服务
    cat > /etc/systemd/system/${PROJECT_NAME}-backup.service << EOF
[Unit]
Description=Kaguya AI Platform Backup

[Service]
Type=oneshot
ExecStart=${DEPLOY_DIR}/deploy/backup.sh
EOF

    # 创建备份定时器
    cat > /etc/systemd/system/${PROJECT_NAME}-backup.timer << EOF
[Unit]
Description=Run Kaguya AI Platform Backup daily

[Timer]
OnCalendar=daily
Persistent=true

[Install]
WantedBy=timers.target
EOF

    systemctl daemon-reload
    systemctl enable ${PROJECT_NAME}.service
    systemctl enable ${PROJECT_NAME}-backup.timer
    
    echo -e "${GREEN}系统服务创建完成${NC}"
}

# 创建备份脚本
create_backup_script() {
    echo -e "${YELLOW}创建备份脚本...${NC}"
    
    cat > ${DEPLOY_DIR}/deploy/backup.sh << 'EOF'
#!/bin/bash
# 备份脚本

BACKUP_DIR="/backup/kaguya-ai-platform"
DATE=$(date +%Y%m%d_%H%M%S)

# 创建备份目录
mkdir -p ${BACKUP_DIR}/{database,uploads}

# 备份数据库
echo "备份数据库..."
docker exec kaguya-postgres-prod pg_dump -U kaguya kaguya_ai > ${BACKUP_DIR}/database/backup_${DATE}.sql

# 备份上传文件
echo "备份上传文件..."
docker cp kaguya-minio-prod:/data ${BACKUP_DIR}/uploads/minio_${DATE}

# 压缩备份
cd ${BACKUP_DIR}
tar -czf backup_${DATE}.tar.gz database/ uploads/

# 清理旧备份（保留7天）
find ${BACKUP_DIR} -name "backup_*.tar.gz" -mtime +7 -delete
find ${BACKUP_DIR}/database -name "backup_*.sql" -mtime +7 -delete
find ${BACKUP_DIR}/uploads -name "minio_*" -mtime +7 -exec rm -rf {} \;

echo "备份完成: backup_${DATE}.tar.gz"
EOF

    chmod +x ${DEPLOY_DIR}/deploy/backup.sh
    
    echo -e "${GREEN}备份脚本创建完成${NC}"
}

# 创建Nginx配置
create_nginx_config() {
    echo -e "${YELLOW}创建Nginx配置...${NC}"
    
    mkdir -p ${DEPLOY_DIR}/deploy/nginx
    
    cat > ${DEPLOY_DIR}/deploy/nginx/nginx.conf << 'EOF'
events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # 日志格式
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;
    error_log /var/log/nginx/error.log;

    # Gzip压缩
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml;

    # 上游服务器
    upstream backend {
        server backend:8000;
    }

    # HTTP重定向到HTTPS
    server {
        listen 80;
        server_name _;
        return 301 https://$host$request_uri;
    }

    # HTTPS服务器
    server {
        listen 443 ssl http2;
        server_name _;

        # SSL证书（需要替换为真实证书）
        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;

        # 前端静态文件
        location / {
            root /var/www/html;
            try_files $uri $uri/ /index.html;
            expires 1d;
        }

        # API代理
        location /api/ {
            proxy_pass http://backend;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;
            proxy_read_timeout 86400;
        }

        # WebSocket代理
        location /ws/ {
            proxy_pass http://backend;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_read_timeout 86400;
        }
    }
}
EOF

    # 创建自签名证书（仅用于测试）
    mkdir -p ${DEPLOY_DIR}/deploy/nginx/ssl
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout ${DEPLOY_DIR}/deploy/nginx/ssl/key.pem \
        -out ${DEPLOY_DIR}/deploy/nginx/ssl/cert.pem \
        -subj "/C=CN/ST=Beijing/L=Beijing/O=Kaguya AI/CN=localhost"
    
    echo -e "${GREEN}Nginx配置创建完成${NC}"
}

# 创建监控配置
create_monitoring_config() {
    echo -e "${YELLOW}创建监控配置...${NC}"
    
    mkdir -p ${DEPLOY_DIR}/deploy/monitoring
    
    # Prometheus配置
    cat > ${DEPLOY_DIR}/deploy/monitoring/prometheus.yml << 'EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'backend'
    static_configs:
      - targets: ['backend:8000']
    metrics_path: /metrics

  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres:5432']

  - job_name: 'redis'
    static_configs:
      - targets: ['redis:6379']
EOF

    # Grafana数据源配置
    mkdir -p ${DEPLOY_DIR}/deploy/monitoring/grafana/datasources
    cat > ${DEPLOY_DIR}/deploy/monitoring/grafana/datasources/datasource.yml << 'EOF'
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
EOF

    echo -e "${GREEN}监控配置创建完成${NC}"
}

# 部署项目
deploy_project() {
    echo -e "${YELLOW}开始部署项目...${NC}"
    
    cd ${DEPLOY_DIR}/deploy
    
    # 拉取镜像并启动
    docker-compose -f docker-compose.prod.yml pull
    docker-compose -f docker-compose.prod.yml up -d --build
    
    # 等待服务启动
    echo "等待服务启动..."
    sleep 30
    
    # 检查服务状态
    docker-compose -f docker-compose.prod.yml ps
    
    echo -e "${GREEN}项目部署完成${NC}"
}

# 显示部署信息
show_deployment_info() {
    echo ""
    echo "========================================"
    echo -e "${GREEN}Kaguya AI Platform 部署完成!${NC}"
    echo "========================================"
    echo ""
    echo "访问地址:"
    echo "  - 前端应用: https://$(hostname -I | awk '{print $1}')"
    echo "  - API文档: https://$(hostname -I | awk '{print $1}')/api/docs"
    echo "  - 监控面板: http://$(hostname -I | awk '{print $1}'):3000"
    echo "  - Prometheus: http://$(hostname -I | awk '{print $1}'):9090"
    echo ""
    echo "管理命令:"
    echo "  - 启动: systemctl start ${PROJECT_NAME}"
    echo "  - 停止: systemctl stop ${PROJECT_NAME}"
    echo "  - 重启: systemctl restart ${PROJECT_NAME}"
    echo "  - 查看日志: journalctl -u ${PROJECT_NAME} -f"
    echo ""
    echo "Docker命令:"
    echo "  - 查看状态: docker-compose -f ${DEPLOY_DIR}/deploy/docker-compose.prod.yml ps"
    echo "  - 查看日志: docker-compose -f ${DEPLOY_DIR}/deploy/docker-compose.prod.yml logs -f"
    echo "  - 更新: docker-compose -f ${DEPLOY_DIR}/deploy/docker-compose.prod.yml pull && docker-compose -f ${DEPLOY_DIR}/deploy/docker-compose.prod.yml up -d"
    echo ""
    echo -e "${YELLOW}重要提示:${NC}"
    echo "1. 请编辑 ${DEPLOY_DIR}/.env 文件，填入真实的API密钥"
    echo "2. 请替换SSL证书为真实证书"
    echo "3. 建议配置防火墙规则，只开放必要端口"
    echo "4. 定期执行备份: ${DEPLOY_DIR}/deploy/backup.sh"
    echo ""
}

# 主函数
main() {
    check_root
    check_environment
    create_directories
    copy_project_files
    create_env_file
    create_nginx_config
    create_monitoring_config
    create_backup_script
    create_systemd_services
    deploy_project
    show_deployment_info
}

# 执行主函数
main
