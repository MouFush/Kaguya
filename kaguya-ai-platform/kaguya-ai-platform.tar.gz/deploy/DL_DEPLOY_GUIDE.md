# Kaguya AI Platform DL环境部署指南

## 概述

本指南介绍如何将 Kaguya AI Platform 部署到深度学习云服务器环境（如 AutoDL、恒源云、阿里云、腾讯云等）。

## 环境要求

### 硬件要求
- **CPU**: 8核+
- **内存**: 16GB+
- **存储**: 100GB+ SSD
- **GPU**: 可选（用于模型微调）

### 软件要求
- **操作系统**: Ubuntu 20.04/22.04 LTS
- **Docker**: 20.10+
- **Docker Compose**: 2.0+

## 快速部署

### 1. 准备DL服务器

以 AutoDL 为例：

1. 登录 AutoDL 控制台
2. 创建实例：
   - 镜像：Ubuntu 20.04
   - GPU：根据需求选择（可选）
   - 硬盘：100GB+
3. 通过SSH连接到服务器

### 2. 上传项目文件

```bash
# 在本地打包项目
cd c:\Users\林智涵\.conda\kaguya-ai-platform
tar -czvf kaguya-ai-platform.tar.gz .

# 上传到服务器（使用scp或rsync）
scp kaguya-ai-platform.tar.gz root@your-server-ip:/root/
```

### 3. 执行部署脚本

```bash
# 登录到服务器
ssh root@your-server-ip

# 解压项目
tar -xzvf kaguya-ai-platform.tar.gz
cd kaguya-ai-platform

# 执行部署脚本
chmod +x deploy/deploy.sh
sudo ./deploy/deploy.sh
```

部署脚本会自动完成：
- 安装 Docker 和 Docker Compose
- 创建项目目录结构
- 配置环境变量
- 设置 Nginx 反向代理
- 配置监控（Prometheus + Grafana）
- 创建系统服务和定时备份
- 启动所有服务

### 4. 配置环境变量

编辑 `.env` 文件，填入真实的API密钥：

```bash
nano /opt/kaguya-ai-platform/.env
```

修改以下配置：
```env
# AI API Keys（必填）
OPENAI_API_KEY=sk-your-openai-key
DEEPSEEK_API_KEY=your-deepseek-key
ANTHROPIC_API_KEY=sk-ant-your-key

# 数据库密码（建议修改）
DB_PASSWORD=YourSecurePassword123!

# JWT密钥（自动生成或自定义）
JWT_SECRET_KEY=your-random-secret-key
```

### 5. 重启服务

```bash
systemctl restart kaguya-ai-platform
```

## 访问服务

部署完成后，可以通过以下地址访问：

- **前端应用**: `https://your-server-ip`
- **API文档**: `https://your-server-ip/api/docs`
- **Grafana监控**: `http://your-server-ip:3000` (默认账号: admin / 密码见.env)
- **Prometheus**: `http://your-server-ip:9090`

## 管理命令

### 系统服务
```bash
# 启动
systemctl start kaguya-ai-platform

# 停止
systemctl stop kaguya-ai-platform

# 重启
systemctl restart kaguya-ai-platform

# 查看状态
systemctl status kaguya-ai-platform

# 查看日志
journalctl -u kaguya-ai-platform -f
```

### Docker命令
```bash
cd /opt/kaguya-ai-platform/deploy

# 查看服务状态
docker-compose -f docker-compose.prod.yml ps

# 查看日志
docker-compose -f docker-compose.prod.yml logs -f

# 重启单个服务
docker-compose -f docker-compose.prod.yml restart backend

# 更新镜像
docker-compose -f docker-compose.prod.yml pull
docker-compose -f docker-compose.prod.yml up -d

# 进入容器
docker exec -it kaguya-backend-prod bash
```

### 数据库管理
```bash
# 备份数据库
/opt/kaguya-ai-platform/deploy/backup.sh

# 进入数据库
docker exec -it kaguya-postgres-prod psql -U kaguya -d kaguya_ai

# 恢复数据库
docker exec -i kaguya-postgres-prod psql -U kaguya -d kaguya_ai < backup.sql
```

## 配置域名和SSL

### 1. 申请域名
在域名服务商处申请域名，并添加A记录指向服务器IP。

### 2. 申请SSL证书

使用 Let's Encrypt：

```bash
# 安装certbot
docker run -it --rm \
  -v /opt/kaguya-ai-platform/deploy/nginx/ssl:/etc/letsencrypt \
  -v /opt/kaguya-ai-platform/deploy/nginx/www:/var/www/html \
  certbot/certbot certonly \
  --webroot -w /var/www/html \
  -d your-domain.com

# 更新Nginx配置使用新证书
nano /opt/kaguya-ai-platform/deploy/nginx/nginx.conf
# 修改 ssl_certificate 和 ssl_certificate_key 路径

# 重启服务
docker-compose -f /opt/kaguya-ai-platform/deploy/docker-compose.prod.yml restart nginx
```

### 3. 配置自动续期

```bash
# 添加定时任务
crontab -e

# 添加以下行（每月1号续期）
0 0 1 * * docker run -it --rm -v /opt/kaguya-ai-platform/deploy/nginx/ssl:/etc/letsencrypt certbot/certbot renew
```

## 性能优化

### 1. 数据库优化

PostgreSQL已配置优化参数，如需调整：

```bash
# 编辑docker-compose.prod.yml
nano /opt/kaguya-ai-platform/deploy/docker-compose.prod.yml

# 修改postgres服务的command部分
```

### 2. 缓存优化

Redis已配置持久化和内存限制，如需调整：

```bash
# 修改Redis配置
docker exec -it kaguya-redis-prod redis-cli CONFIG SET maxmemory 4gb
```

### 3. 负载均衡

如需多实例部署，可以使用：

```bash
# 扩展后端服务
docker-compose -f docker-compose.prod.yml up -d --scale backend=3
```

## 监控和告警

### 1. 配置Grafana

1. 访问 `http://your-server-ip:3000`
2. 使用默认账号登录
3. 导入预设仪表板
4. 配置告警规则

### 2. 配置告警通知

在Grafana中配置：
- 邮件通知
- 钉钉/飞书/企业微信机器人
- Slack通知

### 3. 查看日志

```bash
# 实时日志
docker-compose -f docker-compose.prod.yml logs -f --tail=100

# 特定服务日志
docker-compose -f docker-compose.prod.yml logs -f backend
```

## 备份和恢复

### 自动备份
已配置定时任务，每天自动备份：
- 数据库备份
- 文件备份
- 保留7天历史

### 手动备份

```bash
/opt/kaguya-ai-platform/deploy/backup.sh
```

### 恢复数据

```bash
# 停止服务
systemctl stop kaguya-ai-platform

# 恢复数据库
docker exec -i kaguya-postgres-prod psql -U kaguya -d kaguya_ai < backup_20240101_120000.sql

# 恢复文件
docker cp minio_20240101_120000 kaguya-minio-prod:/data

# 启动服务
systemctl start kaguya-ai-platform
```

## 故障排查

### 1. 服务无法启动

```bash
# 检查日志
journalctl -u kaguya-ai-platform -n 100

# 检查Docker状态
docker ps -a
docker logs kaguya-backend-prod
```

### 2. 数据库连接失败

```bash
# 检查数据库状态
docker exec kaguya-postgres-prod pg_isready

# 检查网络连接
docker network inspect kaguya-prod-network
```

### 3. 端口冲突

```bash
# 查看端口占用
netstat -tlnp | grep 80
netstat -tlnp | grep 443

# 停止冲突服务
systemctl stop nginx  # 如果系统有nginx
```

## 安全建议

1. **修改默认密码**: 立即修改所有默认密码
2. **配置防火墙**: 只开放必要端口（80, 443, 3000）
3. **定期更新**: 定期更新系统和Docker镜像
4. **启用日志审计**: 配置审计日志记录
5. **数据加密**: 启用数据库和存储加密

## 升级指南

### 更新代码

```bash
cd /opt/kaguya-ai-platform

# 拉取最新代码
git pull origin main

# 重新部署
sudo ./deploy/deploy.sh
```

### 更新Docker镜像

```bash
cd /opt/kaguya-ai-platform/deploy

# 拉取最新镜像
docker-compose -f docker-compose.prod.yml pull

# 重启服务
docker-compose -f docker-compose.prod.yml up -d
```

## 卸载

```bash
# 停止服务
systemctl stop kaguya-ai-platform
systemctl disable kaguya-ai-platform

# 删除容器
cd /opt/kaguya-ai-platform/deploy
docker-compose -f docker-compose.prod.yml down -v

# 删除数据（谨慎操作）
rm -rf /opt/kaguya-ai-platform
rm -rf /backup/kaguya-ai-platform
rm -rf /var/log/kaguya-ai-platform

# 删除系统服务
rm /etc/systemd/system/kaguya-ai-platform*.service
rm /etc/systemd/system/kaguya-ai-platform*.timer
systemctl daemon-reload
```

## 支持

如有问题，请查看：
- 日志文件: `/var/log/kaguya-ai-platform/`
- Docker日志: `docker logs <container_name>`
- 系统日志: `journalctl -u kaguya-ai-platform`
