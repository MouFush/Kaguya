"""
AI工作流引擎模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, Text, ForeignKey, JSON, Enum, DateTime, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from datetime import datetime

from app.models.base import Base


class WorkflowStatus(str, enum.Enum):
    """工作流状态"""
    DRAFT = "draft"             # 草稿
    ACTIVE = "active"           # 活跃
    PAUSED = "paused"           # 暂停
    ARCHIVED = "archived"       # 归档


class WorkflowTriggerType(str, enum.Enum):
    """工作流触发器类型"""
    MANUAL = "manual"           # 手动触发
    SCHEDULED = "scheduled"     # 定时触发
    WEBHOOK = "webhook"         # Webhook触发
    EVENT = "event"             # 事件触发
    MESSAGE = "message"         # 消息触发


class WorkflowExecutionStatus(str, enum.Enum):
    """工作流执行状态"""
    PENDING = "pending"         # 待执行
    RUNNING = "running"         # 执行中
    COMPLETED = "completed"     # 已完成
    FAILED = "failed"           # 失败
    CANCELLED = "cancelled"     # 已取消
    TIMEOUT = "timeout"         # 超时


class Workflow(Base):
    """工作流定义模型"""
    __tablename__ = "workflows"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 基本信息
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 触发器配置
    trigger_type: Mapped[WorkflowTriggerType] = mapped_column(Enum(WorkflowTriggerType), nullable=False)
    trigger_config: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "schedule": "0 9 * * *",  # cron表达式（定时触发）
    #     "webhook_path": "/webhooks/my-workflow",  # webhook路径
    #     "event_type": "chat.message.created",  # 事件类型
    #     "message_pattern": "/workflow"  # 消息匹配模式
    # }
    
    # 工作流节点定义
    nodes: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, nullable=False)
    # [
    #     {
    #         "id": "node_1",
    #         "type": "llm",
    #         "config": {
    #             "model": "gpt-4",
    #             "prompt": "{{input.message}}",
    #             "temperature": 0.7
    #         },
    #         "position": {"x": 100, "y": 100}
    #     },
    #     {
    #         "id": "node_2",
    #         "type": "condition",
    #         "config": {
    #             "condition": "{{node_1.output.length}} > 100"
    #         },
    #         "position": {"x": 300, "y": 100}
    #     }
    # ]
    
    # 节点连接
    edges: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    # [
    #     {"source": "node_1", "target": "node_2", "condition": "success"},
    #     {"source": "node_2", "target": "node_3", "condition": "true"},
    #     {"source": "node_2", "target": "node_4", "condition": "false"}
    # ]
    
    # 变量定义
    variables: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "input": {"type": "object", "description": "输入数据"},
    #     "output": {"type": "string", "description": "输出结果"}
    # }
    
    # 状态
    status: Mapped[WorkflowStatus] = mapped_column(Enum(WorkflowStatus), default=WorkflowStatus.DRAFT)
    
    # 执行统计
    total_executions: Mapped[int] = mapped_column(Integer, default=0)
    successful_executions: Mapped[int] = mapped_column(Integer, default=0)
    failed_executions: Mapped[int] = mapped_column(Integer, default=0)
    
    # 最后执行时间
    last_executed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 关系
    executions: Mapped[List["WorkflowExecution"]] = relationship("WorkflowExecution", back_populates="workflow", cascade="all, delete-orphan")
    
    def __repr__(self) -> str:
        return f"<Workflow(id={self.id}, name={self.name}, trigger={self.trigger_type})>"


class WorkflowExecution(Base):
    """工作流执行记录"""
    __tablename__ = "workflow_executions"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    workflow_id: Mapped[str] = mapped_column(ForeignKey("workflows.id"), nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    triggered_by: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    
    # 执行状态
    status: Mapped[WorkflowExecutionStatus] = mapped_column(Enum(WorkflowExecutionStatus), default=WorkflowExecutionStatus.PENDING)
    
    # 输入数据
    input_data: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    
    # 输出数据
    output_data: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    
    # 执行上下文（节点中间结果）
    context: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    # {
    #     "node_1": {"output": "...", "status": "completed", "started_at": "...", "completed_at": "..."},
    #     "node_2": {"output": "...", "status": "completed"}
    # }
    
    # 错误信息
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    error_node_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    
    # 执行时间
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 耗时（毫秒）
    duration_ms: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    # 关系
    workflow: Mapped["Workflow"] = relationship("Workflow", back_populates="executions")
    logs: Mapped[List["WorkflowExecutionLog"]] = relationship("WorkflowExecutionLog", back_populates="execution", cascade="all, delete-orphan")
    
    def __repr__(self) -> str:
        return f"<WorkflowExecution(id={self.id}, workflow={self.workflow_id}, status={self.status})>"


class WorkflowExecutionLog(Base):
    """工作流执行日志"""
    __tablename__ = "workflow_execution_logs"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    execution_id: Mapped[str] = mapped_column(ForeignKey("workflow_executions.id"), nullable=False)
    
    # 节点信息
    node_id: Mapped[str] = mapped_column(String(36), nullable=False)
    node_type: Mapped[str] = mapped_column(String(50), nullable=False)
    
    # 日志级别
    level: Mapped[str] = mapped_column(String(20), default="info")  # debug, info, warning, error
    
    # 日志消息
    message: Mapped[str] = mapped_column(Text, nullable=False)
    
    # 详细数据
    data: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    
    # 时间戳
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    
    # 关系
    execution: Mapped["WorkflowExecution"] = relationship("WorkflowExecution", back_populates="logs")
    
    def __repr__(self) -> str:
        return f"<WorkflowExecutionLog(execution={self.execution_id}, node={self.node_id}, level={self.level})>"


class WorkflowTemplate(Base):
    """工作流模板"""
    __tablename__ = "workflow_templates"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    
    # 分类
    category: Mapped[str] = mapped_column(String(50), nullable=False)
    tags: Mapped[List[str]] = mapped_column(JSON, default=list)
    
    # 模板内容
    nodes: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, nullable=False)
    edges: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    variables: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    
    # 作者
    author_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    
    # 统计
    use_count: Mapped[int] = mapped_column(Integer, default=0)
    
    # 是否官方模板
    is_official: Mapped[bool] = mapped_column(Boolean, default=False)
    
    def __repr__(self) -> str:
        return f"<WorkflowTemplate(id={self.id}, name={self.name}, category={self.category})>"
