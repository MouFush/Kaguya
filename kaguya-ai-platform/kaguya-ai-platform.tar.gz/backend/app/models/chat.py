"""
对话和消息模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, Text, Boolean, Integer, ForeignKey, JSON, Float
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.base import Base


class Chat(Base):
    """对话模型"""
    __tablename__ = "chats"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(200), default="新对话")
    
    # 角色设置
    role_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    
    # 标签
    tags: Mapped[Optional[List[str]]] = mapped_column(JSON, default=list)
    
    # 状态
    is_starred: Mapped[bool] = mapped_column(Boolean, default=False)
    is_archived: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # 模型设置
    model: Mapped[str] = mapped_column(String(50), default="gpt-3.5-turbo")
    temperature: Mapped[float] = mapped_column(Float, default=0.7)
    max_tokens: Mapped[int] = mapped_column(Integer, default=2048)
    
    # 关系
    user: Mapped["User"] = relationship("User", back_populates="chats")
    messages: Mapped[List["Message"]] = relationship("Message", back_populates="chat", cascade="all, delete-orphan", order_by="Message.created_at")
    
    def __repr__(self) -> str:
        return f"<Chat(id={self.id}, title={self.title})>"


class Message(Base):
    """消息模型"""
    __tablename__ = "messages"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    chat_id: Mapped[str] = mapped_column(ForeignKey("chats.id"), nullable=False)
    
    # 消息内容
    role: Mapped[str] = mapped_column(String(20), nullable=False)  # user, assistant, system
    content: Mapped[str] = mapped_column(Text, nullable=False)
    
    # 思考过程（用于推理模型）
    reasoning: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 工具调用结果
    tool_results: Mapped[Optional[List[Dict[str, Any]]]] = mapped_column(JSON, nullable=True)
    
    # 附件
    attachments: Mapped[Optional[List[Dict[str, Any]]]] = mapped_column(JSON, nullable=True)
    
    # Token统计
    prompt_tokens: Mapped[int] = mapped_column(Integer, default=0)
    completion_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0)
    
    # 关系
    chat: Mapped["Chat"] = relationship("Chat", back_populates="messages")
    favorites: Mapped[List["Favorite"]] = relationship("Favorite", back_populates="message", cascade="all, delete-orphan")
    
    def __repr__(self) -> str:
        return f"<Message(id={self.id}, role={self.role})>"


class Favorite(Base):
    """收藏消息模型"""
    __tablename__ = "favorites"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    message_id: Mapped[str] = mapped_column(ForeignKey("messages.id"), nullable=False)
    chat_id: Mapped[str] = mapped_column(ForeignKey("chats.id"), nullable=False)
    
    # 收藏的备注
    note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 关系
    user: Mapped["User"] = relationship("User", back_populates="favorites")
    message: Mapped["Message"] = relationship("Message", back_populates="favorites")
    chat: Mapped["Chat"] = relationship("Chat")
    
    def __repr__(self) -> str:
        return f"<Favorite(id={self.id})>"
