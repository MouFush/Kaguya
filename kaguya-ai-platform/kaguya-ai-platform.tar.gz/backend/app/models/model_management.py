"""
模型管理系统模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, Text, ForeignKey, JSON, DateTime, Boolean, Integer, Float, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from datetime import datetime

from app.models.base import Base


class ModelProvider(str, enum.Enum):
    """模型提供商"""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    DEEPSEEK = "deepseek"
    LOCAL = "local"
    CUSTOM = "custom"


class ModelStatus(str, enum.Enum):
    """模型状态"""
    ACTIVE = "active"
    BETA = "beta"
    DEPRECATED = "deprecated"
    COMING_SOON = "coming_soon"


class AIModel(Base):
    """AI模型"""
    __tablename__ = "ai_models"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    
    # 基本信息
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    model_id: Mapped[str] = mapped_column(String(100), nullable=False)  # 实际调用ID，如 gpt-4
    provider: Mapped[ModelProvider] = mapped_column(Enum(ModelProvider), nullable=False)
    
    # 描述
    description: Mapped[str] = mapped_column(Text, nullable=False)
    capabilities: Mapped[List[str]] = mapped_column(JSON, default=list)  # chat, code, vision, etc.
    
    # 状态
    status: Mapped[ModelStatus] = mapped_column(Enum(ModelStatus), default=ModelStatus.ACTIVE)
    
    # 定价
    pricing: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "input_price": 0.001,  # per 1K tokens
    #     "output_price": 0.002,
    #     "currency": "USD"
    # }
    
    # 配置
    config: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "max_tokens": 8192,
    #     "supports_streaming": true,
    #     "supports_vision": false,
    #     "supports_functions": true
    # }
    
    # 统计
    usage_count: Mapped[int] = mapped_column(Integer, default=0)
    avg_rating: Mapped[float] = mapped_column(Float, default=0.0)
    rating_count: Mapped[int] = mapped_column(Integer, default=0)
    
    # 是否公开
    is_public: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # 创建者（null表示系统模型）
    created_by: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    
    # 版本
    version: Mapped[str] = mapped_column(String(20), default="1.0.0")
    
    def __repr__(self) -> str:
        return f"<AIModel(id={self.id}, name={self.name}, provider={self.provider})>"


class ModelDeployment(Base):
    """模型部署（私有部署）"""
    __tablename__ = "model_deployments"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    model_id: Mapped[str] = mapped_column(ForeignKey("ai_models.id"), nullable=False)
    
    # 部署名称
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # 部署配置
    deployment_type: Mapped[str] = mapped_column(String(50), nullable=False)  # dedicated, shared
    
    # 资源配置
    resources: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "gpu_type": "A100",
    #     "gpu_count": 2,
    #     "memory_gb": 80,
    #     "region": "us-west-2"
    # }
    
    # 端点信息
    endpoint_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    api_key: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    # 状态
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending, deploying, active, failed, stopped
    
    # 时间
    deployed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    stopped_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 成本
    hourly_cost: Mapped[float] = mapped_column(Float, default=0.0)


class FineTuningJob(Base):
    """微调任务"""
    __tablename__ = "fine_tuning_jobs"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 基础模型
    base_model_id: Mapped[str] = mapped_column(ForeignKey("ai_models.id"), nullable=False)
    
    # 任务名称
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # 数据集
    dataset_id: Mapped[str] = mapped_column(String(36), nullable=False)  # 关联Document
    
    # 配置
    config: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "epochs": 3,
    #     "batch_size": 4,
    #     "learning_rate": 0.0001,
    #     "validation_split": 0.1
    # }
    
    # 状态
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending, running, completed, failed, cancelled
    
    # 进度
    progress: Mapped[float] = mapped_column(Float, default=0.0)  # 0-100
    
    # 结果
    result_model_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    metrics: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    # { "loss": 0.5, "accuracy": 0.95, "eval_loss": 0.6 }
    
    # 错误信息
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 时间
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 成本
    estimated_cost: Mapped[float] = mapped_column(Float, default=0.0)
    actual_cost: Mapped[float] = mapped_column(Float, default=0.0)


class ModelEvaluation(Base):
    """模型评估"""
    __tablename__ = "model_evaluations"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 评估名称
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # 评估的模型
    model_ids: Mapped[List[str]] = mapped_column(JSON, nullable=False)  # 模型ID列表
    
    # 评估数据集
    dataset_id: Mapped[str] = mapped_column(String(36), nullable=False)
    
    # 评估指标
    metrics: Mapped[List[str]] = mapped_column(JSON, default=list)  # accuracy, f1, bleu, etc.
    
    # 状态
    status: Mapped[str] = mapped_column(String(20), default="pending")
    
    # 结果
    results: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    # {
    #     "model_1": { "accuracy": 0.95, "f1": 0.94 },
    #     "model_2": { "accuracy": 0.93, "f1": 0.92 }
    # }
    
    # 人工评估
    human_eval_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    human_eval_results: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    
    # 时间
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class ABTest(Base):
    """A/B测试"""
    __tablename__ = "ab_tests"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 测试名称
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 测试变体
    variants: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, nullable=False)
    # [
    #     { "id": "control", "model_id": "gpt-4", "traffic_percentage": 50 },
    #     { "id": "variant_a", "model_id": "gpt-3.5", "traffic_percentage": 50 }
    # ]
    
    # 成功指标
    success_metrics: Mapped[List[str]] = mapped_column(JSON, default=list)  # response_time, user_rating, etc.
    
    # 状态
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft, running, paused, completed
    
    # 流量分配
    total_traffic: Mapped[int] = mapped_column(Integer, default=0)
    
    # 结果
    results: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    winning_variant: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    
    # 时间
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    ended_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class PromptTemplate(Base):
    """提示词模板库"""
    __tablename__ = "prompt_templates"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 模板信息
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 分类
    category: Mapped[str] = mapped_column(String(50), nullable=False)
    tags: Mapped[List[str]] = mapped_column(JSON, default=list)
    
    # 提示词内容
    prompt_text: Mapped[str] = mapped_column(Text, nullable=False)
    
    # 变量定义
    variables: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    # [
    #     { "name": "input", "type": "string", "required": true, "description": "用户输入" },
    #     { "name": "tone", "type": "enum", "options": ["formal", "casual"], "default": "casual" }
    # ]
    
    # 关联模型
    recommended_models: Mapped[List[str]] = mapped_column(JSON, default=list)
    
    # 示例
    examples: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    # [
    #     { "variables": { "input": "Hello" }, "output": "Hi there!" }
    # ]
    
    # 统计
    use_count: Mapped[int] = mapped_column(Integer, default=0)
    avg_rating: Mapped[float] = mapped_column(Float, default=0.0)
    
    # 是否公开
    is_public: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # 是否官方模板
    is_official: Mapped[bool] = mapped_column(Boolean, default=False)
