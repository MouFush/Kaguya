"""
数据库模型模块
"""

from app.models.user import User
from app.models.chat import Chat, Message, Favorite
from app.models.document import Document, DocumentChunk
from app.models.role import Role
from app.models.tenant import (
    Tenant,
    TenantMember,
    TenantInvitation,
    TenantActivity,
    TenantStatus,
    TenantPlan,
    TenantRole
)
from app.models.billing import (
    BillingPlan,
    Subscription,
    Invoice,
    UsageRecord,
    Coupon,
    Wallet,
    WalletTransaction,
    BillingStatus,
    PaymentMethod,
    SubscriptionStatus
)
from app.models.plugin import (
    Plugin,
    PluginInstall,
    PluginReview,
    PluginStatus,
    PluginType
)
from app.models.workflow import (
    Workflow,
    WorkflowExecution,
    WorkflowExecutionLog,
    WorkflowTemplate,
    WorkflowStatus,
    WorkflowTriggerType,
    WorkflowExecutionStatus,
)
from app.models.security import (
    AuditLog,
    APIKey,
    SSOProvider,
    Permission,
    RolePermission,
    AuditAction,
)
from app.models.analytics import (
    MetricDefinition,
    MetricDataPoint,
    Dashboard,
    Report,
    AlertRule,
    AlertNotification,
    UsageSummary,
    MetricType,
    AlertSeverity,
)
from app.models.collaboration import (
    Workspace,
    WorkspaceMember,
    Comment,
    RealTimeSession,
    Notification,
    Integration,
    WorkspaceRole,
    NotificationType,
)
from app.models.model_management import (
    AIModel,
    ModelDeployment,
    FineTuningJob,
    ModelEvaluation,
    ABTest,
    PromptTemplate,
    ModelProvider,
    ModelStatus,
    DeploymentStatus,
    JobStatus,
)
from app.models.api_platform import (
    APIProduct,
    APIVersion,
    APIEndpoint,
    APIDocument,
    SDKPackage,
    DeveloperApp,
    SandboxRequest,
    SDKCodeSample,
    APIStatus,
    APIMethod,
    AppStatus,
)

__all__ = [
    # 基础模型
    "User",
    "Chat",
    "Message",
    "Favorite",
    "Document",
    "DocumentChunk",
    "Role",
    
    # 租户模型
    "Tenant",
    "TenantMember",
    "TenantInvitation",
    "TenantActivity",
    "TenantStatus",
    "TenantPlan",
    "TenantRole",
    
    # 计费模型
    "BillingPlan",
    "Subscription",
    "Invoice",
    "UsageRecord",
    "Coupon",
    "Wallet",
    "WalletTransaction",
    "BillingStatus",
    "PaymentMethod",
    "SubscriptionStatus",
    
    # 插件模型
    "Plugin",
    "PluginInstall",
    "PluginReview",
    "PluginStatus",
    "PluginType",
    
    # 工作流模型
    "Workflow",
    "WorkflowExecution",
    "WorkflowExecutionLog",
    "WorkflowTemplate",
    "WorkflowStatus",
    "WorkflowTriggerType",
    "WorkflowExecutionStatus",
    
    # 安全模型
    "AuditLog",
    "APIKey",
    "SSOProvider",
    "Permission",
    "RolePermission",
    "AuditAction",
    
    # 分析模型
    "MetricDefinition",
    "MetricDataPoint",
    "Dashboard",
    "Report",
    "AlertRule",
    "AlertNotification",
    "UsageSummary",
    "MetricType",
    "AlertSeverity",
    
    # 协作模型
    "Workspace",
    "WorkspaceMember",
    "Comment",
    "RealTimeSession",
    "Notification",
    "Integration",
    "WorkspaceRole",
    "NotificationType",
    
    # 模型管理
    "AIModel",
    "ModelDeployment",
    "FineTuningJob",
    "ModelEvaluation",
    "ABTest",
    "PromptTemplate",
    "ModelProvider",
    "ModelStatus",
    "DeploymentStatus",
    "JobStatus",
    
    # API平台
    "APIProduct",
    "APIVersion",
    "APIEndpoint",
    "APIDocument",
    "SDKPackage",
    "DeveloperApp",
    "SandboxRequest",
    "SDKCodeSample",
    "APIStatus",
    "APIMethod",
    "AppStatus",
]
