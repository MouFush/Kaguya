"""
文档和知识库模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, Text, Integer, ForeignKey, JSON, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from app.models.base import Base


class DocumentStatus(str, enum.Enum):
    """文档状态"""
    PENDING = "pending"      # 待处理
    PROCESSING = "processing" # 处理中
    COMPLETED = "completed"  # 已完成
    FAILED = "failed"        # 失败


class Document(Base):
    """文档模型"""
    __tablename__ = "documents"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 文档信息
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    original_name: Mapped[str] = mapped_column(String(255), nullable=False)
    file_type: Mapped[str] = mapped_column(String(50), nullable=False)  # pdf, docx, txt, etc.
    file_size: Mapped[int] = mapped_column(Integer, nullable=False)  # bytes
    
    # 存储路径
    file_path: Mapped[str] = mapped_column(String(500), nullable=False)
    
    # 文档内容摘要
    content_summary: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 处理状态
    status: Mapped[DocumentStatus] = mapped_column(
        Enum(DocumentStatus),
        default=DocumentStatus.PENDING
    )
    
    # 元数据
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    
    # 错误信息
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 关系
    user: Mapped["User"] = relationship("User", back_populates="documents")
    chunks: Mapped[List["DocumentChunk"]] = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")
    
    def __repr__(self) -> str:
        return f"<Document(id={self.id}, filename={self.filename})>"


class DocumentChunk(Base):
    """文档分块模型"""
    __tablename__ = "document_chunks"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    document_id: Mapped[str] = mapped_column(ForeignKey("documents.id"), nullable=False)
    
    # 分块内容
    content: Mapped[str] = mapped_column(Text, nullable=False)
    
    # 分块序号
    chunk_index: Mapped[int] = mapped_column(Integer, nullable=False)
    
    # 向量ID (Milvus中的ID)
    vector_id: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    
    # 分块元数据
    metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    
    # 关系
    document: Mapped["Document"] = relationship("Document", back_populates="chunks")
    
    def __repr__(self) -> str:
        return f"<DocumentChunk(id={self.id}, index={self.chunk_index})>"
