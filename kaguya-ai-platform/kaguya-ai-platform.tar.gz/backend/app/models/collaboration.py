"""
团队协作模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, Text, ForeignKey, JSON, DateTime, Boolean, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from datetime import datetime

from app.models.base import Base


class Workspace(Base):
    """工作区（团队空间）"""
    __tablename__ = "workspaces"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 基本信息
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 图标和颜色
    icon: Mapped[str] = mapped_column(String(10), default="📁")
    color: Mapped[str] = mapped_column(String(20), default="#667eea")
    
    # 可见性
    is_private: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # 成员
    members: Mapped[List["WorkspaceMember"]] = relationship("WorkspaceMember", back_populates="workspace", cascade="all, delete-orphan")
    resources: Mapped[List["WorkspaceResource"]] = relationship("WorkspaceResource", back_populates="workspace", cascade="all, delete-orphan")
    
    def __repr__(self) -> str:
        return f"<Workspace(id={self.id}, name={self.name})>"


class WorkspaceRole(str, enum.Enum):
    """工作区角色"""
    OWNER = "owner"
    EDITOR = "editor"
    VIEWER = "viewer"


class WorkspaceMember(Base):
    """工作区成员"""
    __tablename__ = "workspace_members"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 角色
    role: Mapped[WorkspaceRole] = mapped_column(Enum(WorkspaceRole), default=WorkspaceRole.VIEWER)
    
    # 加入时间
    joined_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    
    # 关系
    workspace: Mapped["Workspace"] = relationship("Workspace", back_populates="members")
    user: Mapped["User"] = relationship("User")
    
    def __repr__(self) -> str:
        return f"<WorkspaceMember(workspace={self.workspace_id}, user={self.user_id})>"


class ResourceType(str, enum.Enum):
    """资源类型"""
    CHAT = "chat"
    DOCUMENT = "document"
    WORKFLOW = "workflow"
    DASHBOARD = "dashboard"


class WorkspaceResource(Base):
    """工作区资源"""
    __tablename__ = "workspace_resources"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    workspace_id: Mapped[str] = mapped_column(ForeignKey("workspaces.id"), nullable=False)
    added_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 资源信息
    resource_type: Mapped[ResourceType] = mapped_column(Enum(ResourceType), nullable=False)
    resource_id: Mapped[str] = mapped_column(String(36), nullable=False)
    
    # 资源名称（缓存）
    resource_name: Mapped[str] = mapped_column(String(200), nullable=False)
    
    # 添加时间
    added_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    
    # 关系
    workspace: Mapped["Workspace"] = relationship("Workspace", back_populates="resources")


class Comment(Base):
    """评论系统"""
    __tablename__ = "comments"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 关联资源
    resource_type: Mapped[str] = mapped_column(String(50), nullable=False)  # chat, message, document
    resource_id: Mapped[str] = mapped_column(String(36), nullable=False)
    
    # 父评论（支持回复）
    parent_id: Mapped[Optional[str]] = mapped_column(ForeignKey("comments.id"), nullable=True)
    
    # 内容
    content: Mapped[str] = mapped_column(Text, nullable=False)
    
    # 提及的用户
    mentions: Mapped[List[str]] = mapped_column(JSON, default=list)  # 用户ID列表
    
    # 状态
    is_edited: Mapped[bool] = mapped_column(Boolean, default=False)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # 时间
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    replies: Mapped[List["Comment"]] = relationship("Comment", backref="parent", remote_side=[id])


class RealtimeSession(Base):
    """实时协作会话"""
    __tablename__ = "realtime_sessions"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    
    # 会话类型
    session_type: Mapped[str] = mapped_column(String(50), nullable=False)  # chat_edit, document_edit
    
    # 关联资源
    resource_type: Mapped[str] = mapped_column(String(50), nullable=False)
    resource_id: Mapped[str] = mapped_column(String(36), nullable=False)
    
    # 参与者
    participants: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    # [
    #     { "user_id": "...", "joined_at": "...", "cursor_position": {...} },
    # ]
    
    # 会话状态
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # 时间
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    ended_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class Notification(Base):
    """通知系统"""
    __tablename__ = "notifications"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    
    # 通知类型
    notification_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # mention, invitation, workflow_complete, alert, etc.
    
    # 标题和内容
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    content: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 关联数据
    data: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # { "chat_id": "...", "message_id": "...", "user_id": "..." }
    
    # 状态
    is_read: Mapped[bool] = mapped_column(Boolean, default=False)
    read_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 时间
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    
    # 过期时间
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class Integration(Base):
    """第三方集成"""
    __tablename__ = "integrations"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 集成类型
    integration_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # slack, teams, discord, github, jira, etc.
    
    # 名称
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # 配置
    config: Mapped[Dict[str, Any]] = mapped_column(JSON, nullable=False)
    # {
    #     "webhook_url": "https://hooks.slack.com/...",
    #     "channel": "#general",
    #     "events": ["chat.created", "message.sent"]
    # }
    
    # 凭证（加密存储）
    credentials: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 状态
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_used_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 错误信息
    last_error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    error_count: Mapped[int] = mapped_column(Integer, default=0)
