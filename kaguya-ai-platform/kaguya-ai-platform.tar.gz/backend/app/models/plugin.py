"""
插件市场模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, Text, ForeignKey, JSON, Enum, DateTime, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from datetime import datetime

from app.models.base import Base


class PluginStatus(str, enum.Enum):
    """插件状态"""
    PENDING = "pending"         # 待审核
    APPROVED = "approved"       # 已审核
    REJECTED = "rejected"       # 已拒绝
    PUBLISHED = "published"     # 已发布
    DEPRECATED = "deprecated"   # 已弃用
    SUSPENDED = "suspended"     # 已暂停


class PluginType(str, enum.Enum):
    """插件类型"""
    TOOL = "tool"               # 工具插件
    MODEL = "model"             # 模型插件
    DATA_SOURCE = "data_source" # 数据源插件
    INTEGRATION = "integration" # 集成插件
    THEME = "theme"             # 主题插件


class Plugin(Base):
    """插件模型"""
    __tablename__ = "plugins"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    slug: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    
    # 类型和分类
    plugin_type: Mapped[PluginType] = mapped_column(Enum(PluginType), nullable=False)
    category: Mapped[str] = mapped_column(String(50), nullable=False)
    
    # 版本信息
    version: Mapped[str] = mapped_column(String(20), nullable=False)
    min_app_version: Mapped[str] = mapped_column(String(20), default="3.0.0")
    
    # 作者信息
    author_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    author_name: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # 插件配置
    manifest: Mapped[Dict[str, Any]] = mapped_column(JSON, nullable=False)
    # {
    #     "entry_point": "main.js",
    #     "permissions": ["api:read", "storage:write"],
    #     "webhooks": ["onInstall", "onUninstall", "onMessage"],
    #     "settings_schema": {...}
    # }
    
    # 资源文件
    icon: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    screenshots: Mapped[List[str]] = mapped_column(JSON, default=list)
    documentation_url: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    repository_url: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    # 状态
    status: Mapped[PluginStatus] = mapped_column(Enum(PluginStatus), default=PluginStatus.PENDING)
    is_free: Mapped[bool] = mapped_column(Boolean, default=True)
    price: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)  # 美分
    
    # 统计数据
    download_count: Mapped[int] = mapped_column(Integer, default=0)
    rating_average: Mapped[float] = mapped_column(default=0.0)
    rating_count: Mapped[int] = mapped_column(Integer, default=0)
    
    # 审核信息
    reviewed_by: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    review_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 关系
    installs: Mapped[List["PluginInstall"]] = relationship("PluginInstall", back_populates="plugin", cascade="all, delete-orphan")
    reviews: Mapped[List["PluginReview"]] = relationship("PluginReview", back_populates="plugin", cascade="all, delete-orphan")
    
    def __repr__(self) -> str:
        return f"<Plugin(id={self.id}, name={self.name}, type={self.plugin_type})>"


class PluginInstall(Base):
    """插件安装记录"""
    __tablename__ = "plugin_installs"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    plugin_id: Mapped[str] = mapped_column(ForeignKey("plugins.id"), nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    installed_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 安装配置
    config: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    
    # 状态
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # 安装时间
    installed_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    plugin: Mapped["Plugin"] = relationship("Plugin", back_populates="installs")
    
    def __repr__(self) -> str:
        return f"<PluginInstall(plugin={self.plugin_id}, tenant={self.tenant_id})>"


class PluginReview(Base):
    """插件评价"""
    __tablename__ = "plugin_reviews"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    plugin_id: Mapped[str] = mapped_column(ForeignKey("plugins.id"), nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    
    # 评分
    rating: Mapped[int] = mapped_column(Integer, nullable=False)  # 1-5
    
    # 评论
    title: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    content: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 关系
    plugin: Mapped["Plugin"] = relationship("Plugin", back_populates="reviews")
    
    def __repr__(self) -> str:
        return f"<PluginReview(plugin={self.plugin_id}, rating={self.rating})>"
