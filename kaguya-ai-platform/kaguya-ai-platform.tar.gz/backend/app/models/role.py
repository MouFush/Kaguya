"""
角色模型
"""

from typing import Optional
from sqlalchemy import String, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base


class Role(Base):
    """角色模型"""
    __tablename__ = "roles"
    
    id: Mapped[str] = mapped_column(String(50), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    
    # 角色设定
    system_prompt: Mapped[str] = mapped_column(Text, nullable=False)
    
    # 外观
    avatar: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    icon: Mapped[str] = mapped_column(String(10), default="🤖")
    color: Mapped[str] = mapped_column(String(20), default="#667eea")
    
    # 类型: character(角色卡), assistant(助手), custom(自定义)
    role_type: Mapped[str] = mapped_column(String(20), default="assistant")
    
    # 状态
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_preset: Mapped[bool] = mapped_column(Boolean, default=False)  # 是否预设角色
    
    # 用户ID (null表示系统预设角色)
    user_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    
    def __repr__(self) -> str:
        return f"<Role(id={self.id}, name={self.name})>"
