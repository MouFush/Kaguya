"""
计费与配额系统模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, Text, Numeric, ForeignKey, JSON, Enum, DateTime, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from datetime import datetime
from decimal import Decimal

from app.models.base import Base


class BillingStatus(str, enum.Enum):
    """账单状态"""
    PENDING = "pending"         # 待支付
    PAID = "paid"               # 已支付
    FAILED = "failed"           # 支付失败
    REFUNDED = "refunded"       # 已退款
    CANCELLED = "cancelled"     # 已取消


class PaymentMethod(str, enum.Enum):
    """支付方式"""
    CREDIT_CARD = "credit_card"
    PAYPAL = "paypal"
    ALIPAY = "alipay"
    WECHAT = "wechat"
    BANK_TRANSFER = "bank_transfer"


class SubscriptionStatus(str, enum.Enum):
    """订阅状态"""
    ACTIVE = "active"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    PAST_DUE = "past_due"


class BillingPlan(Base):
    """计费套餐模型"""
    __tablename__ = "billing_plans"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    slug: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 价格
    price_monthly: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    price_yearly: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2), nullable=True)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    
    # 配额配置
    quota_config: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "max_users": 5,
    #     "max_chats": 100,
    #     "max_tokens_per_month": 100000,
    #     "max_storage_mb": 1000,
    #     "max_api_calls": 10000,
    #     "features": ["feature_a", "feature_b"]
    # }
    
    # 是否公开
    is_public: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # 排序
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    
    # 关系
    subscriptions: Mapped[List["Subscription"]] = relationship("Subscription", back_populates="plan")
    
    def __repr__(self) -> str:
        return f"<BillingPlan(id={self.id}, name={self.name}, price={self.price_monthly})>"


class Subscription(Base):
    """订阅模型"""
    __tablename__ = "subscriptions"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    plan_id: Mapped[str] = mapped_column(ForeignKey("billing_plans.id"), nullable=False)
    
    # 订阅状态
    status: Mapped[SubscriptionStatus] = mapped_column(Enum(SubscriptionStatus), default=SubscriptionStatus.ACTIVE)
    
    # 计费周期
    billing_cycle: Mapped[str] = mapped_column(String(10), default="monthly")  # monthly, yearly
    
    # 当前周期
    current_period_start: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    current_period_end: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    
    # 取消信息
    cancelled_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    cancellation_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 支付信息
    payment_method: Mapped[Optional[PaymentMethod]] = mapped_column(Enum(PaymentMethod), nullable=True)
    payment_method_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)  # 支付网关ID
    
    # 关系
    plan: Mapped["BillingPlan"] = relationship("BillingPlan", back_populates="subscriptions")
    invoices: Mapped[List["Invoice"]] = relationship("Invoice", back_populates="subscription")
    
    def __repr__(self) -> str:
        return f"<Subscription(id={self.id}, tenant={self.tenant_id}, status={self.status})>"


class Invoice(Base):
    """发票/账单模型"""
    __tablename__ = "invoices"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    subscription_id: Mapped[Optional[str]] = mapped_column(ForeignKey("subscriptions.id"), nullable=True)
    
    # 账单信息
    invoice_number: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    status: Mapped[BillingStatus] = mapped_column(Enum(BillingStatus), default=BillingStatus.PENDING)
    
    # 金额
    subtotal: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    tax_amount: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=Decimal("0.00"))
    discount_amount: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=Decimal("0.00"))
    total: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    
    # 时间
    invoice_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    due_date: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 支付信息
    payment_method: Mapped[Optional[PaymentMethod]] = mapped_column(Enum(PaymentMethod), nullable=True)
    payment_intent_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)  # Stripe等支付ID
    
    # 账单明细
    items: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    # [
    #     {
    #         "description": "Pro Plan - Monthly",
    #         "quantity": 1,
    #         "unit_price": 29.00,
    #         "amount": 29.00
    #     }
    # ]
    
    # 关系
    subscription: Mapped[Optional["Subscription"]] = relationship("Subscription", back_populates="invoices")
    
    def __repr__(self) -> str:
        return f"<Invoice(id={self.id}, number={self.invoice_number}, total={self.total})>"


class UsageRecord(Base):
    """使用记录模型 - 用于按量计费"""
    __tablename__ = "usage_records"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    user_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    
    # 使用类型
    usage_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # llm_tokens, storage, api_call, etc.
    
    # 使用量
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    unit: Mapped[str] = mapped_column(String(20), nullable=False)  # tokens, mb, requests
    
    # 费用
    cost: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 6), nullable=True)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    
    # 关联资源
    resource_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)  # chat, document, etc.
    resource_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    
    # 元数据
    metadata: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "model": "gpt-4",
    #     "prompt_tokens": 100,
    #     "completion_tokens": 50
    # }
    
    # 计费周期
    billing_period: Mapped[str] = mapped_column(String(7), nullable=False)  # YYYY-MM
    
    def __repr__(self) -> str:
        return f"<UsageRecord(tenant={self.tenant_id}, type={self.usage_type}, quantity={self.quantity})>"


class Coupon(Base):
    """优惠券模型"""
    __tablename__ = "coupons"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    code: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # 优惠类型
    discount_type: Mapped[str] = mapped_column(String(20), nullable=False)  # percentage, fixed_amount
    discount_value: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    
    # 限制条件
    min_purchase_amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2), nullable=True)
    max_discount_amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2), nullable=True)
    applicable_plans: Mapped[Optional[List[str]]] = mapped_column(JSON, nullable=True)  # 适用的套餐ID列表
    
    # 有效期
    starts_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    
    # 使用限制
    max_uses: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)  # 最大使用次数
    current_uses: Mapped[int] = mapped_column(Integer, default=0)
    max_uses_per_user: Mapped[int] = mapped_column(Integer, default=1)
    
    # 状态
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    
    def __repr__(self) -> str:
        return f"<Coupon(code={self.code}, discount={self.discount_value})>"


class Wallet(Base):
    """钱包/余额模型 - 预付费系统"""
    __tablename__ = "wallets"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False, unique=True)
    
    # 余额
    balance: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=Decimal("0.00"))
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    
    # 累计统计
    total_deposited: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=Decimal("0.00"))
    total_spent: Mapped[Decimal] = mapped_column(Numeric(10, 2), default=Decimal("0.00"))
    
    # 自动充值设置
    auto_recharge_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    auto_recharge_threshold: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2), nullable=True)
    auto_recharge_amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2), nullable=True)
    
    def __repr__(self) -> str:
        return f"<Wallet(tenant={self.tenant_id}, balance={self.balance})>"


class WalletTransaction(Base):
    """钱包交易记录"""
    __tablename__ = "wallet_transactions"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    wallet_id: Mapped[str] = mapped_column(ForeignKey("wallets.id"), nullable=False)
    
    # 交易类型
    transaction_type: Mapped[str] = mapped_column(String(20), nullable=False)
    # deposit, usage, refund, adjustment
    
    # 金额
    amount: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    
    # 余额变动后
    balance_after: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    
    # 描述
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    
    # 关联信息
    reference_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)  # invoice, usage_record
    reference_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    
    # 元数据
    metadata: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    
    def __repr__(self) -> str:
        return f"<WalletTransaction(wallet={self.wallet_id}, type={self.transaction_type}, amount={self.amount})>"
