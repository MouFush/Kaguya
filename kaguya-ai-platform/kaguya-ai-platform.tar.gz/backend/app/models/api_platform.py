"""
API开发者平台模型
包含API产品、版本、文档、沙箱、SDK、开发者应用
"""

from datetime import datetime
from typing import Optional, List, Dict, Any
from sqlalchemy import String, Text, ForeignKey, JSON, Integer, Boolean, Float, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum

from app.core.database import Base


class APIStatus(str, enum.Enum):
    DRAFT = "draft"           # 草稿
    BETA = "beta"             # 测试版
    STABLE = "stable"         # 稳定版
    DEPRECATED = "deprecated" # 已弃用
    RETIRED = "retired"       # 已停用


class APIMethod(str, enum.Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"


class AppStatus(str, enum.Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    REVOKED = "revoked"


class APIProduct(Base):
    """API产品"""
    __tablename__ = "api_products"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    slug: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    base_url: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[APIStatus] = mapped_column(Enum(APIStatus), default=APIStatus.DRAFT)
    category: Mapped[str] = mapped_column(String(50), nullable=False)
    tags: Mapped[List[str]] = mapped_column(JSON, default=list)
    pricing_tier: Mapped[str] = mapped_column(String(20), default="free")  # free, basic, pro, enterprise
    rate_limits: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    features: Mapped[List[str]] = mapped_column(JSON, default=list)
    changelog: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    versions: Mapped[List["APIVersion"]] = relationship("APIVersion", back_populates="product")
    endpoints: Mapped[List["APIEndpoint"]] = relationship("APIEndpoint", back_populates="product")


class APIVersion(Base):
    """API版本"""
    __tablename__ = "api_versions"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    product_id: Mapped[str] = mapped_column(ForeignKey("api_products.id"), nullable=False, index=True)
    version: Mapped[str] = mapped_column(String(20), nullable=False)
    status: Mapped[APIStatus] = mapped_column(Enum(APIStatus), default=APIStatus.DRAFT)
    release_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    deprecated_at: Mapped[Optional[datetime]] = mapped_column(nullable=True)
    sunset_date: Mapped[Optional[datetime]] = mapped_column(nullable=True)
    breaking_changes: Mapped[List[str]] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)
    
    # 关系
    product: Mapped["APIProduct"] = relationship("APIProduct", back_populates="versions")
    endpoints: Mapped[List["APIEndpoint"]] = relationship("APIEndpoint", back_populates="version")


class APIEndpoint(Base):
    """API端点"""
    __tablename__ = "api_endpoints"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    product_id: Mapped[str] = mapped_column(ForeignKey("api_products.id"), nullable=False, index=True)
    version_id: Mapped[str] = mapped_column(ForeignKey("api_versions.id"), nullable=False, index=True)
    path: Mapped[str] = mapped_column(String(255), nullable=False)
    method: Mapped[APIMethod] = mapped_column(Enum(APIMethod), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    summary: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    tags: Mapped[List[str]] = mapped_column(JSON, default=list)
    parameters: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    request_body: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    responses: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    examples: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    auth_required: Mapped[bool] = mapped_column(Boolean, default=True)
    scopes: Mapped[List[str]] = mapped_column(JSON, default=list)
    rate_limit_key: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    product: Mapped["APIProduct"] = relationship("APIProduct", back_populates="endpoints")
    version: Mapped["APIVersion"] = relationship("APIVersion", back_populates="endpoints")


class APIDocument(Base):
    """API文档"""
    __tablename__ = "api_documents"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    product_id: Mapped[str] = mapped_column(ForeignKey("api_products.id"), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    slug: Mapped[str] = mapped_column(String(100), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    content_type: Mapped[str] = mapped_column(String(20), default="markdown")  # markdown, html, openapi
    parent_id: Mapped[Optional[str]] = mapped_column(ForeignKey("api_documents.id"), nullable=True)
    order: Mapped[int] = mapped_column(Integer, default=0)
    is_published: Mapped[bool] = mapped_column(Boolean, default=False)
    metadata: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 关系
    children: Mapped[List["APIDocument"]] = relationship("APIDocument", backref="parent", remote_side=[id])


class SDKPackage(Base):
    """SDK包"""
    __tablename__ = "sdk_packages"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    product_id: Mapped[str] = mapped_column(ForeignKey("api_products.id"), nullable=False, index=True)
    language: Mapped[str] = mapped_column(String(20), nullable=False)  # python, javascript, go, java, etc.
    package_name: Mapped[str] = mapped_column(String(100), nullable=False)
    version: Mapped[str] = mapped_column(String(20), nullable=False)
    download_url: Mapped[str] = mapped_column(String(500), nullable=False)
    install_command: Mapped[str] = mapped_column(String(255), nullable=False)
    documentation_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    repository_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    release_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_latest: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)


class DeveloperApp(Base):
    """开发者应用"""
    __tablename__ = "developer_apps"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False, index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    client_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    client_secret_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[AppStatus] = mapped_column(Enum(AppStatus), default=AppStatus.ACTIVE)
    redirect_uris: Mapped[List[str]] = mapped_column(JSON, default=list)
    allowed_origins: Mapped[List[str]] = mapped_column(JSON, default=list)
    scopes: Mapped[List[str]] = mapped_column(JSON, default=list)
    api_products: Mapped[List[str]] = mapped_column(JSON, default=list)  # 订阅的API产品ID
    rate_limit_config: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    usage_quota: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    webhook_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    webhook_secret: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(default=datetime.utcnow, onupdate=datetime.utcnow)


class SandboxRequest(Base):
    """沙箱请求记录"""
    __tablename__ = "sandbox_requests"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    endpoint_id: Mapped[str] = mapped_column(ForeignKey("api_endpoints.id"), nullable=False, index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    request_method: Mapped[str] = mapped_column(String(10), nullable=False)
    request_url: Mapped[str] = mapped_column(String(500), nullable=False)
    request_headers: Mapped[Dict[str, str]] = mapped_column(JSON, default=dict)
    request_body: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    response_status: Mapped[int] = mapped_column(Integer, nullable=False)
    response_headers: Mapped[Dict[str, str]] = mapped_column(JSON, default=dict)
    response_body: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    latency_ms: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)


class SDKCodeSample(Base):
    """SDK代码示例"""
    __tablename__ = "sdk_code_samples"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    endpoint_id: Mapped[str] = mapped_column(ForeignKey("api_endpoints.id"), nullable=False, index=True)
    language: Mapped[str] = mapped_column(String(20), nullable=False)
    title: Mapped[str] = mapped_column(String(100), nullable=False)
    code: Mapped[str] = mapped_column(Text, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(default=datetime.utcnow, onupdate=datetime.utcnow)
