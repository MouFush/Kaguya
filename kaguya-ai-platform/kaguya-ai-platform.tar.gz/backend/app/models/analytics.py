"""
数据分析平台模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, ForeignKey, JSON, DateTime, Integer, Float, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from datetime import datetime

from app.models.base import Base


class MetricDefinition(Base):
    """指标定义"""
    __tablename__ = "metric_definitions"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(String(500), nullable=False)
    
    # 指标类型
    metric_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # counter, gauge, histogram, summary
    
    # 单位
    unit: Mapped[str] = mapped_column(String(20), nullable=False)
    
    # 聚合方式
    aggregation: Mapped[str] = mapped_column(String(20), default="sum")  # sum, avg, max, min, count
    
    # 是否启用
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class MetricValue(Base):
    """指标值"""
    __tablename__ = "metric_values"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    metric_id: Mapped[str] = mapped_column(ForeignKey("metric_definitions.id"), nullable=False)
    
    # 维度
    dimensions: Mapped[Dict[str, str]] = mapped_column(JSON, default=dict)
    # { "model": "gpt-4", "endpoint": "/api/chat" }
    
    # 值
    value: Mapped[float] = mapped_column(Float, nullable=False)
    
    # 时间戳
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    
    # 统计周期
    period: Mapped[str] = mapped_column(String(20), default="minute")  # minute, hour, day, month


class Dashboard(Base):
    """仪表板"""
    __tablename__ = "dashboards"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 基本信息
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    
    # 布局配置
    layout: Mapped[List[Dict[str, Any]]] = mapped_column(JSON, default=list)
    # [
    #     {
    #         "id": "widget_1",
    #         "type": "line_chart",
    #         "title": "Token Usage",
    #         "metric_id": "...",
    #         "x": 0, "y": 0, "w": 6, "h": 4,
    #         "config": { "time_range": "7d", "granularity": "hour" }
    #     }
    # ]
    
    # 是否默认
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # 共享设置
    is_shared: Mapped[bool] = mapped_column(Boolean, default=False)
    shared_with: Mapped[List[str]] = mapped_column(JSON, default=list)  # 用户ID列表


class Report(Base):
    """报告"""
    __tablename__ = "reports"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 基本信息
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    
    # 报告类型
    report_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # usage, cost, performance, audit
    
    # 配置
    config: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "time_range": "last_30_days",
    #     "metrics": ["token_usage", "api_calls"],
    #     "filters": { "model": "gpt-4" },
    #     "group_by": ["day", "user"]
    # }
    
    # 定时生成
    schedule: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)  # cron表达式
    
    # 接收人
    recipients: Mapped[List[str]] = mapped_column(JSON, default=list)
    
    # 最后生成时间
    last_generated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class AlertRule(Base):
    """告警规则"""
    __tablename__ = "alert_rules"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 基本信息
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    
    # 告警条件
    metric_id: Mapped[str] = mapped_column(ForeignKey("metric_definitions.id"), nullable=False)
    condition: Mapped[str] = mapped_column(String(20), nullable=False)  # gt, lt, eq, gte, lte
    threshold: Mapped[float] = mapped_column(Float, nullable=False)
    
    # 持续时间（分钟）
    duration: Mapped[int] = mapped_column(Integer, default=5)
    
    # 通知渠道
    notification_channels: Mapped[List[str]] = mapped_column(JSON, default=list)
    # ["email", "slack", "webhook"]
    
    # 通知配置
    notification_config: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "email": ["admin@example.com"],
    #     "slack_webhook": "https://hooks.slack.com/...",
    #     "webhook_url": "https://example.com/webhook"
    # }
    
    # 是否启用
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # 冷却时间（分钟）
    cooldown: Mapped[int] = mapped_column(Integer, default=60)
    
    # 最后触发时间
    last_triggered_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class AlertHistory(Base):
    """告警历史"""
    __tablename__ = "alert_histories"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    alert_rule_id: Mapped[str] = mapped_column(ForeignKey("alert_rules.id"), nullable=False)
    
    # 触发时的值
    metric_value: Mapped[float] = mapped_column(Float, nullable=False)
    threshold: Mapped[float] = mapped_column(Float, nullable=False)
    
    # 状态
    status: Mapped[str] = mapped_column(String(20), default="firing")  # firing, resolved
    
    # 时间
    fired_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 通知状态
    notification_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    notification_error: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)


class UsageSummary(Base):
    """使用汇总（预聚合数据）"""
    __tablename__ = "usage_summaries"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    
    # 统计周期
    period: Mapped[str] = mapped_column(String(20), nullable=False)  # day, week, month
    period_start: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    period_end: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    
    # 汇总数据
    summary_data: Mapped[Dict[str, Any]] = mapped_column(JSON, nullable=False)
    # {
    #     "total_tokens": 1000000,
    #     "total_cost": 25.50,
    #     "api_calls": 5000,
    #     "active_users": 50,
    #     "model_breakdown": {
    #         "gpt-4": { "tokens": 600000, "cost": 18.00 },
    #         "gpt-3.5": { "tokens": 400000, "cost": 7.50 }
    #     }
    # }
