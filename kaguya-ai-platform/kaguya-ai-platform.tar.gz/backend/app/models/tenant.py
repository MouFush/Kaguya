"""
多租户模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, Text, Boolean, Integer, ForeignKey, JSON, Enum, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from datetime import datetime

from app.models.base import Base


class TenantStatus(str, enum.Enum):
    """租户状态"""
    ACTIVE = "active"           # 活跃
    SUSPENDED = "suspended"     # 暂停
    TRIAL = "trial"             # 试用
    EXPIRED = "expired"         # 过期


class TenantPlan(str, enum.Enum):
    """租户套餐"""
    FREE = "free"               # 免费版
    BASIC = "basic"             # 基础版
    PRO = "pro"                 # 专业版
    ENTERPRISE = "enterprise"   # 企业版


class Tenant(Base):
    """租户模型"""
    __tablename__ = "tenants"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    slug: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)  # 唯一标识
    
    # 联系信息
    email: Mapped[str] = mapped_column(String(100), nullable=False)
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    
    # 套餐和状态
    plan: Mapped[TenantPlan] = mapped_column(Enum(TenantPlan), default=TenantPlan.FREE)
    status: Mapped[TenantStatus] = mapped_column(Enum(TenantStatus), default=TenantStatus.TRIAL)
    
    # 自定义域名
    custom_domain: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    
    # 品牌定制
    branding: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, default=dict)
    # {
    #     "logo": "https://...",
    #     "favicon": "https://...",
    #     "primary_color": "#667eea",
    #     "company_name": "..."
    # }
    
    # 配额配置
    quota_config: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "max_users": 5,
    #     "max_chats": 100,
    #     "max_tokens_per_month": 100000,
    #     "max_storage_mb": 1000
    # }
    
    # 当前使用量
    usage_stats: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    # {
    #     "users_count": 3,
    #     "chats_count": 50,
    #     "tokens_used_this_month": 50000,
    #     "storage_used_mb": 500
    # }
    
    # 试用信息
    trial_ends_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 订阅信息
    subscription_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    subscription_ends_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 数据库隔离策略
    db_schema: Mapped[str] = mapped_column(String(50), default="public")  # 多租户schema
    
    # 设置
    settings: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    
    # 关系
    members: Mapped[List["TenantMember"]] = relationship("TenantMember", back_populates="tenant", cascade="all, delete-orphan")
    invitations: Mapped[List["TenantInvitation"]] = relationship("TenantInvitation", back_populates="tenant", cascade="all, delete-orphan")
    
    def __repr__(self) -> str:
        return f"<Tenant(id={self.id}, name={self.name}, plan={self.plan})>"


class TenantRole(str, enum.Enum):
    """租户成员角色"""
    OWNER = "owner"             # 所有者
    ADMIN = "admin"             # 管理员
    MEMBER = "member"           # 成员
    VIEWER = "viewer"           # 查看者


class TenantMember(Base):
    """租户成员模型"""
    __tablename__ = "tenant_members"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 角色
    role: Mapped[TenantRole] = mapped_column(Enum(TenantRole), default=TenantRole.MEMBER)
    
    # 权限 (覆盖角色的细粒度权限)
    permissions: Mapped[Optional[List[str]]] = mapped_column(JSON, nullable=True)
    
    # 部门
    department: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    
    # 加入时间
    joined_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    
    # 关系
    tenant: Mapped["Tenant"] = relationship("Tenant", back_populates="members")
    user: Mapped["User"] = relationship("User")
    
    def __repr__(self) -> str:
        return f"<TenantMember(tenant={self.tenant_id}, user={self.user_id}, role={self.role})>"


class TenantInvitation(Base):
    """租户邀请模型"""
    __tablename__ = "tenant_invitations"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    
    # 邀请信息
    email: Mapped[str] = mapped_column(String(100), nullable=False)
    role: Mapped[TenantRole] = mapped_column(Enum(TenantRole), default=TenantRole.MEMBER)
    
    # 邀请人
    invited_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 邀请码
    token: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    
    # 过期时间
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    
    # 状态
    is_accepted: Mapped[bool] = mapped_column(Boolean, default=False)
    accepted_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 关系
    tenant: Mapped["Tenant"] = relationship("Tenant", back_populates="invitations")
    
    def __repr__(self) -> str:
        return f"<TenantInvitation(tenant={self.tenant_id}, email={self.email})>"


class TenantActivity(Base):
    """租户活动日志"""
    __tablename__ = "tenant_activities"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    user_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    
    # 活动类型
    activity_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # user_login, user_invited, chat_created, model_used, etc.
    
    # 活动详情
    details: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    
    # IP地址和用户代理
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    
    def __repr__(self) -> str:
        return f"<TenantActivity(tenant={self.tenant_id}, type={self.activity_type})>"
