"""
企业级安全功能模型
"""

from typing import List, Optional, Dict, Any
from sqlalchemy import String, Text, ForeignKey, JSON, Enum, DateTime, Boolean, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum
from datetime import datetime

from app.models.base import Base


class AuditAction(str, enum.Enum):
    """审计动作类型"""
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    LOGIN = "login"
    LOGOUT = "logout"
    EXPORT = "export"
    IMPORT = "import"
    PERMISSION_CHANGE = "permission_change"


class AuditLog(Base):
    """审计日志模型"""
    __tablename__ = "audit_logs"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    user_id: Mapped[Optional[str]] = mapped_column(ForeignKey("users.id"), nullable=True)
    
    # 操作信息
    action: Mapped[AuditAction] = mapped_column(Enum(AuditAction), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(50), nullable=False)  # chat, message, user, etc.
    resource_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    
    # 变更详情
    before_data: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    after_data: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    
    # 客户端信息
    ip_address: Mapped[str] = mapped_column(String(45), nullable=False)
    user_agent: Mapped[str] = mapped_column(String(500), nullable=False)
    session_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    
    # 结果
    success: Mapped[bool] = mapped_column(Boolean, default=True)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    def __repr__(self) -> str:
        return f"<AuditLog(action={self.action}, resource={self.resource_type})>"


class DataRetentionPolicy(Base):
    """数据保留策略"""
    __tablename__ = "data_retention_policies"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    
    # 策略名称
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # 数据类型
    data_type: Mapped[str] = mapped_column(String(50), nullable=False)  # chat, message, audit_log, etc.
    
    # 保留期限（天）
    retention_days: Mapped[int] = mapped_column(Integer, nullable=False)
    
    # 归档设置
    archive_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    archive_after_days: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    
    # 自动删除
    auto_delete: Mapped[bool] = mapped_column(Boolean, default=False)
    
    # 是否启用
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class APIKey(Base):
    """API密钥管理"""
    __tablename__ = "api_keys"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    
    # 密钥信息
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    key_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    key_prefix: Mapped[str] = mapped_column(String(10), nullable=False)  # 用于显示的前缀
    
    # 权限范围
    scopes: Mapped[List[str]] = mapped_column(JSON, default=list)  # ["chats:read", "chats:write"]
    
    # 限制
    rate_limit: Mapped[int] = mapped_column(Integer, default=1000)  # 每小时请求数
    allowed_ips: Mapped[Optional[List[str]]] = mapped_column(JSON, nullable=True)  # IP白名单
    
    # 有效期
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_used_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # 状态
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    revoked_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    revoked_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


class SSOProvider(Base):
    """SSO提供商配置"""
    __tablename__ = "sso_providers"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    
    # 提供商类型
    provider_type: Mapped[str] = mapped_column(String(20), nullable=False)  # saml, oauth2, oidc
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    
    # 配置
    config: Mapped[Dict[str, Any]] = mapped_column(JSON, nullable=False)
    # SAML: {entity_id, sso_url, certificate, ...}
    # OAuth2/OIDC: {client_id, client_secret, authorization_endpoint, token_endpoint, ...}
    
    # 映射配置
    attribute_mapping: Mapped[Dict[str, str]] = mapped_column(JSON, default=dict)
    # { "email": "user.email", "name": "user.name", "department": "user.dept" }
    
    # 是否启用
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # 强制SSO（禁止密码登录）
    enforce_sso: Mapped[bool] = mapped_column(Boolean, default=False)


class Permission(Base):
    """权限定义"""
    __tablename__ = "permissions"
    
    id: Mapped[str] = mapped_column(String(50), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    resource_type: Mapped[str] = mapped_column(String(50), nullable=False)
    action: Mapped[str] = mapped_column(String(50), nullable=False)


class RolePermission(Base):
    """角色权限关联"""
    __tablename__ = "role_permissions"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(ForeignKey("tenants.id"), nullable=False)
    role: Mapped[str] = mapped_column(String(50), nullable=False)  # owner, admin, member, viewer
    permission_id: Mapped[str] = mapped_column(ForeignKey("permissions.id"), nullable=False)
    
    # 是否允许
    granted: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # 条件（可选）
    conditions: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)
    # { "department": "engineering", "max_chats": 100 }
