"""
企业级安全功能API路由
包含审计日志、API密钥管理、SSO、权限管理
"""

from typing import List, Optional
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, desc, func
from pydantic import BaseModel, Field

from app.core.database import get_db
from app.core.security import get_current_user, require_permissions
from app.models import (
    User, AuditLog, APIKey, SSOProvider, Permission, RolePermission, AuditAction
)

router = APIRouter(prefix="/security", tags=["安全"])


# ============ 请求/响应模型 ============

class AuditLogResponse(BaseModel):
    id: str
    action: str
    resource_type: str
    resource_id: Optional[str]
    user_id: Optional[str]
    user_email: Optional[str]
    ip_address: Optional[str]
    user_agent: Optional[str]
    before_data: Optional[dict]
    after_data: Optional[dict]
    created_at: datetime
    
    class Config:
        from_attributes = True


class AuditLogListResponse(BaseModel):
    total: int
    items: List[AuditLogResponse]


class APIKeyCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    scopes: List[str] = Field(default_factory=list)
    rate_limit: int = Field(default=1000, ge=1, le=100000)
    expires_in_days: Optional[int] = Field(default=None, ge=1, le=365)


class APIKeyResponse(BaseModel):
    id: str
    name: str
    key_preview: str
    scopes: List[str]
    rate_limit: int
    is_active: bool
    expires_at: Optional[datetime]
    last_used_at: Optional[datetime]
    created_at: datetime
    
    class Config:
        from_attributes = True


class APIKeyCreateResponse(APIKeyResponse):
    full_key: str  # 仅创建时返回完整密钥


class SSOProviderCreate(BaseModel):
    name: str
    provider_type: str = Field(..., regex="^(oidc|saml|oauth2)$")
    config: dict
    is_active: bool = True


class SSOProviderResponse(BaseModel):
    id: str
    name: str
    provider_type: str
    config: dict
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class PermissionResponse(BaseModel):
    id: str
    code: str
    name: str
    description: Optional[str]
    resource_type: str
    action: str
    
    class Config:
        from_attributes = True


class RolePermissionAssign(BaseModel):
    role: str
    permission_codes: List[str]


# ============ 审计日志API ============

@router.get("/audit-logs", response_model=AuditLogListResponse)
async def list_audit_logs(
    action: Optional[AuditAction] = None,
    resource_type: Optional[str] = None,
    user_id: Optional[str] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("audit:read"))
):
    """查询审计日志"""
    query = select(AuditLog)
    
    # 构建过滤条件
    filters = []
    if action:
        filters.append(AuditLog.action == action)
    if resource_type:
        filters.append(AuditLog.resource_type == resource_type)
    if user_id:
        filters.append(AuditLog.user_id == user_id)
    if start_date:
        filters.append(AuditLog.created_at >= start_date)
    if end_date:
        filters.append(AuditLog.created_at <= end_date)
    
    if filters:
        query = query.where(and_(*filters))
    
    # 统计总数
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # 分页查询
    query = query.order_by(desc(AuditLog.created_at))
    query = query.offset((page - 1) * page_size).limit(page_size)
    
    result = await db.execute(query)
    logs = result.scalars().all()
    
    return AuditLogListResponse(total=total, items=logs)


@router.get("/audit-logs/{log_id}", response_model=AuditLogResponse)
async def get_audit_log(
    log_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("audit:read"))
):
    """获取审计日志详情"""
    log = await db.get(AuditLog, log_id)
    if not log:
        raise HTTPException(status_code=404, detail="审计日志不存在")
    return log


@router.get("/audit-logs/stats/summary")
async def get_audit_stats(
    days: int = Query(7, ge=1, le=90),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("audit:read"))
):
    """获取审计统计摘要"""
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # 按操作类型统计
    action_stats = await db.execute(
        select(AuditLog.action, func.count())
        .where(AuditLog.created_at >= start_date)
        .group_by(AuditLog.action)
    )
    
    # 按资源类型统计
    resource_stats = await db.execute(
        select(AuditLog.resource_type, func.count())
        .where(AuditLog.created_at >= start_date)
        .group_by(AuditLog.resource_type)
    )
    
    # 每日趋势
    daily_stats = await db.execute(
        select(
            func.date(AuditLog.created_at).label("date"),
            func.count().label("count")
        )
        .where(AuditLog.created_at >= start_date)
        .group_by(func.date(AuditLog.created_at))
        .order_by("date")
    )
    
    return {
        "period_days": days,
        "action_distribution": {action: count for action, count in action_stats},
        "resource_distribution": {resource: count for resource, count in resource_stats},
        "daily_trend": [{"date": str(date), "count": count} for date, count in daily_stats]
    }


# ============ API密钥管理API ============

@router.get("/api-keys", response_model=List[APIKeyResponse])
async def list_api_keys(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出用户的API密钥"""
    result = await db.execute(
        select(APIKey)
        .where(APIKey.user_id == current_user.id)
        .order_by(desc(APIKey.created_at))
    )
    return result.scalars().all()


@router.post("/api-keys", response_model=APIKeyCreateResponse)
async def create_api_key(
    data: APIKeyCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建新的API密钥"""
    import secrets
    import hashlib
    
    # 生成密钥
    raw_key = f"kag_{secrets.token_urlsafe(32)}"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    
    # 计算过期时间
    expires_at = None
    if data.expires_in_days:
        expires_at = datetime.utcnow() + timedelta(days=data.expires_in_days)
    
    api_key = APIKey(
        user_id=current_user.id,
        name=data.name,
        key_hash=key_hash,
        key_preview=f"{raw_key[:8]}...{raw_key[-4:]}",
        scopes=data.scopes,
        rate_limit=data.rate_limit,
        expires_at=expires_at
    )
    
    db.add(api_key)
    await db.commit()
    await db.refresh(api_key)
    
    # 返回完整密钥（仅这一次）
    response = APIKeyCreateResponse(
        **api_key.__dict__,
        full_key=raw_key
    )
    return response


@router.delete("/api-keys/{key_id}")
async def revoke_api_key(
    key_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """撤销API密钥"""
    api_key = await db.get(APIKey, key_id)
    if not api_key or api_key.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="API密钥不存在")
    
    api_key.is_active = False
    api_key.revoked_at = datetime.utcnow()
    await db.commit()
    
    return {"message": "API密钥已撤销"}


@router.post("/api-keys/{key_id}/regenerate")
async def regenerate_api_key(
    key_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """重新生成API密钥"""
    import secrets
    import hashlib
    
    api_key = await db.get(APIKey, key_id)
    if not api_key or api_key.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="API密钥不存在")
    
    # 生成新密钥
    raw_key = f"kag_{secrets.token_urlsafe(32)}"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    
    api_key.key_hash = key_hash
    api_key.key_preview = f"{raw_key[:8]}...{raw_key[-4:]}"
    api_key.updated_at = datetime.utcnow()
    await db.commit()
    
    return {"full_key": raw_key, "message": "API密钥已重新生成"}


# ============ SSO提供商管理API ============

@router.get("/sso-providers", response_model=List[SSOProviderResponse])
async def list_sso_providers(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("sso:read"))
):
    """列出SSO提供商"""
    result = await db.execute(
        select(SSOProvider).order_by(desc(SSOProvider.created_at))
    )
    return result.scalars().all()


@router.post("/sso-providers", response_model=SSOProviderResponse)
async def create_sso_provider(
    data: SSOProviderCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("sso:write"))
):
    """创建SSO提供商"""
    provider = SSOProvider(**data.dict())
    db.add(provider)
    await db.commit()
    await db.refresh(provider)
    return provider


@router.put("/sso-providers/{provider_id}", response_model=SSOProviderResponse)
async def update_sso_provider(
    provider_id: str,
    data: SSOProviderCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("sso:write"))
):
    """更新SSO提供商"""
    provider = await db.get(SSOProvider, provider_id)
    if not provider:
        raise HTTPException(status_code=404, detail="SSO提供商不存在")
    
    for key, value in data.dict().items():
        setattr(provider, key, value)
    
    provider.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(provider)
    return provider


@router.delete("/sso-providers/{provider_id}")
async def delete_sso_provider(
    provider_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("sso:write"))
):
    """删除SSO提供商"""
    provider = await db.get(SSOProvider, provider_id)
    if not provider:
        raise HTTPException(status_code=404, detail="SSO提供商不存在")
    
    await db.delete(provider)
    await db.commit()
    
    return {"message": "SSO提供商已删除"}


# ============ 权限管理API ============

@router.get("/permissions", response_model=List[PermissionResponse])
async def list_permissions(
    resource_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("permission:read"))
):
    """列出所有权限"""
    query = select(Permission)
    if resource_type:
        query = query.where(Permission.resource_type == resource_type)
    
    result = await db.execute(query.order_by(Permission.code))
    return result.scalars().all()


@router.get("/permissions/my")
async def get_my_permissions(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取当前用户的权限列表"""
    # 获取用户角色对应的权限
    result = await db.execute(
        select(Permission.code)
        .join(RolePermission)
        .where(RolePermission.role == current_user.role)
    )
    permissions = [p[0] for p in result.all()]
    
    return {
        "role": current_user.role,
        "permissions": permissions
    }


@router.post("/role-permissions")
async def assign_role_permissions(
    data: RolePermissionAssign,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("permission:write"))
):
    """为角色分配权限"""
    # 删除现有权限
    await db.execute(
        select(RolePermission).where(RolePermission.role == data.role)
    )
    
    # 添加新权限
    for code in data.permission_codes:
        permission = await db.execute(
            select(Permission).where(Permission.code == code)
        )
        if not permission.scalar_one_or_none():
            raise HTTPException(status_code=400, detail=f"权限不存在: {code}")
        
        role_perm = RolePermission(role=data.role, permission_code=code)
        db.add(role_perm)
    
    await db.commit()
    
    return {"message": f"已为角色 {data.role} 分配 {len(data.permission_codes)} 个权限"}


@router.get("/role-permissions/{role}")
async def get_role_permissions(
    role: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("permission:read"))
):
    """获取角色的权限列表"""
    result = await db.execute(
        select(Permission)
        .join(RolePermission)
        .where(RolePermission.role == role)
    )
    permissions = result.scalars().all()
    
    return {
        "role": role,
        "permissions": [PermissionResponse.from_orm(p) for p in permissions]
    }
