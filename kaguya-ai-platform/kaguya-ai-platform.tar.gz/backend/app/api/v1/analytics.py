"""
数据分析平台API路由
包含指标定义、仪表板、报告、告警
"""

from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, desc, func, between
from pydantic import BaseModel, Field

from app.core.database import get_db
from app.core.security import get_current_user, require_permissions
from app.models import (
    User, MetricDefinition, MetricDataPoint, Dashboard, Report,
    AlertRule, AlertNotification, UsageSummary, MetricType, AlertSeverity
)

router = APIRouter(prefix="/analytics", tags=["数据分析"])


# ============ 请求/响应模型 ============

class MetricDefinitionCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    metric_type: MetricType
    unit: Optional[str] = None
    aggregation: str = Field(default="sum", regex="^(sum|avg|count|min|max|last)$")
    retention_days: int = Field(default=90, ge=1, le=365)
    labels: List[str] = Field(default_factory=list)


class MetricDefinitionResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    metric_type: MetricType
    unit: Optional[str]
    aggregation: str
    retention_days: int
    labels: List[str]
    is_active: bool
    created_at: datetime
    
    class Config:
        from_attributes = True


class MetricDataPointCreate(BaseModel):
    metric_id: str
    value: float
    timestamp: Optional[datetime] = None
    labels: Dict[str, str] = Field(default_factory=dict)


class MetricDataPointResponse(BaseModel):
    id: str
    metric_id: str
    value: float
    timestamp: datetime
    labels: Dict[str, str]
    
    class Config:
        from_attributes = True


class MetricQueryResult(BaseModel):
    metric_id: str
    metric_name: str
    aggregation: str
    data_points: List[Dict[str, Any]]
    summary: Dict[str, float]


class DashboardCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    layout: List[Dict[str, Any]] = Field(default_factory=list)
    is_public: bool = False


class DashboardResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    description: Optional[str]
    layout: List[Dict[str, Any]]
    is_public: bool
    created_by: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class ReportCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    report_type: str = Field(..., regex="^(usage|performance|billing|custom)$")
    config: Dict[str, Any] = Field(default_factory=dict)
    schedule: Optional[str] = None  # cron表达式


class ReportResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    description: Optional[str]
    report_type: str
    config: Dict[str, Any]
    schedule: Optional[str]
    is_active: bool
    last_run_at: Optional[datetime]
    next_run_at: Optional[datetime]
    created_by: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class AlertRuleCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    metric_id: str
    condition: str = Field(..., regex="^(gt|lt|eq|gte|lte)$")
    threshold: float
    severity: AlertSeverity
    notification_channels: List[str] = Field(default_factory=list)
    cooldown_minutes: int = Field(default=60, ge=5, le=1440)


class AlertRuleResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    metric_id: str
    condition: str
    threshold: float
    severity: AlertSeverity
    notification_channels: List[str]
    cooldown_minutes: int
    is_active: bool
    last_triggered_at: Optional[datetime]
    created_at: datetime
    
    class Config:
        from_attributes = True


class UsageSummaryResponse(BaseModel):
    id: str
    tenant_id: str
    user_id: Optional[str]
    period_type: str
    period_start: datetime
    period_end: datetime
    metrics: Dict[str, Any]
    cost_data: Dict[str, Any]
    created_at: datetime
    
    class Config:
        from_attributes = True


# ============ 指标定义API ============

@router.get("/metrics", response_model=List[MetricDefinitionResponse])
async def list_metrics(
    metric_type: Optional[MetricType] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """列出指标定义"""
    query = select(MetricDefinition).where(MetricDefinition.is_active == True)
    if metric_type:
        query = query.where(MetricDefinition.metric_type == metric_type)
    
    result = await db.execute(query.order_by(MetricDefinition.name))
    return result.scalars().all()


@router.post("/metrics", response_model=MetricDefinitionResponse)
async def create_metric(
    data: MetricDefinitionCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """创建指标定义"""
    metric = MetricDefinition(**data.dict())
    db.add(metric)
    await db.commit()
    await db.refresh(metric)
    return metric


@router.put("/metrics/{metric_id}", response_model=MetricDefinitionResponse)
async def update_metric(
    metric_id: str,
    data: MetricDefinitionCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """更新指标定义"""
    metric = await db.get(MetricDefinition, metric_id)
    if not metric:
        raise HTTPException(status_code=404, detail="指标不存在")
    
    for key, value in data.dict().items():
        setattr(metric, key, value)
    
    await db.commit()
    await db.refresh(metric)
    return metric


@router.delete("/metrics/{metric_id}")
async def delete_metric(
    metric_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """删除指标定义"""
    metric = await db.get(MetricDefinition, metric_id)
    if not metric:
        raise HTTPException(status_code=404, detail="指标不存在")
    
    metric.is_active = False
    await db.commit()
    
    return {"message": "指标已删除"}


# ============ 指标数据API ============

@router.post("/metrics/data")
async def record_metric_data(
    data: MetricDataPointCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """记录指标数据点"""
    # 验证指标存在
    metric = await db.get(MetricDefinition, data.metric_id)
    if not metric:
        raise HTTPException(status_code=404, detail="指标不存在")
    
    data_point = MetricDataPoint(
        metric_id=data.metric_id,
        value=data.value,
        timestamp=data.timestamp or datetime.utcnow(),
        labels=data.labels
    )
    
    db.add(data_point)
    await db.commit()
    
    return {"message": "数据点已记录"}


@router.post("/metrics/data/batch")
async def record_metric_data_batch(
    data_points: List[MetricDataPointCreate],
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """批量记录指标数据点"""
    for data in data_points:
        data_point = MetricDataPoint(
            metric_id=data.metric_id,
            value=data.value,
            timestamp=data.timestamp or datetime.utcnow(),
            labels=data.labels
        )
        db.add(data_point)
    
    await db.commit()
    
    return {"message": f"已记录 {len(data_points)} 个数据点"}


@router.get("/metrics/{metric_id}/query")
async def query_metric_data(
    metric_id: str,
    start_time: datetime,
    end_time: datetime,
    aggregation: Optional[str] = None,
    interval: Optional[str] = None,  # 1m, 5m, 1h, 1d
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """查询指标数据"""
    metric = await db.get(MetricDefinition, metric_id)
    if not metric:
        raise HTTPException(status_code=404, detail="指标不存在")
    
    # 使用指定的聚合方式或默认方式
    agg_func = aggregation or metric.aggregation
    
    query = select(MetricDataPoint).where(
        and_(
            MetricDataPoint.metric_id == metric_id,
            MetricDataPoint.timestamp >= start_time,
            MetricDataPoint.timestamp <= end_time
        )
    ).order_by(MetricDataPoint.timestamp)
    
    result = await db.execute(query)
    points = result.scalars().all()
    
    # 计算汇总统计
    values = [p.value for p in points]
    summary = {
        "count": len(values),
        "sum": sum(values) if values else 0,
        "avg": sum(values) / len(values) if values else 0,
        "min": min(values) if values else 0,
        "max": max(values) if values else 0,
        "last": values[-1] if values else 0
    }
    
    # 按时间间隔聚合
    data_points = []
    if interval and points:
        from collections import defaultdict
        import pandas as pd
        
        # 转换为DataFrame进行时间序列聚合
        df = pd.DataFrame([
            {"timestamp": p.timestamp, "value": p.value, **p.labels}
            for p in points
        ])
        df.set_index("timestamp", inplace=True)
        
        # 重采样
        resampled = df.resample(interval).agg({
            "value": agg_func if agg_func in ["sum", "mean", "min", "max", "count"] else "sum"
        })
        
        for timestamp, row in resampled.iterrows():
            data_points.append({
                "timestamp": timestamp.isoformat(),
                "value": row["value"] if not pd.isna(row["value"]) else 0
            })
    else:
        data_points = [
            {"timestamp": p.timestamp.isoformat(), "value": p.value, "labels": p.labels}
            for p in points
        ]
    
    return MetricQueryResult(
        metric_id=metric_id,
        metric_name=metric.name,
        aggregation=agg_func,
        data_points=data_points,
        summary=summary
    )


# ============ 仪表板API ============

@router.get("/dashboards", response_model=List[DashboardResponse])
async def list_dashboards(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """列出仪表板"""
    result = await db.execute(
        select(Dashboard)
        .where(
            and_(
                Dashboard.tenant_id == current_user.tenant_id,
                Dashboard.is_public == True
            )
        )
        .order_by(desc(Dashboard.updated_at))
    )
    return result.scalars().all()


@router.post("/dashboards", response_model=DashboardResponse)
async def create_dashboard(
    data: DashboardCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """创建仪表板"""
    dashboard = Dashboard(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        **data.dict()
    )
    db.add(dashboard)
    await db.commit()
    await db.refresh(dashboard)
    return dashboard


@router.get("/dashboards/{dashboard_id}", response_model=DashboardResponse)
async def get_dashboard(
    dashboard_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """获取仪表板详情"""
    dashboard = await db.get(Dashboard, dashboard_id)
    if not dashboard:
        raise HTTPException(status_code=404, detail="仪表板不存在")
    
    if dashboard.tenant_id != current_user.tenant_id and not dashboard.is_public:
        raise HTTPException(status_code=403, detail="无权访问此仪表板")
    
    return dashboard


@router.put("/dashboards/{dashboard_id}", response_model=DashboardResponse)
async def update_dashboard(
    dashboard_id: str,
    data: DashboardCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """更新仪表板"""
    dashboard = await db.get(Dashboard, dashboard_id)
    if not dashboard:
        raise HTTPException(status_code=404, detail="仪表板不存在")
    
    if dashboard.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=403, detail="无权修改此仪表板")
    
    for key, value in data.dict().items():
        setattr(dashboard, key, value)
    
    dashboard.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(dashboard)
    return dashboard


@router.delete("/dashboards/{dashboard_id}")
async def delete_dashboard(
    dashboard_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """删除仪表板"""
    dashboard = await db.get(Dashboard, dashboard_id)
    if not dashboard:
        raise HTTPException(status_code=404, detail="仪表板不存在")
    
    if dashboard.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=403, detail="无权删除此仪表板")
    
    await db.delete(dashboard)
    await db.commit()
    
    return {"message": "仪表板已删除"}


# ============ 报告API ============

@router.get("/reports", response_model=List[ReportResponse])
async def list_reports(
    report_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """列出报告"""
    query = select(Report).where(Report.tenant_id == current_user.tenant_id)
    if report_type:
        query = query.where(Report.report_type == report_type)
    
    result = await db.execute(query.order_by(desc(Report.created_at)))
    return result.scalars().all()


@router.post("/reports", response_model=ReportResponse)
async def create_report(
    data: ReportCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """创建报告"""
    report = Report(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        **data.dict()
    )
    db.add(report)
    await db.commit()
    await db.refresh(report)
    return report


@router.post("/reports/{report_id}/generate")
async def generate_report(
    report_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """生成报告"""
    report = await db.get(Report, report_id)
    if not report or report.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="报告不存在")
    
    # 根据报告类型生成数据
    # 这里简化处理，实际应该根据config生成详细报告
    report.last_run_at = datetime.utcnow()
    
    if report.schedule:
        # 计算下次运行时间
        from croniter import croniter
        iter = croniter(report.schedule, datetime.utcnow())
        report.next_run_at = iter.get_next(datetime)
    
    await db.commit()
    
    return {
        "message": "报告生成成功",
        "report_id": report_id,
        "generated_at": report.last_run_at
    }


# ============ 告警规则API ============

@router.get("/alerts/rules", response_model=List[AlertRuleResponse])
async def list_alert_rules(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """列出告警规则"""
    result = await db.execute(
        select(AlertRule)
        .where(AlertRule.tenant_id == current_user.tenant_id)
        .order_by(desc(AlertRule.created_at))
    )
    return result.scalars().all()


@router.post("/alerts/rules", response_model=AlertRuleResponse)
async def create_alert_rule(
    data: AlertRuleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """创建告警规则"""
    rule = AlertRule(
        tenant_id=current_user.tenant_id,
        **data.dict()
    )
    db.add(rule)
    await db.commit()
    await db.refresh(rule)
    return rule


@router.put("/alerts/rules/{rule_id}", response_model=AlertRuleResponse)
async def update_alert_rule(
    rule_id: str,
    data: AlertRuleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """更新告警规则"""
    rule = await db.get(AlertRule, rule_id)
    if not rule or rule.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="告警规则不存在")
    
    for key, value in data.dict().items():
        setattr(rule, key, value)
    
    await db.commit()
    await db.refresh(rule)
    return rule


@router.delete("/alerts/rules/{rule_id}")
async def delete_alert_rule(
    rule_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:write"))
):
    """删除告警规则"""
    rule = await db.get(AlertRule, rule_id)
    if not rule or rule.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="告警规则不存在")
    
    await db.delete(rule)
    await db.commit()
    
    return {"message": "告警规则已删除"}


@router.get("/alerts/notifications")
async def list_alert_notifications(
    is_read: Optional[bool] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """列出告警通知"""
    query = select(AlertNotification).where(
        AlertNotification.tenant_id == current_user.tenant_id
    )
    
    if is_read is not None:
        query = query.where(AlertNotification.is_read == is_read)
    
    # 统计总数
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # 分页
    query = query.order_by(desc(AlertNotification.created_at))
    query = query.offset((page - 1) * page_size).limit(page_size)
    
    result = await db.execute(query)
    notifications = result.scalars().all()
    
    return {
        "total": total,
        "items": notifications
    }


@router.post("/alerts/notifications/{notification_id}/read")
async def mark_notification_read(
    notification_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """标记告警通知为已读"""
    notification = await db.get(AlertNotification, notification_id)
    if not notification or notification.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="通知不存在")
    
    notification.is_read = True
    notification.read_at = datetime.utcnow()
    await db.commit()
    
    return {"message": "已标记为已读"}


# ============ 使用统计API ============

@router.get("/usage/summary")
async def get_usage_summary(
    period_type: str = Query(..., regex="^(daily|weekly|monthly)$"),
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """获取使用统计摘要"""
    if not start_date:
        start_date = datetime.utcnow() - timedelta(days=30)
    if not end_date:
        end_date = datetime.utcnow()
    
    result = await db.execute(
        select(UsageSummary)
        .where(
            and_(
                UsageSummary.tenant_id == current_user.tenant_id,
                UsageSummary.period_type == period_type,
                UsageSummary.period_start >= start_date,
                UsageSummary.period_end <= end_date
            )
        )
        .order_by(UsageSummary.period_start)
    )
    
    summaries = result.scalars().all()
    
    # 汇总数据
    total_metrics = {}
    total_cost = 0
    
    for summary in summaries:
        for key, value in summary.metrics.items():
            if key not in total_metrics:
                total_metrics[key] = 0
            total_metrics[key] += value
        total_cost += summary.cost_data.get("total", 0)
    
    return {
        "period_type": period_type,
        "start_date": start_date,
        "end_date": end_date,
        "summaries": summaries,
        "totals": {
            "metrics": total_metrics,
            "cost": total_cost
        }
    }


@router.get("/usage/realtime")
async def get_realtime_usage(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("analytics:read"))
):
    """获取实时使用数据"""
    # 获取今日数据
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    
    # 这里简化处理，实际应该从缓存或实时数据源获取
    return {
        "timestamp": datetime.utcnow().isoformat(),
        "today": {
            "requests": 0,  # 从缓存获取
            "tokens": 0,
            "active_users": 0
        },
        "current_load": {
            "requests_per_minute": 0,
            "average_latency_ms": 0
        }
    }
