"""
团队协作功能API路由
包含工作空间、评论、实时会话、通知、集成
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query, status, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, desc, func
from pydantic import BaseModel, Field

from app.core.database import get_db
from app.core.security import get_current_user, require_permissions
from app.models import (
    User, Workspace, WorkspaceMember, Comment, RealTimeSession,
    Notification, Integration, WorkspaceRole, NotificationType
)

router = APIRouter(prefix="/collaboration", tags=["团队协作"])


# ============ 请求/响应模型 ============

class WorkspaceCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = Field(default="#1890ff", regex="^#[0-9A-Fa-f]{6}$")


class WorkspaceResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    description: Optional[str]
    icon: Optional[str]
    color: str
    created_by: str
    created_at: datetime
    updated_at: datetime
    member_count: int = 0
    
    class Config:
        from_attributes = True


class WorkspaceMemberCreate(BaseModel):
    user_id: str
    role: WorkspaceRole = WorkspaceRole.MEMBER


class WorkspaceMemberResponse(BaseModel):
    id: str
    workspace_id: str
    user_id: str
    role: WorkspaceRole
    joined_at: datetime
    user: Optional[Dict[str, Any]] = None
    
    class Config:
        from_attributes = True


class CommentCreate(BaseModel):
    content: str = Field(..., min_length=1, max_length=5000)
    parent_id: Optional[str] = None
    mentions: List[str] = Field(default_factory=list)


class CommentResponse(BaseModel):
    id: str
    workspace_id: str
    resource_type: str
    resource_id: str
    user_id: str
    content: str
    parent_id: Optional[str]
    mentions: List[str]
    is_resolved: bool
    resolved_at: Optional[datetime]
    resolved_by: Optional[str]
    created_at: datetime
    updated_at: datetime
    reply_count: int = 0
    user: Optional[Dict[str, Any]] = None
    
    class Config:
        from_attributes = True


class RealTimeSessionCreate(BaseModel):
    resource_type: str
    resource_id: str
    cursor_position: Optional[Dict[str, Any]] = None
    selection: Optional[Dict[str, Any]] = None


class RealTimeSessionResponse(BaseModel):
    id: str
    workspace_id: str
    user_id: str
    resource_type: str
    resource_id: str
    cursor_position: Optional[Dict[str, Any]]
    selection: Optional[Dict[str, Any]]
    is_active: bool
    joined_at: datetime
    last_activity_at: datetime
    user: Optional[Dict[str, Any]] = None
    
    class Config:
        from_attributes = True


class NotificationResponse(BaseModel):
    id: str
    user_id: str
    notification_type: NotificationType
    title: str
    content: str
    data: Dict[str, Any]
    is_read: bool
    read_at: Optional[datetime]
    created_at: datetime
    
    class Config:
        from_attributes = True


class IntegrationCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    integration_type: str
    config: Dict[str, Any] = Field(default_factory=dict)


class IntegrationResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    integration_type: str
    config: Dict[str, Any]
    is_active: bool
    last_sync_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


# ============ 工作空间API ============

@router.get("/workspaces", response_model=List[WorkspaceResponse])
async def list_workspaces(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出用户的工作空间"""
    result = await db.execute(
        select(Workspace, func.count(WorkspaceMember.id).label("member_count"))
        .join(WorkspaceMember, Workspace.id == WorkspaceMember.workspace_id)
        .where(
            and_(
                Workspace.tenant_id == current_user.tenant_id,
                WorkspaceMember.user_id == current_user.id
            )
        )
        .group_by(Workspace.id)
        .order_by(desc(Workspace.updated_at))
    )
    
    workspaces = []
    for workspace, member_count in result.all():
        ws_dict = workspace.__dict__.copy()
        ws_dict["member_count"] = member_count
        workspaces.append(WorkspaceResponse(**ws_dict))
    
    return workspaces


@router.post("/workspaces", response_model=WorkspaceResponse)
async def create_workspace(
    data: WorkspaceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建工作空间"""
    workspace = Workspace(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        **data.dict()
    )
    db.add(workspace)
    await db.flush()
    
    # 自动将创建者添加为管理员
    member = WorkspaceMember(
        workspace_id=workspace.id,
        user_id=current_user.id,
        role=WorkspaceRole.ADMIN
    )
    db.add(member)
    await db.commit()
    await db.refresh(workspace)
    
    return WorkspaceResponse(**workspace.__dict__, member_count=1)


@router.get("/workspaces/{workspace_id}", response_model=WorkspaceResponse)
async def get_workspace(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取工作空间详情"""
    # 检查用户是否是成员
    member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == current_user.id
            )
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="无权访问此工作空间")
    
    workspace = await db.get(Workspace, workspace_id)
    if not workspace:
        raise HTTPException(status_code=404, detail="工作空间不存在")
    
    # 获取成员数
    member_count = await db.scalar(
        select(func.count(WorkspaceMember.id)).where(
            WorkspaceMember.workspace_id == workspace_id
        )
    )
    
    return WorkspaceResponse(**workspace.__dict__, member_count=member_count)


@router.put("/workspaces/{workspace_id}", response_model=WorkspaceResponse)
async def update_workspace(
    workspace_id: str,
    data: WorkspaceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """更新工作空间"""
    # 检查权限
    member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == current_user.id,
                WorkspaceMember.role.in_([WorkspaceRole.ADMIN, WorkspaceRole.OWNER])
            )
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="无权修改此工作空间")
    
    workspace = await db.get(Workspace, workspace_id)
    if not workspace:
        raise HTTPException(status_code=404, detail="工作空间不存在")
    
    for key, value in data.dict().items():
        setattr(workspace, key, value)
    
    workspace.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(workspace)
    
    member_count = await db.scalar(
        select(func.count(WorkspaceMember.id)).where(
            WorkspaceMember.workspace_id == workspace_id
        )
    )
    
    return WorkspaceResponse(**workspace.__dict__, member_count=member_count)


@router.delete("/workspaces/{workspace_id}")
async def delete_workspace(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """删除工作空间"""
    # 检查权限（仅所有者）
    member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == current_user.id,
                WorkspaceMember.role == WorkspaceRole.OWNER
            )
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="无权删除此工作空间")
    
    workspace = await db.get(Workspace, workspace_id)
    if not workspace:
        raise HTTPException(status_code=404, detail="工作空间不存在")
    
    await db.delete(workspace)
    await db.commit()
    
    return {"message": "工作空间已删除"}


# ============ 工作空间成员API ============

@router.get("/workspaces/{workspace_id}/members", response_model=List[WorkspaceMemberResponse])
async def list_workspace_members(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出工作空间成员"""
    # 检查用户是否是成员
    member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == current_user.id
            )
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="无权访问此工作空间")
    
    result = await db.execute(
        select(WorkspaceMember, User)
        .join(User, WorkspaceMember.user_id == User.id)
        .where(WorkspaceMember.workspace_id == workspace_id)
        .order_by(WorkspaceMember.joined_at)
    )
    
    members = []
    for ws_member, user in result.all():
        member_dict = ws_member.__dict__.copy()
        member_dict["user"] = {
            "id": user.id,
            "email": user.email,
            "nickname": user.nickname,
            "avatar": user.avatar
        }
        members.append(WorkspaceMemberResponse(**member_dict))
    
    return members


@router.post("/workspaces/{workspace_id}/members", response_model=WorkspaceMemberResponse)
async def add_workspace_member(
    workspace_id: str,
    data: WorkspaceMemberCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """添加工作空间成员"""
    # 检查权限
    member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == current_user.id,
                WorkspaceMember.role.in_([WorkspaceRole.ADMIN, WorkspaceRole.OWNER])
            )
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="无权添加成员")
    
    # 检查用户是否已存在
    existing = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == data.user_id
            )
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="用户已是工作空间成员")
    
    ws_member = WorkspaceMember(
        workspace_id=workspace_id,
        user_id=data.user_id,
        role=data.role
    )
    db.add(ws_member)
    await db.commit()
    await db.refresh(ws_member)
    
    # 发送通知
    notification = Notification(
        user_id=data.user_id,
        notification_type=NotificationType.WORKSPACE,
        title="被添加到工作空间",
        content=f"你已被添加到工作空间",
        data={"workspace_id": workspace_id}
    )
    db.add(notification)
    await db.commit()
    
    return WorkspaceMemberResponse(**ws_member.__dict__)


@router.put("/workspaces/{workspace_id}/members/{user_id}")
async def update_member_role(
    workspace_id: str,
    user_id: str,
    role: WorkspaceRole,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """更新成员角色"""
    # 检查权限
    member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == current_user.id,
                WorkspaceMember.role == WorkspaceRole.OWNER
            )
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="无权修改成员角色")
    
    target_member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == user_id
            )
        )
    )
    ws_member = target_member.scalar_one_or_none()
    if not ws_member:
        raise HTTPException(status_code=404, detail="成员不存在")
    
    ws_member.role = role
    await db.commit()
    
    return {"message": "成员角色已更新"}


@router.delete("/workspaces/{workspace_id}/members/{user_id}")
async def remove_workspace_member(
    workspace_id: str,
    user_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """移除工作空间成员"""
    # 检查权限
    member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == current_user.id,
                WorkspaceMember.role.in_([WorkspaceRole.ADMIN, WorkspaceRole.OWNER])
            )
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="无权移除成员")
    
    target_member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == user_id
            )
        )
    )
    ws_member = target_member.scalar_one_or_none()
    if not ws_member:
        raise HTTPException(status_code=404, detail="成员不存在")
    
    await db.delete(ws_member)
    await db.commit()
    
    return {"message": "成员已移除"}


# ============ 评论API ============

@router.get("/workspaces/{workspace_id}/comments", response_model=List[CommentResponse])
async def list_comments(
    workspace_id: str,
    resource_type: Optional[str] = None,
    resource_id: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出评论"""
    # 检查权限
    member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == current_user.id
            )
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="无权访问此工作空间")
    
    query = select(Comment).where(
        and_(
            Comment.workspace_id == workspace_id,
            Comment.parent_id == None  # 只获取顶级评论
        )
    )
    
    if resource_type:
        query = query.where(Comment.resource_type == resource_type)
    if resource_id:
        query = query.where(Comment.resource_id == resource_id)
    
    # 统计总数
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # 分页
    query = query.order_by(desc(Comment.created_at))
    query = query.offset((page - 1) * page_size).limit(page_size)
    
    result = await db.execute(query)
    comments = result.scalars().all()
    
    # 获取回复数
    comment_list = []
    for comment in comments:
        reply_count = await db.scalar(
            select(func.count(Comment.id)).where(Comment.parent_id == comment.id)
        )
        comment_dict = comment.__dict__.copy()
        comment_dict["reply_count"] = reply_count
        comment_list.append(CommentResponse(**comment_dict))
    
    return comment_list


@router.post("/workspaces/{workspace_id}/comments", response_model=CommentResponse)
async def create_comment(
    workspace_id: str,
    resource_type: str,
    resource_id: str,
    data: CommentCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建评论"""
    # 检查权限
    member = await db.execute(
        select(WorkspaceMember).where(
            and_(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.user_id == current_user.id
            )
        )
    )
    if not member.scalar_one_or_none():
        raise HTTPException(status_code=403, detail="无权在此工作空间发表评论")
    
    comment = Comment(
        workspace_id=workspace_id,
        resource_type=resource_type,
        resource_id=resource_id,
        user_id=current_user.id,
        **data.dict()
    )
    db.add(comment)
    await db.commit()
    await db.refresh(comment)
    
    # 通知被提及的用户
    for mentioned_user_id in data.mentions:
        notification = Notification(
            user_id=mentioned_user_id,
            notification_type=NotificationType.MENTION,
            title="有人在评论中提到了你",
            content=f"{current_user.nickname or current_user.email} 在评论中提到了你",
            data={
                "comment_id": comment.id,
                "workspace_id": workspace_id
            }
        )
        db.add(notification)
    
    await db.commit()
    
    return CommentResponse(**comment.__dict__)


@router.put("/comments/{comment_id}/resolve")
async def resolve_comment(
    comment_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """解决评论"""
    comment = await db.get(Comment, comment_id)
    if not comment:
        raise HTTPException(status_code=404, detail="评论不存在")
    
    comment.is_resolved = True
    comment.resolved_at = datetime.utcnow()
    comment.resolved_by = current_user.id
    await db.commit()
    
    return {"message": "评论已解决"}


# ============ 通知API ============

@router.get("/notifications", response_model=List[NotificationResponse])
async def list_notifications(
    is_read: Optional[bool] = None,
    notification_type: Optional[NotificationType] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出通知"""
    query = select(Notification).where(Notification.user_id == current_user.id)
    
    if is_read is not None:
        query = query.where(Notification.is_read == is_read)
    if notification_type:
        query = query.where(Notification.notification_type == notification_type)
    
    # 统计总数
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # 分页
    query = query.order_by(desc(Notification.created_at))
    query = query.offset((page - 1) * page_size).limit(page_size)
    
    result = await db.execute(query)
    notifications = result.scalars().all()
    
    return {
        "total": total,
        "items": notifications
    }


@router.get("/notifications/unread-count")
async def get_unread_notification_count(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取未读通知数量"""
    count = await db.scalar(
        select(func.count(Notification.id)).where(
            and_(
                Notification.user_id == current_user.id,
                Notification.is_read == False
            )
        )
    )
    
    return {"unread_count": count}


@router.post("/notifications/{notification_id}/read")
async def mark_notification_read(
    notification_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """标记通知为已读"""
    notification = await db.get(Notification, notification_id)
    if not notification or notification.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="通知不存在")
    
    notification.is_read = True
    notification.read_at = datetime.utcnow()
    await db.commit()
    
    return {"message": "已标记为已读"}


@router.post("/notifications/read-all")
async def mark_all_notifications_read(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """标记所有通知为已读"""
    await db.execute(
        select(Notification).where(
            and_(
                Notification.user_id == current_user.id,
                Notification.is_read == False
            )
        )
    )
    
    # 批量更新
    from sqlalchemy import update
    await db.execute(
        update(Notification)
        .where(
            and_(
                Notification.user_id == current_user.id,
                Notification.is_read == False
            )
        )
        .values(is_read=True, read_at=datetime.utcnow())
    )
    await db.commit()
    
    return {"message": "所有通知已标记为已读"}


# ============ 集成API ============

@router.get("/integrations", response_model=List[IntegrationResponse])
async def list_integrations(
    integration_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("integration:read"))
):
    """列出集成"""
    query = select(Integration).where(Integration.tenant_id == current_user.tenant_id)
    if integration_type:
        query = query.where(Integration.integration_type == integration_type)
    
    result = await db.execute(query.order_by(desc(Integration.created_at)))
    return result.scalars().all()


@router.post("/integrations", response_model=IntegrationResponse)
async def create_integration(
    data: IntegrationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("integration:write"))
):
    """创建集成"""
    integration = Integration(
        tenant_id=current_user.tenant_id,
        **data.dict()
    )
    db.add(integration)
    await db.commit()
    await db.refresh(integration)
    return integration


@router.put("/integrations/{integration_id}", response_model=IntegrationResponse)
async def update_integration(
    integration_id: str,
    data: IntegrationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("integration:write"))
):
    """更新集成"""
    integration = await db.get(Integration, integration_id)
    if not integration or integration.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="集成不存在")
    
    for key, value in data.dict().items():
        setattr(integration, key, value)
    
    integration.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(integration)
    return integration


@router.delete("/integrations/{integration_id}")
async def delete_integration(
    integration_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("integration:write"))
):
    """删除集成"""
    integration = await db.get(Integration, integration_id)
    if not integration or integration.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="集成不存在")
    
    await db.delete(integration)
    await db.commit()
    
    return {"message": "集成已删除"}


@router.post("/integrations/{integration_id}/sync")
async def sync_integration(
    integration_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("integration:write"))
):
    """同步集成数据"""
    integration = await db.get(Integration, integration_id)
    if not integration or integration.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="集成不存在")
    
    # 这里应该调用实际的同步逻辑
    integration.last_sync_at = datetime.utcnow()
    await db.commit()
    
    return {"message": "同步已开始", "synced_at": integration.last_sync_at}


# ============ WebSocket实时协作 ============

@router.websocket("/ws/workspace/{workspace_id}")
async def workspace_websocket(
    websocket: WebSocket,
    workspace_id: str,
    token: str,
    db: AsyncSession = Depends(get_db)
):
    """工作空间实时协作WebSocket"""
    await websocket.accept()
    
    try:
        # 验证token并获取用户
        from app.core.security import verify_token
        payload = verify_token(token)
        user_id = payload.get("sub")
        
        if not user_id:
            await websocket.close(code=4001, reason="无效的token")
            return
        
        # 检查用户是否是工作空间成员
        member = await db.execute(
            select(WorkspaceMember).where(
                and_(
                    WorkspaceMember.workspace_id == workspace_id,
                    WorkspaceMember.user_id == user_id
                )
            )
        )
        if not member.scalar_one_or_none():
            await websocket.close(code=4003, reason="无权访问此工作空间")
            return
        
        # 创建实时会话
        session = RealTimeSession(
            workspace_id=workspace_id,
            user_id=user_id,
            resource_type="workspace",
            resource_id=workspace_id
        )
        db.add(session)
        await db.commit()
        
        try:
            while True:
                data = await websocket.receive_json()
                
                # 处理不同类型的消息
                msg_type = data.get("type")
                
                if msg_type == "cursor":
                    # 更新光标位置
                    session.cursor_position = data.get("position")
                    session.last_activity_at = datetime.utcnow()
                    await db.commit()
                    
                    # 广播给其他用户
                    await websocket.broadcast({
                        "type": "cursor",
                        "user_id": user_id,
                        "position": data.get("position")
                    })
                
                elif msg_type == "selection":
                    # 更新选区
                    session.selection = data.get("selection")
                    session.last_activity_at = datetime.utcnow()
                    await db.commit()
                
                elif msg_type == "typing":
                    # 用户正在输入
                    await websocket.broadcast({
                        "type": "typing",
                        "user_id": user_id,
                        "resource_id": data.get("resource_id")
                    })
                
                elif msg_type == "ping":
                    await websocket.send_json({"type": "pong"})
        
        except WebSocketDisconnect:
            session.is_active = False
            await db.commit()
    
    except Exception as e:
        await websocket.close(code=4000, reason=str(e))
