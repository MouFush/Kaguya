"""
模型管理系统API路由
包含AI模型、部署、微调、评估、A/B测试、提示词模板
"""

from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, desc, func
from pydantic import BaseModel, Field

from app.core.database import get_db
from app.core.security import get_current_user, require_permissions
from app.models import (
    User, AIModel, ModelDeployment, FineTuningJob, ModelEvaluation,
    ABTest, PromptTemplate, ModelProvider, ModelStatus, DeploymentStatus, JobStatus
)

router = APIRouter(prefix="/models", tags=["模型管理"])


# ============ 请求/响应模型 ============

class AIModelCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    provider: ModelProvider
    model_id: str = Field(..., min_length=1, max_length=100)
    version: str = Field(default="1.0.0")
    capabilities: List[str] = Field(default_factory=list)
    max_tokens: int = Field(default=4096, ge=1)
    context_window: int = Field(default=8192, ge=1)
    pricing: Dict[str, Any] = Field(default_factory=dict)
    config: Dict[str, Any] = Field(default_factory=dict)


class AIModelResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    description: Optional[str]
    provider: ModelProvider
    model_id: str
    version: str
    capabilities: List[str]
    max_tokens: int
    context_window: int
    pricing: Dict[str, Any]
    config: Dict[str, Any]
    status: ModelStatus
    is_public: bool
    created_by: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class ModelDeploymentCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    model_id: str
    endpoint_config: Dict[str, Any] = Field(default_factory=dict)
    scaling_config: Dict[str, Any] = Field(default_factory=dict)


class ModelDeploymentResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    model_id: str
    status: DeploymentStatus
    endpoint_url: Optional[str]
    endpoint_config: Dict[str, Any]
    scaling_config: Dict[str, Any]
    current_instances: int
    request_count: int
    error_count: int
    avg_latency_ms: float
    deployed_at: Optional[datetime]
    created_by: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class FineTuningJobCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    base_model_id: str
    dataset_id: str
    config: Dict[str, Any] = Field(default_factory=dict)
    hyperparameters: Dict[str, Any] = Field(default_factory=dict)


class FineTuningJobResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    base_model_id: str
    dataset_id: str
    status: JobStatus
    progress: float
    config: Dict[str, Any]
    hyperparameters: Dict[str, Any]
    metrics: Dict[str, Any]
    output_model_id: Optional[str]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_by: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class ModelEvaluationCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    model_id: str
    dataset_id: str
    metrics: List[str] = Field(default_factory=list)
    config: Dict[str, Any] = Field(default_factory=dict)


class ModelEvaluationResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    model_id: str
    dataset_id: str
    status: JobStatus
    metrics: List[str]
    results: Dict[str, Any]
    config: Dict[str, Any]
    overall_score: Optional[float]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_by: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class ABTestCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    control_model_id: str
    treatment_model_id: str
    traffic_split: Dict[str, float] = Field(default_factory=lambda: {"control": 0.5, "treatment": 0.5})
    metrics: List[str] = Field(default_factory=list)
    duration_days: int = Field(default=7, ge=1, le=30)


class ABTestResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    description: Optional[str]
    status: str
    variants: List[Dict[str, Any]]
    traffic_split: Dict[str, float]
    metrics: List[str]
    results: Dict[str, Any]
    winning_variant: Optional[str]
    start_date: Optional[datetime]
    end_date: Optional[datetime]
    created_by: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class PromptTemplateCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    template: str = Field(..., min_length=1)
    variables: List[Dict[str, Any]] = Field(default_factory=list)
    examples: List[Dict[str, Any]] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)
    is_public: bool = False


class PromptTemplateResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    description: Optional[str]
    template: str
    variables: List[Dict[str, Any]]
    examples: List[Dict[str, Any]]
    tags: List[str]
    version: int
    is_public: bool
    usage_count: int
    created_by: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


# ============ AI模型API ============

@router.get("/ai-models", response_model=List[AIModelResponse])
async def list_ai_models(
    provider: Optional[ModelProvider] = None,
    status: Optional[ModelStatus] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """列出AI模型"""
    query = select(AIModel).where(
        and_(
            AIModel.tenant_id == current_user.tenant_id,
            AIModel.is_public == True
        )
    )
    
    if provider:
        query = query.where(AIModel.provider == provider)
    if status:
        query = query.where(AIModel.status == status)
    
    result = await db.execute(query.order_by(desc(AIModel.created_at)))
    return result.scalars().all()


@router.post("/ai-models", response_model=AIModelResponse)
async def create_ai_model(
    data: AIModelCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """创建AI模型"""
    model = AIModel(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        **data.dict()
    )
    db.add(model)
    await db.commit()
    await db.refresh(model)
    return model


@router.get("/ai-models/{model_id}", response_model=AIModelResponse)
async def get_ai_model(
    model_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """获取AI模型详情"""
    model = await db.get(AIModel, model_id)
    if not model or (model.tenant_id != current_user.tenant_id and not model.is_public):
        raise HTTPException(status_code=404, detail="模型不存在")
    return model


@router.put("/ai-models/{model_id}", response_model=AIModelResponse)
async def update_ai_model(
    model_id: str,
    data: AIModelCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """更新AI模型"""
    model = await db.get(AIModel, model_id)
    if not model or model.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="模型不存在")
    
    for key, value in data.dict().items():
        setattr(model, key, value)
    
    model.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(model)
    return model


@router.delete("/ai-models/{model_id}")
async def delete_ai_model(
    model_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """删除AI模型"""
    model = await db.get(AIModel, model_id)
    if not model or model.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="模型不存在")
    
    model.status = ModelStatus.DEPRECATED
    await db.commit()
    
    return {"message": "模型已标记为废弃"}


# ============ 模型部署API ============

@router.get("/deployments", response_model=List[ModelDeploymentResponse])
async def list_deployments(
    status: Optional[DeploymentStatus] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """列出模型部署"""
    query = select(ModelDeployment).where(
        ModelDeployment.tenant_id == current_user.tenant_id
    )
    
    if status:
        query = query.where(ModelDeployment.status == status)
    
    result = await db.execute(query.order_by(desc(ModelDeployment.created_at)))
    return result.scalars().all()


@router.post("/deployments", response_model=ModelDeploymentResponse)
async def create_deployment(
    data: ModelDeploymentCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """创建模型部署"""
    # 验证模型存在
    model = await db.get(AIModel, data.model_id)
    if not model or model.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="模型不存在")
    
    deployment = ModelDeployment(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        **data.dict()
    )
    db.add(deployment)
    await db.commit()
    await db.refresh(deployment)
    return deployment


@router.post("/deployments/{deployment_id}/deploy")
async def deploy_model(
    deployment_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """部署模型"""
    deployment = await db.get(ModelDeployment, deployment_id)
    if not deployment or deployment.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="部署不存在")
    
    # 这里应该调用实际的部署逻辑
    deployment.status = DeploymentStatus.DEPLOYING
    await db.commit()
    
    # 模拟部署完成
    deployment.status = DeploymentStatus.RUNNING
    deployment.deployed_at = datetime.utcnow()
    deployment.endpoint_url = f"https://api.kaguya.ai/v1/models/{deployment.id}/infer"
    await db.commit()
    
    return {"message": "模型部署成功", "endpoint": deployment.endpoint_url}


@router.post("/deployments/{deployment_id}/scale")
async def scale_deployment(
    deployment_id: str,
    min_instances: int,
    max_instances: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """扩缩容部署"""
    deployment = await db.get(ModelDeployment, deployment_id)
    if not deployment or deployment.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="部署不存在")
    
    deployment.scaling_config["min_instances"] = min_instances
    deployment.scaling_config["max_instances"] = max_instances
    await db.commit()
    
    return {"message": "扩缩容配置已更新"}


@router.delete("/deployments/{deployment_id}")
async def delete_deployment(
    deployment_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """删除部署"""
    deployment = await db.get(ModelDeployment, deployment_id)
    if not deployment or deployment.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="部署不存在")
    
    deployment.status = DeploymentStatus.TERMINATED
    await db.commit()
    
    return {"message": "部署已终止"}


# ============ 微调任务API ============

@router.get("/fine-tuning", response_model=List[FineTuningJobResponse])
async def list_fine_tuning_jobs(
    status: Optional[JobStatus] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """列出微调任务"""
    query = select(FineTuningJob).where(
        FineTuningJob.tenant_id == current_user.tenant_id
    )
    
    if status:
        query = query.where(FineTuningJob.status == status)
    
    result = await db.execute(query.order_by(desc(FineTuningJob.created_at)))
    return result.scalars().all()


@router.post("/fine-tuning", response_model=FineTuningJobResponse)
async def create_fine_tuning_job(
    data: FineTuningJobCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """创建微调任务"""
    # 验证基础模型存在
    model = await db.get(AIModel, data.base_model_id)
    if not model or model.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="基础模型不存在")
    
    job = FineTuningJob(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        status=JobStatus.PENDING,
        **data.dict()
    )
    db.add(job)
    await db.commit()
    await db.refresh(job)
    return job


@router.post("/fine-tuning/{job_id}/start")
async def start_fine_tuning_job(
    job_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """启动微调任务"""
    job = await db.get(FineTuningJob, job_id)
    if not job or job.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="任务不存在")
    
    job.status = JobStatus.RUNNING
    job.started_at = datetime.utcnow()
    await db.commit()
    
    return {"message": "微调任务已启动"}


@router.get("/fine-tuning/{job_id}/progress")
async def get_fine_tuning_progress(
    job_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """获取微调任务进度"""
    job = await db.get(FineTuningJob, job_id)
    if not job or job.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="任务不存在")
    
    return {
        "job_id": job_id,
        "status": job.status,
        "progress": job.progress,
        "metrics": job.metrics,
        "started_at": job.started_at,
        "completed_at": job.completed_at
    }


@router.delete("/fine-tuning/{job_id}")
async def cancel_fine_tuning_job(
    job_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """取消微调任务"""
    job = await db.get(FineTuningJob, job_id)
    if not job or job.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="任务不存在")
    
    job.status = JobStatus.CANCELLED
    await db.commit()
    
    return {"message": "微调任务已取消"}


# ============ 模型评估API ============

@router.get("/evaluations", response_model=List[ModelEvaluationResponse])
async def list_evaluations(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """列出模型评估"""
    result = await db.execute(
        select(ModelEvaluation)
        .where(ModelEvaluation.tenant_id == current_user.tenant_id)
        .order_by(desc(ModelEvaluation.created_at))
    )
    return result.scalars().all()


@router.post("/evaluations", response_model=ModelEvaluationResponse)
async def create_evaluation(
    data: ModelEvaluationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """创建模型评估"""
    # 验证模型存在
    model = await db.get(AIModel, data.model_id)
    if not model or model.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="模型不存在")
    
    evaluation = ModelEvaluation(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        status=JobStatus.PENDING,
        **data.dict()
    )
    db.add(evaluation)
    await db.commit()
    await db.refresh(evaluation)
    return evaluation


@router.post("/evaluations/{evaluation_id}/start")
async def start_evaluation(
    evaluation_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """启动评估"""
    evaluation = await db.get(ModelEvaluation, evaluation_id)
    if not evaluation or evaluation.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="评估不存在")
    
    evaluation.status = JobStatus.RUNNING
    evaluation.started_at = datetime.utcnow()
    await db.commit()
    
    return {"message": "评估已启动"}


@router.get("/evaluations/{evaluation_id}/results")
async def get_evaluation_results(
    evaluation_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """获取评估结果"""
    evaluation = await db.get(ModelEvaluation, evaluation_id)
    if not evaluation or evaluation.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="评估不存在")
    
    return {
        "evaluation_id": evaluation_id,
        "status": evaluation.status,
        "metrics": evaluation.metrics,
        "results": evaluation.results,
        "overall_score": evaluation.overall_score,
        "completed_at": evaluation.completed_at
    }


# ============ A/B测试API ============

@router.get("/ab-tests", response_model=List[ABTestResponse])
async def list_ab_tests(
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """列出A/B测试"""
    query = select(ABTest).where(ABTest.tenant_id == current_user.tenant_id)
    if status:
        query = query.where(ABTest.status == status)
    
    result = await db.execute(query.order_by(desc(ABTest.created_at)))
    return result.scalars().all()


@router.post("/ab-tests", response_model=ABTestResponse)
async def create_ab_test(
    data: ABTestCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """创建A/B测试"""
    # 验证模型存在
    control_model = await db.get(AIModel, data.control_model_id)
    treatment_model = await db.get(AIModel, data.treatment_model_id)
    
    if not control_model or control_model.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="对照组模型不存在")
    if not treatment_model or treatment_model.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="实验组模型不存在")
    
    variants = [
        {"name": "control", "model_id": data.control_model_id, "traffic_percent": data.traffic_split["control"]},
        {"name": "treatment", "model_id": data.treatment_model_id, "traffic_percent": data.traffic_split["treatment"]}
    ]
    
    test = ABTest(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        status="draft",
        variants=variants,
        **data.dict()
    )
    db.add(test)
    await db.commit()
    await db.refresh(test)
    return test


@router.post("/ab-tests/{test_id}/start")
async def start_ab_test(
    test_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """启动A/B测试"""
    test = await db.get(ABTest, test_id)
    if not test or test.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="测试不存在")
    
    test.status = "running"
    test.start_date = datetime.utcnow()
    test.end_date = datetime.utcnow() + timedelta(days=test.duration_days)
    await db.commit()
    
    return {"message": "A/B测试已启动"}


@router.post("/ab-tests/{test_id}/stop")
async def stop_ab_test(
    test_id: str,
    winning_variant: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """停止A/B测试"""
    test = await db.get(ABTest, test_id)
    if not test or test.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="测试不存在")
    
    test.status = "completed"
    test.winning_variant = winning_variant
    await db.commit()
    
    return {"message": "A/B测试已停止", "winning_variant": winning_variant}


@router.get("/ab-tests/{test_id}/results")
async def get_ab_test_results(
    test_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """获取A/B测试结果"""
    test = await db.get(ABTest, test_id)
    if not test or test.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="测试不存在")
    
    return {
        "test_id": test_id,
        "status": test.status,
        "variants": test.variants,
        "results": test.results,
        "winning_variant": test.winning_variant,
        "start_date": test.start_date,
        "end_date": test.end_date
    }


# ============ 提示词模板API ============

@router.get("/prompt-templates", response_model=List[PromptTemplateResponse])
async def list_prompt_templates(
    tag: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """列出提示词模板"""
    query = select(PromptTemplate).where(
        and_(
            PromptTemplate.tenant_id == current_user.tenant_id,
            PromptTemplate.is_public == True
        )
    )
    
    if tag:
        query = query.where(PromptTemplate.tags.contains([tag]))
    
    result = await db.execute(query.order_by(desc(PromptTemplate.usage_count)))
    return result.scalars().all()


@router.post("/prompt-templates", response_model=PromptTemplateResponse)
async def create_prompt_template(
    data: PromptTemplateCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """创建提示词模板"""
    template = PromptTemplate(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        version=1,
        **data.dict()
    )
    db.add(template)
    await db.commit()
    await db.refresh(template)
    return template


@router.get("/prompt-templates/{template_id}", response_model=PromptTemplateResponse)
async def get_prompt_template(
    template_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """获取提示词模板详情"""
    template = await db.get(PromptTemplate, template_id)
    if not template or (template.tenant_id != current_user.tenant_id and not template.is_public):
        raise HTTPException(status_code=404, detail="模板不存在")
    
    # 增加使用计数
    template.usage_count += 1
    await db.commit()
    
    return template


@router.post("/prompt-templates/{template_id}/render")
async def render_prompt_template(
    template_id: str,
    variables: Dict[str, Any],
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:read"))
):
    """渲染提示词模板"""
    template = await db.get(PromptTemplate, template_id)
    if not template or (template.tenant_id != current_user.tenant_id and not template.is_public):
        raise HTTPException(status_code=404, detail="模板不存在")
    
    # 简单的模板渲染
    rendered = template.template
    for key, value in variables.items():
        rendered = rendered.replace(f"{{{key}}}", str(value))
    
    return {
        "template_id": template_id,
        "variables": variables,
        "rendered": rendered
    }


@router.put("/prompt-templates/{template_id}", response_model=PromptTemplateResponse)
async def update_prompt_template(
    template_id: str,
    data: PromptTemplateCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """更新提示词模板"""
    template = await db.get(PromptTemplate, template_id)
    if not template or template.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    for key, value in data.dict().items():
        setattr(template, key, value)
    
    template.version += 1
    template.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(template)
    return template


@router.delete("/prompt-templates/{template_id}")
async def delete_prompt_template(
    template_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("model:write"))
):
    """删除提示词模板"""
    template = await db.get(PromptTemplate, template_id)
    if not template or template.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="模板不存在")
    
    await db.delete(template)
    await db.commit()
    
    return {"message": "模板已删除"}
