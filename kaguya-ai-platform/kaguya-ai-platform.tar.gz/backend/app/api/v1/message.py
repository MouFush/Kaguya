"""
消息API路由 - 流式响应
"""

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import uuid
import json

from app.core.database import get_db
from app.api.v1.auth import get_current_user
from app.models.user import User
from app.models.chat import Chat, Message
from app.models.role import Role
from app.schemas.chat import MessageCreate
from app.services.llm import llm_gateway

router = APIRouter()


@router.post("/stream")
async def stream_message(
    chat_id: str,
    message_data: MessageCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """流式发送消息"""
    # 验证对话存在
    result = await db.execute(
        select(Chat).where(Chat.id == chat_id, Chat.user_id == current_user.id)
    )
    chat = result.scalar_one_or_none()
    
    if not chat:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="对话不存在"
        )
    
    # 保存用户消息
    user_message = Message(
        id=str(uuid.uuid4()),
        chat_id=chat_id,
        role="user",
        content=message_data.content,
        attachments=message_data.attachments
    )
    db.add(user_message)
    await db.commit()
    
    # 构建消息历史
    result = await db.execute(
        select(Message)
        .where(Message.chat_id == chat_id)
        .order_by(Message.created_at)
    )
    messages = result.scalars().all()
    
    # 构建LLM消息列表
    llm_messages = []
    
    # 添加系统提示词（如果有角色）
    if chat.role_id:
        result = await db.execute(
            select(Role).where(Role.id == chat.role_id)
        )
        role = result.scalar_one_or_none()
        if role:
            llm_messages.append({
                "role": "system",
                "content": role.system_prompt
            })
    
    # 添加历史消息
    for msg in messages:
        llm_messages.append({
            "role": msg.role,
            "content": msg.content
        })
    
    # 流式响应生成器
    async def generate():
        assistant_content = ""
        
        async for chunk in llm_gateway.chat_completion(
            messages=llm_messages,
            model=chat.model,
            temperature=chat.temperature,
            max_tokens=chat.max_tokens,
            stream=True
        ):
            assistant_content += chunk
            # SSE格式
            yield f"data: {json.dumps({'content': chunk})}\n\n"
        
        # 保存助手消息
        assistant_message = Message(
            id=str(uuid.uuid4()),
            chat_id=chat_id,
            role="assistant",
            content=assistant_content
        )
        db.add(assistant_message)
        await db.commit()
        
        # 发送结束标记
        yield f"data: {json.dumps({'done': True})}\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )


@router.post("/send")
async def send_message(
    chat_id: str,
    message_data: MessageCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """非流式发送消息"""
    # 验证对话存在
    result = await db.execute(
        select(Chat).where(Chat.id == chat_id, Chat.user_id == current_user.id)
    )
    chat = result.scalar_one_or_none()
    
    if not chat:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="对话不存在"
        )
    
    # 保存用户消息
    user_message = Message(
        id=str(uuid.uuid4()),
        chat_id=chat_id,
        role="user",
        content=message_data.content,
        attachments=message_data.attachments
    )
    db.add(user_message)
    await db.commit()
    
    # 构建消息历史
    result = await db.execute(
        select(Message)
        .where(Message.chat_id == chat_id)
        .order_by(Message.created_at)
    )
    messages = result.scalars().all()
    
    # 构建LLM消息列表
    llm_messages = []
    
    # 添加系统提示词
    if chat.role_id:
        result = await db.execute(
            select(Role).where(Role.id == chat.role_id)
        )
        role = result.scalar_one_or_none()
        if role:
            llm_messages.append({
                "role": "system",
                "content": role.system_prompt
            })
    
    # 添加历史消息
    for msg in messages:
        llm_messages.append({
            "role": msg.role,
            "content": msg.content
        })
    
    # 获取完整响应
    assistant_content = ""
    async for chunk in llm_gateway.chat_completion(
        messages=llm_messages,
        model=chat.model,
        temperature=chat.temperature,
        max_tokens=chat.max_tokens,
        stream=False
    ):
        assistant_content += chunk
    
    # 保存助手消息
    assistant_message = Message(
        id=str(uuid.uuid4()),
        chat_id=chat_id,
        role="assistant",
        content=assistant_content
    )
    db.add(assistant_message)
    await db.commit()
    await db.refresh(assistant_message)
    
    return assistant_message


@router.get("/models")
async def get_models():
    """获取可用模型列表"""
    models = await llm_gateway.get_all_models()
    return {"models": models}
