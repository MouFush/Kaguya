"""
API V1路由主文件
整合所有模块路由
"""

from fastapi import APIRouter

from app.api.v1 import (
    auth, chat, message, role, document, tenant, billing,
    plugin, workflow, security, analytics, collaboration,
    model_management, api_platform
)

api_router = APIRouter()

# ============ 基础模块 ============
# 认证路由
api_router.include_router(auth.router, prefix="/auth", tags=["认证"])

# 对话路由
api_router.include_router(chat.router, prefix="/chats", tags=["对话"])

# 消息路由
api_router.include_router(message.router, prefix="/messages", tags=["消息"])

# 角色路由
api_router.include_router(role.router, prefix="/roles", tags=["角色"])

# 文档路由
api_router.include_router(document.router, prefix="/documents", tags=["文档"])

# ============ 企业级SaaS模块 ============
# 多租户路由
api_router.include_router(tenant.router, prefix="/tenants", tags=["租户"])

# 计费路由
api_router.include_router(billing.router, prefix="/billing", tags=["计费"])

# ============ 扩展功能模块 ============
# 插件市场路由
api_router.include_router(plugin.router, prefix="/plugins", tags=["插件"])

# 工作流路由
api_router.include_router(workflow.router, prefix="/workflows", tags=["工作流"])

# ============ 企业级专业模块 ============
# 安全路由
api_router.include_router(security.router, prefix="/security", tags=["安全"])

# 数据分析路由
api_router.include_router(analytics.router, prefix="/analytics", tags=["数据分析"])

# 团队协作路由
api_router.include_router(collaboration.router, prefix="/collaboration", tags=["协作"])

# 模型管理路由
api_router.include_router(model_management.router, prefix="/models", tags=["模型管理"])

# API开发者平台路由
api_router.include_router(api_platform.router, prefix="/api-platform", tags=["API平台"])
