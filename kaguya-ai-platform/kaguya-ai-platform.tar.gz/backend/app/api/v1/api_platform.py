"""
API开发者平台路由
包含API产品、版本、文档、沙箱、SDK、开发者应用
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, desc, func
from pydantic import BaseModel, Field

from app.core.database import get_db
from app.core.security import get_current_user, require_permissions
from app.models import (
    User, APIProduct, APIVersion, APIEndpoint, APIDocument, SDKPackage,
    DeveloperApp, SandboxRequest, SDKCodeSample, APIStatus, APIMethod, AppStatus
)

router = APIRouter(prefix="/api-platform", tags=["API开发者平台"])


# ============ 请求/响应模型 ============

class APIProductCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    slug: str = Field(..., min_length=1, max_length=50)
    base_url: str = Field(..., min_length=1, max_length=255)
    category: str = Field(..., min_length=1, max_length=50)
    tags: List[str] = Field(default_factory=list)
    pricing_tier: str = Field(default="free")
    rate_limits: Dict[str, Any] = Field(default_factory=dict)
    features: List[str] = Field(default_factory=list)


class APIProductResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    description: Optional[str]
    slug: str
    base_url: str
    status: APIStatus
    category: str
    tags: List[str]
    pricing_tier: str
    rate_limits: Dict[str, Any]
    features: List[str]
    created_by: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class APIVersionCreate(BaseModel):
    version: str = Field(..., min_length=1, max_length=20)
    release_notes: Optional[str] = None
    is_default: bool = False
    breaking_changes: List[str] = Field(default_factory=list)


class APIVersionResponse(BaseModel):
    id: str
    product_id: str
    version: str
    status: APIStatus
    release_notes: Optional[str]
    is_default: bool
    deprecated_at: Optional[datetime]
    sunset_date: Optional[datetime]
    breaking_changes: List[str]
    created_at: datetime
    
    class Config:
        from_attributes = True


class APIEndpointCreate(BaseModel):
    path: str = Field(..., min_length=1, max_length=255)
    method: APIMethod
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    summary: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    parameters: List[Dict[str, Any]] = Field(default_factory=list)
    request_body: Optional[Dict[str, Any]] = None
    responses: Dict[str, Any] = Field(default_factory=dict)
    examples: List[Dict[str, Any]] = Field(default_factory=list)
    auth_required: bool = True
    scopes: List[str] = Field(default_factory=list)


class APIEndpointResponse(BaseModel):
    id: str
    product_id: str
    version_id: str
    path: str
    method: APIMethod
    name: str
    description: Optional[str]
    summary: Optional[str]
    tags: List[str]
    parameters: List[Dict[str, Any]]
    request_body: Optional[Dict[str, Any]]
    responses: Dict[str, Any]
    examples: List[Dict[str, Any]]
    auth_required: bool
    scopes: List[str]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class APIDocumentCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    slug: str = Field(..., min_length=1, max_length=100)
    content: str
    content_type: str = Field(default="markdown")
    parent_id: Optional[str] = None
    order: int = 0
    metadata: Dict[str, Any] = Field(default_factory=dict)


class APIDocumentResponse(BaseModel):
    id: str
    product_id: str
    title: str
    slug: str
    content: str
    content_type: str
    parent_id: Optional[str]
    order: int
    is_published: bool
    metadata: Dict[str, Any]
    created_by: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class SDKPackageCreate(BaseModel):
    language: str = Field(..., min_length=1, max_length=20)
    package_name: str = Field(..., min_length=1, max_length=100)
    version: str = Field(..., min_length=1, max_length=20)
    download_url: str = Field(..., min_length=1, max_length=500)
    install_command: str = Field(..., min_length=1, max_length=255)
    documentation_url: Optional[str] = None
    repository_url: Optional[str] = None
    release_notes: Optional[str] = None


class SDKPackageResponse(BaseModel):
    id: str
    product_id: str
    language: str
    package_name: str
    version: str
    download_url: str
    install_command: str
    documentation_url: Optional[str]
    repository_url: Optional[str]
    release_notes: Optional[str]
    is_latest: bool
    created_at: datetime
    
    class Config:
        from_attributes = True


class DeveloperAppCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    redirect_uris: List[str] = Field(default_factory=list)
    allowed_origins: List[str] = Field(default_factory=list)
    scopes: List[str] = Field(default_factory=list)
    api_products: List[str] = Field(default_factory=list)
    webhook_url: Optional[str] = None


class DeveloperAppResponse(BaseModel):
    id: str
    tenant_id: str
    user_id: str
    name: str
    description: Optional[str]
    client_id: str
    status: AppStatus
    redirect_uris: List[str]
    allowed_origins: List[str]
    scopes: List[str]
    api_products: List[str]
    webhook_url: Optional[str]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class SandboxRequestCreate(BaseModel):
    endpoint_id: str
    request_method: str
    request_url: str
    request_headers: Dict[str, str] = Field(default_factory=dict)
    request_body: Optional[str] = None


class SandboxRequestResponse(BaseModel):
    id: str
    endpoint_id: str
    user_id: str
    request_method: str
    request_url: str
    request_headers: Dict[str, str]
    request_body: Optional[str]
    response_status: int
    response_headers: Dict[str, str]
    response_body: Optional[str]
    latency_ms: int
    created_at: datetime
    
    class Config:
        from_attributes = True


# ============ API产品API ============

@router.get("/products", response_model=List[APIProductResponse])
async def list_api_products(
    category: Optional[str] = None,
    status: Optional[APIStatus] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出API产品"""
    query = select(APIProduct).where(APIProduct.tenant_id == current_user.tenant_id)
    
    if category:
        query = query.where(APIProduct.category == category)
    if status:
        query = query.where(APIProduct.status == status)
    
    result = await db.execute(query.order_by(desc(APIProduct.created_at)))
    return result.scalars().all()


@router.post("/products", response_model=APIProductResponse)
async def create_api_product(
    data: APIProductCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """创建API产品"""
    # 检查slug是否已存在
    existing = await db.execute(
        select(APIProduct).where(APIProduct.slug == data.slug)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="API标识已存在")
    
    product = APIProduct(
        tenant_id=current_user.tenant_id,
        created_by=current_user.id,
        **data.dict()
    )
    db.add(product)
    await db.commit()
    await db.refresh(product)
    return product


@router.get("/products/{product_id}", response_model=APIProductResponse)
async def get_api_product(
    product_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取API产品详情"""
    product = await db.get(APIProduct, product_id)
    if not product or product.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="API产品不存在")
    return product


@router.put("/products/{product_id}", response_model=APIProductResponse)
async def update_api_product(
    product_id: str,
    data: APIProductCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """更新API产品"""
    product = await db.get(APIProduct, product_id)
    if not product or product.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="API产品不存在")
    
    for key, value in data.dict().items():
        setattr(product, key, value)
    
    product.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(product)
    return product


@router.delete("/products/{product_id}")
async def delete_api_product(
    product_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """删除API产品"""
    product = await db.get(APIProduct, product_id)
    if not product or product.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="API产品不存在")
    
    product.status = APIStatus.RETIRED
    await db.commit()
    
    return {"message": "API产品已停用"}


# ============ API版本API ============

@router.get("/products/{product_id}/versions", response_model=List[APIVersionResponse])
async def list_api_versions(
    product_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出API版本"""
    product = await db.get(APIProduct, product_id)
    if not product or product.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="API产品不存在")
    
    result = await db.execute(
        select(APIVersion)
        .where(APIVersion.product_id == product_id)
        .order_by(desc(APIVersion.created_at))
    )
    return result.scalars().all()


@router.post("/products/{product_id}/versions", response_model=APIVersionResponse)
async def create_api_version(
    product_id: str,
    data: APIVersionCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """创建API版本"""
    product = await db.get(APIProduct, product_id)
    if not product or product.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="API产品不存在")
    
    version = APIVersion(product_id=product_id, **data.dict())
    db.add(version)
    await db.commit()
    await db.refresh(version)
    return version


@router.put("/versions/{version_id}/default")
async def set_default_version(
    version_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """设置默认版本"""
    version = await db.get(APIVersion, version_id)
    if not version:
        raise HTTPException(status_code=404, detail="版本不存在")
    
    # 取消其他默认版本
    await db.execute(
        select(APIVersion).where(
            and_(
                APIVersion.product_id == version.product_id,
                APIVersion.is_default == True
            )
        )
    )
    
    from sqlalchemy import update
    await db.execute(
        update(APIVersion)
        .where(APIVersion.product_id == version.product_id)
        .values(is_default=False)
    )
    
    version.is_default = True
    await db.commit()
    
    return {"message": "默认版本已设置"}


# ============ API端点API ============

@router.get("/versions/{version_id}/endpoints", response_model=List[APIEndpointResponse])
async def list_api_endpoints(
    version_id: str,
    tag: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出API端点"""
    version = await db.get(APIVersion, version_id)
    if not version:
        raise HTTPException(status_code=404, detail="版本不存在")
    
    query = select(APIEndpoint).where(APIEndpoint.version_id == version_id)
    if tag:
        query = query.where(APIEndpoint.tags.contains([tag]))
    
    result = await db.execute(query.order_by(APIEndpoint.path))
    return result.scalars().all()


@router.post("/versions/{version_id}/endpoints", response_model=APIEndpointResponse)
async def create_api_endpoint(
    version_id: str,
    data: APIEndpointCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """创建API端点"""
    version = await db.get(APIVersion, version_id)
    if not version:
        raise HTTPException(status_code=404, detail="版本不存在")
    
    endpoint = APIEndpoint(
        product_id=version.product_id,
        version_id=version_id,
        **data.dict()
    )
    db.add(endpoint)
    await db.commit()
    await db.refresh(endpoint)
    return endpoint


@router.get("/endpoints/{endpoint_id}", response_model=APIEndpointResponse)
async def get_api_endpoint(
    endpoint_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取API端点详情"""
    endpoint = await db.get(APIEndpoint, endpoint_id)
    if not endpoint:
        raise HTTPException(status_code=404, detail="端点不存在")
    return endpoint


@router.put("/endpoints/{endpoint_id}", response_model=APIEndpointResponse)
async def update_api_endpoint(
    endpoint_id: str,
    data: APIEndpointCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """更新API端点"""
    endpoint = await db.get(APIEndpoint, endpoint_id)
    if not endpoint:
        raise HTTPException(status_code=404, detail="端点不存在")
    
    for key, value in data.dict().items():
        setattr(endpoint, key, value)
    
    endpoint.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(endpoint)
    return endpoint


# ============ API文档API ============

@router.get("/products/{product_id}/documents", response_model=List[APIDocumentResponse])
async def list_api_documents(
    product_id: str,
    parent_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出API文档"""
    query = select(APIDocument).where(
        and_(
            APIDocument.product_id == product_id,
            APIDocument.is_published == True
        )
    )
    if parent_id:
        query = query.where(APIDocument.parent_id == parent_id)
    else:
        query = query.where(APIDocument.parent_id == None)
    
    result = await db.execute(query.order_by(APIDocument.order))
    return result.scalars().all()


@router.post("/products/{product_id}/documents", response_model=APIDocumentResponse)
async def create_api_document(
    product_id: str,
    data: APIDocumentCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """创建API文档"""
    document = APIDocument(
        product_id=product_id,
        created_by=current_user.id,
        **data.dict()
    )
    db.add(document)
    await db.commit()
    await db.refresh(document)
    return document


@router.put("/documents/{document_id}", response_model=APIDocumentResponse)
async def update_api_document(
    document_id: str,
    data: APIDocumentCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """更新API文档"""
    document = await db.get(APIDocument, document_id)
    if not document:
        raise HTTPException(status_code=404, detail="文档不存在")
    
    for key, value in data.dict().items():
        setattr(document, key, value)
    
    document.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(document)
    return document


@router.post("/documents/{document_id}/publish")
async def publish_api_document(
    document_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """发布API文档"""
    document = await db.get(APIDocument, document_id)
    if not document:
        raise HTTPException(status_code=404, detail="文档不存在")
    
    document.is_published = True
    await db.commit()
    
    return {"message": "文档已发布"}


# ============ SDK包API ============

@router.get("/products/{product_id}/sdks", response_model=List[SDKPackageResponse])
async def list_sdk_packages(
    product_id: str,
    language: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出SDK包"""
    query = select(SDKPackage).where(SDKPackage.product_id == product_id)
    if language:
        query = query.where(SDKPackage.language == language)
    
    result = await db.execute(query.order_by(desc(SDKPackage.created_at)))
    return result.scalars().all()


@router.post("/products/{product_id}/sdks", response_model=SDKPackageResponse)
async def create_sdk_package(
    product_id: str,
    data: SDKPackageCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("api:write"))
):
    """创建SDK包"""
    sdk = SDKPackage(product_id=product_id, **data.dict())
    db.add(sdk)
    await db.commit()
    await db.refresh(sdk)
    return sdk


# ============ 开发者应用API ============

@router.get("/apps", response_model=List[DeveloperAppResponse])
async def list_developer_apps(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """列出开发者应用"""
    result = await db.execute(
        select(DeveloperApp)
        .where(DeveloperApp.user_id == current_user.id)
        .order_by(desc(DeveloperApp.created_at))
    )
    return result.scalars().all()


@router.post("/apps", response_model=DeveloperAppResponse)
async def create_developer_app(
    data: DeveloperAppCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """创建开发者应用"""
    import secrets
    import hashlib
    
    # 生成client_id和client_secret
    client_id = f"kag_app_{secrets.token_urlsafe(16)}"
    client_secret = secrets.token_urlsafe(32)
    client_secret_hash = hashlib.sha256(client_secret.encode()).hexdigest()
    
    app = DeveloperApp(
        tenant_id=current_user.tenant_id,
        user_id=current_user.id,
        client_id=client_id,
        client_secret_hash=client_secret_hash,
        **data.dict()
    )
    db.add(app)
    await db.commit()
    await db.refresh(app)
    
    # 返回时包含client_secret（仅创建时）
    response = DeveloperAppResponse(**app.__dict__)
    response.client_secret = client_secret  # 临时属性
    return response


@router.get("/apps/{app_id}", response_model=DeveloperAppResponse)
async def get_developer_app(
    app_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取开发者应用详情"""
    app = await db.get(DeveloperApp, app_id)
    if not app or app.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="应用不存在")
    return app


@router.put("/apps/{app_id}", response_model=DeveloperAppResponse)
async def update_developer_app(
    app_id: str,
    data: DeveloperAppCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """更新开发者应用"""
    app = await db.get(DeveloperApp, app_id)
    if not app or app.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="应用不存在")
    
    for key, value in data.dict().items():
        setattr(app, key, value)
    
    app.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(app)
    return app


@router.post("/apps/{app_id}/regenerate-secret")
async def regenerate_app_secret(
    app_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """重新生成应用密钥"""
    import secrets
    import hashlib
    
    app = await db.get(DeveloperApp, app_id)
    if not app or app.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="应用不存在")
    
    client_secret = secrets.token_urlsafe(32)
    app.client_secret_hash = hashlib.sha256(client_secret.encode()).hexdigest()
    app.updated_at = datetime.utcnow()
    await db.commit()
    
    return {"client_secret": client_secret, "message": "密钥已重新生成"}


@router.delete("/apps/{app_id}")
async def delete_developer_app(
    app_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """删除开发者应用"""
    app = await db.get(DeveloperApp, app_id)
    if not app or app.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="应用不存在")
    
    app.status = AppStatus.REVOKED
    await db.commit()
    
    return {"message": "应用已撤销"}


# ============ 沙箱API ============

@router.post("/sandbox/execute", response_model=SandboxRequestResponse)
async def execute_sandbox_request(
    data: SandboxRequestCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """执行沙箱请求"""
    import time
    import json
    
    endpoint = await db.get(APIEndpoint, data.endpoint_id)
    if not endpoint:
        raise HTTPException(status_code=404, detail="端点不存在")
    
    start_time = time.time()
    
    # 这里模拟API调用
    # 实际应该根据endpoint配置调用真实的API
    response_status = 200
    response_headers = {"Content-Type": "application/json"}
    response_body = json.dumps({
        "success": True,
        "message": "沙箱请求成功",
        "data": {"mock": True}
    })
    
    latency_ms = int((time.time() - start_time) * 1000)
    
    sandbox_request = SandboxRequest(
        endpoint_id=data.endpoint_id,
        user_id=current_user.id,
        request_method=data.request_method,
        request_url=data.request_url,
        request_headers=data.request_headers,
        request_body=data.request_body,
        response_status=response_status,
        response_headers=response_headers,
        response_body=response_body,
        latency_ms=latency_ms
    )
    db.add(sandbox_request)
    await db.commit()
    await db.refresh(sandbox_request)
    
    return sandbox_request


@router.get("/sandbox/history")
async def get_sandbox_history(
    endpoint_id: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取沙箱请求历史"""
    query = select(SandboxRequest).where(SandboxRequest.user_id == current_user.id)
    
    if endpoint_id:
        query = query.where(SandboxRequest.endpoint_id == endpoint_id)
    
    # 统计总数
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # 分页
    query = query.order_by(desc(SandboxRequest.created_at))
    query = query.offset((page - 1) * page_size).limit(page_size)
    
    result = await db.execute(query)
    requests = result.scalars().all()
    
    return {
        "total": total,
        "items": requests
    }


# ============ OpenAPI规范API ============

@router.get("/products/{product_id}/openapi.json")
async def get_openapi_spec(
    product_id: str,
    version_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取OpenAPI规范"""
    product = await db.get(APIProduct, product_id)
    if not product or product.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=404, detail="API产品不存在")
    
    # 获取版本
    if version_id:
        version = await db.get(APIVersion, version_id)
    else:
        # 获取默认版本
        version_result = await db.execute(
            select(APIVersion).where(
                and_(
                    APIVersion.product_id == product_id,
                    APIVersion.is_default == True
                )
            )
        )
        version = version_result.scalar_one_or_none()
    
    if not version:
        raise HTTPException(status_code=404, detail="API版本不存在")
    
    # 获取端点
    endpoints_result = await db.execute(
        select(APIEndpoint).where(APIEndpoint.version_id == version.id)
    )
    endpoints = endpoints_result.scalars().all()
    
    # 构建OpenAPI规范
    openapi_spec = {
        "openapi": "3.0.0",
        "info": {
            "title": product.name,
            "description": product.description,
            "version": version.version
        },
        "servers": [
            {"url": product.base_url}
        ],
        "paths": {}
    }
    
    for endpoint in endpoints:
        path = openapi_spec["paths"].setdefault(endpoint.path, {})
        path[endpoint.method.lower()] = {
            "summary": endpoint.summary or endpoint.name,
            "description": endpoint.description,
            "tags": endpoint.tags,
            "parameters": endpoint.parameters,
            "requestBody": endpoint.request_body,
            "responses": endpoint.responses
        }
    
    return openapi_spec
