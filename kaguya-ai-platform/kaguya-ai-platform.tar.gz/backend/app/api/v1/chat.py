"""
对话API路由
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import List
import uuid

from app.core.database import get_db
from app.api.v1.auth import get_current_user
from app.models.user import User
from app.models.chat import Chat, Message, Favorite
from app.schemas.chat import (
    ChatCreate,
    ChatUpdate,
    ChatResponse,
    MessageCreate,
    MessageResponse,
    FavoriteCreate
)

router = APIRouter()


@router.get("", response_model=List[ChatResponse])
async def list_chats(
    tag: str = None,
    search: str = None,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """获取对话列表"""
    query = select(Chat).where(Chat.user_id == current_user.id)
    
    if tag:
        # 过滤标签
        query = query.where(Chat.tags.contains([tag]))
    
    if search:
        # 搜索标题
        query = query.where(Chat.title.contains(search))
    
    query = query.order_by(desc(Chat.is_starred), desc(Chat.updated_at))
    
    result = await db.execute(query)
    chats = result.scalars().all()
    
    return chats


@router.post("", response_model=ChatResponse)
async def create_chat(
    chat_data: ChatCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """创建新对话"""
    chat = Chat(
        id=str(uuid.uuid4()),
        user_id=current_user.id,
        title=chat_data.title or "新对话",
        role_id=chat_data.role_id,
        model=chat_data.model or "gpt-3.5-turbo",
        temperature=chat_data.temperature or 0.7,
        max_tokens=chat_data.max_tokens or 2048
    )
    
    db.add(chat)
    await db.commit()
    await db.refresh(chat)
    
    return chat


@router.get("/{chat_id}", response_model=ChatResponse)
async def get_chat(
    chat_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """获取对话详情"""
    result = await db.execute(
        select(Chat).where(Chat.id == chat_id, Chat.user_id == current_user.id)
    )
    chat = result.scalar_one_or_none()
    
    if not chat:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="对话不存在"
        )
    
    return chat


@router.put("/{chat_id}", response_model=ChatResponse)
async def update_chat(
    chat_id: str,
    chat_data: ChatUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """更新对话"""
    result = await db.execute(
        select(Chat).where(Chat.id == chat_id, Chat.user_id == current_user.id)
    )
    chat = result.scalar_one_or_none()
    
    if not chat:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="对话不存在"
        )
    
    # 更新字段
    if chat_data.title is not None:
        chat.title = chat_data.title
    if chat_data.role_id is not None:
        chat.role_id = chat_data.role_id
    if chat_data.tags is not None:
        chat.tags = chat_data.tags
    if chat_data.is_starred is not None:
        chat.is_starred = chat_data.is_starred
    if chat_data.model is not None:
        chat.model = chat_data.model
    if chat_data.temperature is not None:
        chat.temperature = chat_data.temperature
    if chat_data.max_tokens is not None:
        chat.max_tokens = chat_data.max_tokens
    
    await db.commit()
    await db.refresh(chat)
    
    return chat


@router.delete("/{chat_id}")
async def delete_chat(
    chat_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """删除对话"""
    result = await db.execute(
        select(Chat).where(Chat.id == chat_id, Chat.user_id == current_user.id)
    )
    chat = result.scalar_one_or_none()
    
    if not chat:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="对话不存在"
        )
    
    await db.delete(chat)
    await db.commit()
    
    return {"message": "对话已删除"}


@router.get("/{chat_id}/messages", response_model=List[MessageResponse])
async def get_messages(
    chat_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """获取对话消息"""
    # 验证对话存在
    result = await db.execute(
        select(Chat).where(Chat.id == chat_id, Chat.user_id == current_user.id)
    )
    chat = result.scalar_one_or_none()
    
    if not chat:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="对话不存在"
        )
    
    # 获取消息
    result = await db.execute(
        select(Message)
        .where(Message.chat_id == chat_id)
        .order_by(Message.created_at)
    )
    messages = result.scalars().all()
    
    return messages


@router.post("/{chat_id}/favorites")
async def add_favorite(
    chat_id: str,
    favorite_data: FavoriteCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """添加收藏"""
    # 验证消息存在
    result = await db.execute(
        select(Message).where(
            Message.id == favorite_data.message_id,
            Message.chat_id == chat_id
        )
    )
    message = result.scalar_one_or_none()
    
    if not message:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="消息不存在"
        )
    
    # 检查是否已收藏
    result = await db.execute(
        select(Favorite).where(
            Favorite.user_id == current_user.id,
            Favorite.message_id == favorite_data.message_id
        )
    )
    if result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="消息已收藏"
        )
    
    favorite = Favorite(
        id=str(uuid.uuid4()),
        user_id=current_user.id,
        message_id=favorite_data.message_id,
        chat_id=chat_id,
        note=favorite_data.note
    )
    
    db.add(favorite)
    await db.commit()
    await db.refresh(favorite)
    
    return favorite


@router.get("/favorites/my")
async def get_favorites(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """获取我的收藏"""
    result = await db.execute(
        select(Favorite)
        .where(Favorite.user_id == current_user.id)
        .order_by(desc(Favorite.created_at))
    )
    favorites = result.scalars().all()
    
    return favorites
