"""
LLM服务 - 统一模型网关
"""

import os
from typing import AsyncGenerator, List, Dict, Any, Optional
from abc import ABC, abstractmethod
import openai
from openai import AsyncOpenAI

from app.core.config import settings


class BaseLLMProvider(ABC):
    """LLM提供商基类"""
    
    @abstractmethod
    async def chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stream: bool = False,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """聊天完成"""
        pass
    
    @abstractmethod
    async def get_models(self) -> List[Dict[str, Any]]:
        """获取可用模型列表"""
        pass


class OpenAIProvider(BaseLLMProvider):
    """OpenAI提供商"""
    
    def __init__(self):
        self.client = AsyncOpenAI(
            api_key=settings.OPENAI_API_KEY or "",
            base_url=settings.OPENAI_BASE_URL
        )
    
    async def chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stream: bool = False,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """聊天完成"""
        try:
            response = await self.client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=stream,
                **kwargs
            )
            
            if stream:
                async for chunk in response:
                    if chunk.choices and chunk.choices[0].delta.content:
                        yield chunk.choices[0].delta.content
            else:
                content = response.choices[0].message.content
                yield content
                
        except Exception as e:
            yield f"[Error: {str(e)}]"
    
    async def get_models(self) -> List[Dict[str, Any]]:
        """获取可用模型"""
        try:
            models = await self.client.models.list()
            return [
                {"id": m.id, "name": m.id, "provider": "openai"}
                for m in models.data
            ]
        except:
            return [
                {"id": "gpt-4", "name": "GPT-4", "provider": "openai"},
                {"id": "gpt-4-turbo", "name": "GPT-4 Turbo", "provider": "openai"},
                {"id": "gpt-3.5-turbo", "name": "GPT-3.5 Turbo", "provider": "openai"},
            ]


class DeepSeekProvider(BaseLLMProvider):
    """DeepSeek提供商"""
    
    def __init__(self):
        self.client = AsyncOpenAI(
            api_key=settings.DEEPSEEK_API_KEY or "",
            base_url=settings.DEEPSEEK_BASE_URL
        )
    
    async def chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stream: bool = False,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """聊天完成"""
        try:
            response = await self.client.chat.completions.create(
                model=model or "deepseek-chat",
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=stream,
                **kwargs
            )
            
            if stream:
                async for chunk in response:
                    if chunk.choices and chunk.choices[0].delta.content:
                        yield chunk.choices[0].delta.content
            else:
                content = response.choices[0].message.content
                yield content
                
        except Exception as e:
            yield f"[Error: {str(e)}]"
    
    async def get_models(self) -> List[Dict[str, Any]]:
        """获取可用模型"""
        return [
            {"id": "deepseek-chat", "name": "DeepSeek Chat", "provider": "deepseek"},
            {"id": "deepseek-coder", "name": "DeepSeek Coder", "provider": "deepseek"},
            {"id": "deepseek-reasoner", "name": "DeepSeek Reasoner", "provider": "deepseek"},
        ]


class LLMGateway:
    """LLM网关 - 统一接口"""
    
    def __init__(self):
        self.providers = {
            "openai": OpenAIProvider(),
            "deepseek": DeepSeekProvider(),
        }
        self.model_mapping = {
            # OpenAI 模型
            "gpt-4": ("openai", "gpt-4"),
            "gpt-4-turbo": ("openai", "gpt-4-turbo-preview"),
            "gpt-3.5-turbo": ("openai", "gpt-3.5-turbo"),
            # DeepSeek 模型
            "deepseek-chat": ("deepseek", "deepseek-chat"),
            "deepseek-coder": ("deepseek", "deepseek-coder"),
            "deepseek-reasoner": ("deepseek", "deepseek-reasoner"),
        }
    
    def get_provider(self, model: str) -> tuple:
        """获取模型对应的提供商"""
        if model in self.model_mapping:
            return self.model_mapping[model]
        # 默认使用 OpenAI
        return ("openai", model)
    
    async def chat_completion(
        self,
        messages: List[Dict[str, str]],
        model: str,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stream: bool = False,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """统一聊天完成接口"""
        provider_name, actual_model = self.get_provider(model)
        provider = self.providers.get(provider_name)
        
        if not provider:
            yield f"[Error: Unknown provider {provider_name}]"
            return
        
        async for chunk in provider.chat_completion(
            messages=messages,
            model=actual_model,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            **kwargs
        ):
            yield chunk
    
    async def get_all_models(self) -> List[Dict[str, Any]]:
        """获取所有可用模型"""
        all_models = []
        
        for provider_name, provider in self.providers.items():
            try:
                models = await provider.get_models()
                all_models.extend(models)
            except Exception as e:
                print(f"Failed to get models from {provider_name}: {e}")
        
        return all_models


# 全局LLM网关实例
llm_gateway = LLMGateway()
