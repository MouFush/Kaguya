"""
安全服务
负责审计日志、权限检查、API密钥验证等
"""

from typing import Optional, Dict, Any, List
from datetime import datetime
from functools import wraps
import hashlib
import secrets

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, desc

from app.models import AuditLog, APIKey, Permission, RolePermission, AuditAction


class SecurityService:
    """安全服务"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def log_audit(
        self,
        action: AuditAction,
        resource_type: str,
        resource_id: Optional[str] = None,
        user_id: Optional[str] = None,
        user_email: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        before_data: Optional[Dict[str, Any]] = None,
        after_data: Optional[Dict[str, Any]] = None
    ) -> AuditLog:
        """记录审计日志"""
        log = AuditLog(
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            user_id=user_id,
            user_email=user_email,
            ip_address=ip_address,
            user_agent=user_agent,
            before_data=before_data,
            after_data=after_data
        )
        self.db.add(log)
        await self.db.commit()
        return log
    
    async def verify_api_key(self, api_key: str) -> Optional[APIKey]:
        """验证API密钥"""
        # 计算哈希
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        
        # 查询数据库
        result = await self.db.execute(
            select(APIKey).where(
                and_(
                    APIKey.key_hash == key_hash,
                    APIKey.is_active == True
                )
            )
        )
        key_obj = result.scalar_one_or_none()
        
        if not key_obj:
            return None
        
        # 检查是否过期
        if key_obj.expires_at and key_obj.expires_at < datetime.utcnow():
            return None
        
        # 更新最后使用时间
        key_obj.last_used_at = datetime.utcnow()
        await self.db.commit()
        
        return key_obj
    
    async def check_permission(
        self,
        user_role: str,
        required_permission: str
    ) -> bool:
        """检查权限"""
        # 超级管理员拥有所有权限
        if user_role == "superadmin":
            return True
        
        # 查询角色权限
        result = await self.db.execute(
            select(RolePermission).where(
                and_(
                    RolePermission.role == user_role,
                    RolePermission.permission_code == required_permission
                )
            )
        )
        return result.scalar_one_or_none() is not None
    
    async def get_user_permissions(self, user_role: str) -> List[str]:
        """获取用户权限列表"""
        if user_role == "superadmin":
            # 返回所有权限
            result = await self.db.execute(select(Permission.code))
            return [p[0] for p in result.all()]
        
        result = await self.db.execute(
            select(Permission.code)
            .join(RolePermission)
            .where(RolePermission.role == user_role)
        )
        return [p[0] for p in result.all()]
    
    async def check_rate_limit(
        self,
        api_key_id: str,
        limit: int,
        window_seconds: int = 60
    ) -> Dict[str, Any]:
        """检查速率限制"""
        # 这里简化处理，实际应该使用Redis等缓存
        # 返回剩余请求数和是否被限制
        return {
            "allowed": True,
            "remaining": limit,
            "reset_time": datetime.utcnow().timestamp() + window_seconds
        }
    
    def generate_secure_token(self, length: int = 32) -> str:
        """生成安全令牌"""
        return secrets.token_urlsafe(length)
    
    def hash_secret(self, secret: str) -> str:
        """哈希密钥"""
        return hashlib.sha256(secret.encode()).hexdigest()


def audit_log(
    action: AuditAction,
    resource_type: str,
    get_resource_id: Optional[callable] = None
):
    """审计日志装饰器"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # 获取数据库会话和当前用户
            db = kwargs.get('db')
            current_user = kwargs.get('current_user')
            
            # 执行原函数
            result = await func(*args, **kwargs)
            
            # 记录审计日志
            if db and current_user:
                resource_id = None
                if get_resource_id:
                    resource_id = get_resource_id(result, *args, **kwargs)
                
                security_service = SecurityService(db)
                await security_service.log_audit(
                    action=action,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    user_id=current_user.id,
                    user_email=current_user.email
                )
            
            return result
        return wrapper
    return decorator
