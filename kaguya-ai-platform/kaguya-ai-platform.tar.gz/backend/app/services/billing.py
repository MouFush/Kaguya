"""
计费服务
负责处理计费逻辑、配额检查、发票生成等
"""

from typing import Dict, Any, Optional
from datetime import datetime, timedelta
from decimal import Decimal

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func, desc

from app.models import (
    Subscription, BillingPlan, UsageRecord, Wallet, WalletTransaction,
    Invoice, Coupon, SubscriptionStatus, BillingStatus
)


class BillingService:
    """计费服务"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def check_quota(
        self,
        tenant_id: str,
        resource_type: str,
        requested_amount: int = 1
    ) -> Dict[str, Any]:
        """检查配额"""
        # 获取当前订阅
        result = await self.db.execute(
            select(Subscription)
            .join(BillingPlan)
            .where(
                and_(
                    Subscription.tenant_id == tenant_id,
                    Subscription.status == SubscriptionStatus.ACTIVE
                )
            )
        )
        subscription = result.scalar_one_or_none()
        
        if not subscription:
            return {
                "allowed": False,
                "reason": "No active subscription",
                "remaining": 0
            }
        
        # 获取配额配置
        quota_config = subscription.plan.quota_config
        resource_quota = quota_config.get(resource_type, {})
        
        limit = resource_quota.get("limit", 0)
        period = resource_quota.get("period", "monthly")  # daily, monthly, yearly
        
        # 计算当前使用量
        usage = await self.get_usage(tenant_id, resource_type, period)
        remaining = limit - usage
        
        if remaining < requested_amount:
            return {
                "allowed": False,
                "reason": "Quota exceeded",
                "remaining": remaining,
                "limit": limit,
                "usage": usage
            }
        
        return {
            "allowed": True,
            "remaining": remaining,
            "limit": limit,
            "usage": usage
        }
    
    async def record_usage(
        self,
        tenant_id: str,
        user_id: str,
        resource_type: str,
        quantity: int,
        unit_price: Optional[Decimal] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> UsageRecord:
        """记录使用量"""
        # 计算费用
        cost = None
        if unit_price:
            cost = unit_price * quantity
        
        usage = UsageRecord(
            tenant_id=tenant_id,
            user_id=user_id,
            resource_type=resource_type,
            quantity=quantity,
            unit_price=unit_price,
            cost=cost,
            metadata=metadata or {}
        )
        self.db.add(usage)
        await self.db.commit()
        
        # 更新租户使用统计
        await self._update_tenant_usage(tenant_id, resource_type, quantity)
        
        return usage
    
    async def get_usage(
        self,
        tenant_id: str,
        resource_type: str,
        period: str = "monthly"
    ) -> int:
        """获取使用量"""
        # 计算时间范围
        end_time = datetime.utcnow()
        if period == "daily":
            start_time = end_time - timedelta(days=1)
        elif period == "monthly":
            start_time = end_time - timedelta(days=30)
        elif period == "yearly":
            start_time = end_time - timedelta(days=365)
        else:
            start_time = end_time - timedelta(days=30)
        
        # 查询使用量
        result = await self.db.execute(
            select(func.sum(UsageRecord.quantity))
            .where(
                and_(
                    UsageRecord.tenant_id == tenant_id,
                    UsageRecord.resource_type == resource_type,
                    UsageRecord.created_at >= start_time,
                    UsageRecord.created_at <= end_time
                )
            )
        )
        total = result.scalar() or 0
        return int(total)
    
    async def charge_wallet(
        self,
        tenant_id: str,
        amount: Decimal,
        description: str,
        reference_type: Optional[str] = None,
        reference_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """从钱包扣费"""
        # 获取钱包
        result = await self.db.execute(
            select(Wallet).where(Wallet.tenant_id == tenant_id)
        )
        wallet = result.scalar_one_or_none()
        
        if not wallet:
            return {
                "success": False,
                "error": "Wallet not found"
            }
        
        # 检查余额
        if wallet.balance < amount:
            return {
                "success": False,
                "error": "Insufficient balance",
                "balance": float(wallet.balance),
                "required": float(amount)
            }
        
        # 扣费
        wallet.balance -= amount
        
        # 创建交易记录
        transaction = WalletTransaction(
            wallet_id=wallet.id,
            transaction_type="charge",
            amount=-amount,
            balance_after=wallet.balance,
            description=description,
            reference_type=reference_type,
            reference_id=reference_id
        )
        self.db.add(transaction)
        await self.db.commit()
        
        return {
            "success": True,
            "transaction_id": transaction.id,
            "balance": float(wallet.balance)
        }
    
    async def generate_invoice(
        self,
        tenant_id: str,
        period_start: datetime,
        period_end: datetime
    ) -> Invoice:
        """生成发票"""
        # 获取期间的使用记录
        result = await self.db.execute(
            select(UsageRecord)
            .where(
                and_(
                    UsageRecord.tenant_id == tenant_id,
                    UsageRecord.created_at >= period_start,
                    UsageRecord.created_at <= period_end,
                    UsageRecord.invoice_id == None
                )
            )
        )
        usages = result.scalars().all()
        
        # 计算费用
        items = []
        total_amount = Decimal("0")
        
        for usage in usages:
            if usage.cost:
                item = {
                    "resource_type": usage.resource_type,
                    "quantity": usage.quantity,
                    "unit_price": float(usage.unit_price) if usage.unit_price else 0,
                    "amount": float(usage.cost)
                }
                items.append(item)
                total_amount += usage.cost
        
        # 创建发票
        invoice = Invoice(
            tenant_id=tenant_id,
            invoice_number=await self._generate_invoice_number(),
            period_start=period_start,
            period_end=period_end,
            subtotal=total_amount,
            tax_amount=total_amount * Decimal("0.06"),  # 6% 税率
            total_amount=total_amount * Decimal("1.06"),
            items=items,
            status=BillingStatus.PENDING
        )
        self.db.add(invoice)
        
        # 关联使用记录
        for usage in usages:
            usage.invoice_id = invoice.id
        
        await self.db.commit()
        await self.db.refresh(invoice)
        
        return invoice
    
    async def apply_coupon(
        self,
        invoice_id: str,
        coupon_code: str
    ) -> Dict[str, Any]:
        """应用优惠券"""
        # 获取优惠券
        result = await self.db.execute(
            select(Coupon).where(
                and_(
                    Coupon.code == coupon_code,
                    Coupon.is_active == True,
                    Coupon.valid_from <= datetime.utcnow(),
                    Coupon.valid_until >= datetime.utcnow()
                )
            )
        )
        coupon = result.scalar_one_or_none()
        
        if not coupon:
            return {
                "success": False,
                "error": "Invalid or expired coupon"
            }
        
        # 检查使用次数
        if coupon.usage_count >= coupon.usage_limit:
            return {
                "success": False,
                "error": "Coupon usage limit reached"
            }
        
        # 获取发票
        invoice = await self.db.get(Invoice, invoice_id)
        if not invoice:
            return {
                "success": False,
                "error": "Invoice not found"
            }
        
        # 计算折扣
        discount_amount = Decimal("0")
        if coupon.discount_type == "percentage":
            discount_amount = invoice.subtotal * (coupon.discount_value / 100)
        else:  # fixed
            discount_amount = min(coupon.discount_value, invoice.subtotal)
        
        # 应用折扣
        invoice.discount_amount = discount_amount
        invoice.total_amount = invoice.subtotal + invoice.tax_amount - discount_amount
        
        # 更新优惠券使用次数
        coupon.usage_count += 1
        
        await self.db.commit()
        
        return {
            "success": True,
            "discount_amount": float(discount_amount),
            "new_total": float(invoice.total_amount)
        }
    
    async def _update_tenant_usage(
        self,
        tenant_id: str,
        resource_type: str,
        quantity: int
    ):
        """更新租户使用统计"""
        from app.models import Tenant
        
        tenant = await self.db.get(Tenant, tenant_id)
        if tenant:
            if "usage_stats" not in tenant.usage_stats:
                tenant.usage_stats["usage_stats"] = {}
            
            current = tenant.usage_stats["usage_stats"].get(resource_type, 0)
            tenant.usage_stats["usage_stats"][resource_type] = current + quantity
            
            await self.db.commit()
    
    async def _generate_invoice_number(self) -> str:
        """生成发票编号"""
        # 格式: INV-YYYYMMDD-XXXX
        today = datetime.utcnow().strftime("%Y%m%d")
        
        # 获取今日发票数量
        result = await self.db.execute(
            select(func.count(Invoice.id))
            .where(
                and_(
                    Invoice.created_at >= datetime.utcnow().replace(hour=0, minute=0, second=0),
                    Invoice.created_at < datetime.utcnow().replace(hour=23, minute=59, second=59)
                )
            )
        )
        count = result.scalar() or 0
        
        return f"INV-{today}-{count + 1:04d}"
