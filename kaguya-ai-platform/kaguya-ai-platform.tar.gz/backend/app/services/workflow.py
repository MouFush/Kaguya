"""
工作流引擎服务
负责执行AI工作流
"""

import json
import asyncio
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
from enum import Enum

from app.models import Workflow, WorkflowExecution, WorkflowExecutionLog, WorkflowExecutionStatus


class NodeType(str, Enum):
    """节点类型"""
    START = "start"
    LLM = "llm"
    CONDITION = "condition"
    CODE = "code"
    API = "api"
    KNOWLEDGE = "knowledge"
    END = "end"


class WorkflowEngine:
    """工作流引擎"""
    
    def __init__(self):
        self.node_handlers: Dict[NodeType, Callable] = {
            NodeType.START: self._handle_start_node,
            NodeType.LLM: self._handle_llm_node,
            NodeType.CONDITION: self._handle_condition_node,
            NodeType.CODE: self._handle_code_node,
            NodeType.API: self._handle_api_node,
            NodeType.KNOWLEDGE: self._handle_knowledge_node,
            NodeType.END: self._handle_end_node,
        }
    
    async def execute(
        self,
        workflow: Workflow,
        execution: WorkflowExecution,
        initial_context: Optional[Dict[str, Any]] = None
    ) -> WorkflowExecution:
        """执行工作流"""
        try:
            execution.status = WorkflowExecutionStatus.RUNNING
            execution.started_at = datetime.utcnow()
            
            # 初始化上下文
            context = initial_context or {}
            execution.context = context
            
            # 构建节点映射
            nodes_map = {node["id"]: node for node in workflow.nodes}
            edges_map = self._build_edges_map(workflow.edges)
            
            # 找到开始节点
            start_node = self._find_start_node(workflow.nodes)
            if not start_node:
                raise ValueError("工作流没有开始节点")
            
            # 执行工作流
            current_node_id = start_node["id"]
            visited_nodes = set()
            
            while current_node_id:
                if current_node_id in visited_nodes:
                    raise ValueError("检测到循环依赖")
                
                visited_nodes.add(current_node_id)
                node = nodes_map.get(current_node_id)
                
                if not node:
                    break
                
                # 执行节点
                result = await self._execute_node(node, context, execution)
                
                # 记录日志
                await self._log_execution(execution.id, current_node_id, node["type"], result)
                
                # 更新上下文
                context.update(result.get("outputs", {}))
                execution.context = context
                
                # 确定下一个节点
                if node["type"] == NodeType.END.value:
                    break
                
                current_node_id = self._get_next_node(node, result, edges_map)
            
            execution.status = WorkflowExecutionStatus.COMPLETED
            execution.completed_at = datetime.utcnow()
            execution.result = context
            
        except Exception as e:
            execution.status = WorkflowExecutionStatus.FAILED
            execution.error_message = str(e)
            execution.completed_at = datetime.utcnow()
            
            # 记录错误日志
            await self._log_execution(
                execution.id,
                current_node_id if 'current_node_id' in locals() else None,
                "error",
                {"error": str(e)}
            )
        
        return execution
    
    def _build_edges_map(self, edges: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        """构建边映射"""
        edges_map = {}
        for edge in edges:
            source = edge["source"]
            if source not in edges_map:
                edges_map[source] = []
            edges_map[source].append(edge)
        return edges_map
    
    def _find_start_node(self, nodes: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """找到开始节点"""
        for node in nodes:
            if node["type"] == NodeType.START.value:
                return node
        return None
    
    async def _execute_node(
        self,
        node: Dict[str, Any],
        context: Dict[str, Any],
        execution: WorkflowExecution
    ) -> Dict[str, Any]:
        """执行单个节点"""
        node_type = NodeType(node["type"])
        handler = self.node_handlers.get(node_type)
        
        if not handler:
            raise ValueError(f"未知的节点类型: {node_type}")
        
        return await handler(node, context, execution)
    
    async def _handle_start_node(
        self,
        node: Dict[str, Any],
        context: Dict[str, Any],
        execution: WorkflowExecution
    ) -> Dict[str, Any]:
        """处理开始节点"""
        return {
            "outputs": node.get("data", {}).get("outputs", {}),
            "success": True
        }
    
    async def _handle_llm_node(
        self,
        node: Dict[str, Any],
        context: Dict[str, Any],
        execution: WorkflowExecution
    ) -> Dict[str, Any]:
        """处理LLM节点"""
        from app.services.llm import LLMService
        
        data = node.get("data", {})
        model = data.get("model", "default")
        prompt = data.get("prompt", "")
        temperature = data.get("temperature", 0.7)
        
        # 替换模板变量
        prompt = self._render_template(prompt, context)
        
        # 调用LLM
        llm_service = LLMService()
        response = await llm_service.chat(
            messages=[{"role": "user", "content": prompt}],
            model=model,
            temperature=temperature
        )
        
        return {
            "outputs": {
                "response": response["content"],
                "model": model
            },
            "success": True
        }
    
    async def _handle_condition_node(
        self,
        node: Dict[str, Any],
        context: Dict[str, Any],
        execution: WorkflowExecution
    ) -> Dict[str, Any]:
        """处理条件节点"""
        data = node.get("data", {})
        conditions = data.get("conditions", [])
        
        for condition in conditions:
            expression = condition.get("expression", "")
            # 简单的条件评估
            if self._evaluate_condition(expression, context):
                return {
                    "outputs": {"condition_result": condition.get("id")},
                    "success": True,
                    "branch": condition.get("id")
                }
        
        # 默认分支
        return {
            "outputs": {"condition_result": "default"},
            "success": True,
            "branch": "default"
        }
    
    async def _handle_code_node(
        self,
        node: Dict[str, Any],
        context: Dict[str, Any],
        execution: WorkflowExecution
    ) -> Dict[str, Any]:
        """处理代码节点"""
        data = node.get("data", {})
        code = data.get("code", "")
        language = data.get("language", "python")
        
        # 安全执行代码（这里简化处理，实际应该使用沙箱）
        try:
            # 创建安全的执行环境
            safe_globals = {
                "context": context,
                "json": json,
                "result": {}
            }
            
            if language == "python":
                exec(code, safe_globals)
                result = safe_globals.get("result", {})
            else:
                result = {"error": f"不支持的语言: {language}"}
            
            return {
                "outputs": result,
                "success": "error" not in result
            }
        except Exception as e:
            return {
                "outputs": {"error": str(e)},
                "success": False
            }
    
    async def _handle_api_node(
        self,
        node: Dict[str, Any],
        context: Dict[str, Any],
        execution: WorkflowExecution
    ) -> Dict[str, Any]:
        """处理API节点"""
        import httpx
        
        data = node.get("data", {})
        url = self._render_template(data.get("url", ""), context)
        method = data.get("method", "GET")
        headers = data.get("headers", {})
        body = data.get("body", {})
        
        # 替换模板变量
        for key, value in headers.items():
            headers[key] = self._render_template(value, context)
        
        if isinstance(body, str):
            body = self._render_template(body, context)
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=body if method in ["POST", "PUT", "PATCH"] else None,
                    params=body if method == "GET" else None,
                    timeout=30.0
                )
                
                return {
                    "outputs": {
                        "status_code": response.status_code,
                        "body": response.json() if response.headers.get("content-type", "").startswith("application/json") else response.text,
                        "headers": dict(response.headers)
                    },
                    "success": response.status_code < 400
                }
        except Exception as e:
            return {
                "outputs": {"error": str(e)},
                "success": False
            }
    
    async def _handle_knowledge_node(
        self,
        node: Dict[str, Any],
        context: Dict[str, Any],
        execution: WorkflowExecution
    ) -> Dict[str, Any]:
        """处理知识库节点"""
        from app.services.rag import RAGService
        
        data = node.get("data", {})
        query = self._render_template(data.get("query", ""), context)
        knowledge_base_id = data.get("knowledge_base_id")
        top_k = data.get("top_k", 5)
        
        # 调用RAG服务
        rag_service = RAGService()
        results = await rag_service.search(
            query=query,
            knowledge_base_id=knowledge_base_id,
            top_k=top_k
        )
        
        return {
            "outputs": {
                "results": results,
                "query": query
            },
            "success": True
        }
    
    async def _handle_end_node(
        self,
        node: Dict[str, Any],
        context: Dict[str, Any],
        execution: WorkflowExecution
    ) -> Dict[str, Any]:
        """处理结束节点"""
        data = node.get("data", {})
        outputs = data.get("outputs", {})
        
        # 渲染输出模板
        rendered_outputs = {}
        for key, value in outputs.items():
            rendered_outputs[key] = self._render_template(value, context)
        
        return {
            "outputs": rendered_outputs,
            "success": True
        }
    
    def _get_next_node(
        self,
        current_node: Dict[str, Any],
        result: Dict[str, Any],
        edges_map: Dict[str, List[Dict[str, Any]]]
    ) -> Optional[str]:
        """获取下一个节点"""
        node_id = current_node["id"]
        edges = edges_map.get(node_id, [])
        
        if not edges:
            return None
        
        # 如果是条件节点，根据分支选择
        if current_node["type"] == NodeType.CONDITION.value:
            branch = result.get("branch", "default")
            for edge in edges:
                if edge.get("condition") == branch:
                    return edge["target"]
            # 返回第一个边作为默认
            return edges[0]["target"]
        
        # 返回第一个连接
        return edges[0]["target"]
    
    def _render_template(self, template: str, context: Dict[str, Any]) -> str:
        """渲染模板"""
        if not isinstance(template, str):
            return template
        
        result = template
        for key, value in context.items():
            placeholder = f"{{{{{key}}}}}"
            if placeholder in result:
                result = result.replace(placeholder, str(value))
        
        return result
    
    def _evaluate_condition(self, expression: str, context: Dict[str, Any]) -> bool:
        """评估条件表达式"""
        try:
            # 简单的条件评估，实际应该使用更安全的表达式引擎
            # 替换变量
            for key, value in context.items():
                if isinstance(value, (int, float, bool)):
                    expression = expression.replace(f"{{{key}}}", str(value))
                else:
                    expression = expression.replace(f"{{{key}}}", f'"{value}"')
            
            # 使用eval评估（注意：这在生产环境中应该使用更安全的方案）
            return bool(eval(expression, {"__builtins__": {}}))
        except:
            return False
    
    async def _log_execution(
        self,
        execution_id: str,
        node_id: Optional[str],
        node_type: str,
        result: Dict[str, Any]
    ):
        """记录执行日志"""
        # 这里应该将日志写入数据库
        # 简化处理，仅打印
        print(f"[Workflow {execution_id}] Node {node_id} ({node_type}): {result.get('success', False)}")
