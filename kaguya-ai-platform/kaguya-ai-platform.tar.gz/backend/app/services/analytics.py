"""
数据分析服务
负责收集、聚合和分析平台数据
"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from collections import defaultdict

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func, desc

from app.models import (
    MetricDefinition, MetricDataPoint, Dashboard, Report, AlertRule,
    AlertNotification, UsageSummary, MetricType, AlertSeverity
)


class AnalyticsService:
    """数据分析服务"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def record_metric(
        self,
        metric_name: str,
        value: float,
        labels: Optional[Dict[str, str]] = None,
        timestamp: Optional[datetime] = None
    ) -> MetricDataPoint:
        """记录指标数据"""
        # 查找或创建指标定义
        result = await self.db.execute(
            select(MetricDefinition).where(MetricDefinition.name == metric_name)
        )
        metric_def = result.scalar_one_or_none()
        
        if not metric_def:
            # 自动创建指标定义
            metric_def = MetricDefinition(
                name=metric_name,
                metric_type=MetricType.GAUGE,
                description=f"Auto-created metric: {metric_name}"
            )
            self.db.add(metric_def)
            await self.db.flush()
        
        # 创建数据点
        data_point = MetricDataPoint(
            metric_id=metric_def.id,
            value=value,
            timestamp=timestamp or datetime.utcnow(),
            labels=labels or {}
        )
        self.db.add(data_point)
        await self.db.commit()
        
        return data_point
    
    async def get_metric_summary(
        self,
        metric_name: str,
        start_time: datetime,
        end_time: datetime,
        aggregation: str = "avg"
    ) -> Dict[str, Any]:
        """获取指标汇总"""
        result = await self.db.execute(
            select(MetricDefinition).where(MetricDefinition.name == metric_name)
        )
        metric_def = result.scalar_one_or_none()
        
        if not metric_def:
            return {"error": "Metric not found"}
        
        # 查询数据点
        result = await self.db.execute(
            select(MetricDataPoint)
            .where(
                and_(
                    MetricDataPoint.metric_id == metric_def.id,
                    MetricDataPoint.timestamp >= start_time,
                    MetricDataPoint.timestamp <= end_time
                )
            )
            .order_by(MetricDataPoint.timestamp)
        )
        points = result.scalars().all()
        
        if not points:
            return {
                "metric": metric_name,
                "count": 0,
                "value": 0
            }
        
        values = [p.value for p in points]
        
        # 计算聚合值
        if aggregation == "sum":
            agg_value = sum(values)
        elif aggregation == "avg":
            agg_value = sum(values) / len(values)
        elif aggregation == "min":
            agg_value = min(values)
        elif aggregation == "max":
            agg_value = max(values)
        elif aggregation == "count":
            agg_value = len(values)
        else:
            agg_value = sum(values) / len(values)
        
        return {
            "metric": metric_name,
            "count": len(values),
            "value": agg_value,
            "min": min(values),
            "max": max(values),
            "start_time": start_time,
            "end_time": end_time
        }
    
    async def check_alerts(self) -> List[Dict[str, Any]]:
        """检查告警规则"""
        triggered_alerts = []
        
        # 获取所有活跃的告警规则
        result = await self.db.execute(
            select(AlertRule).where(AlertRule.is_active == True)
        )
        rules = result.scalars().all()
        
        for rule in rules:
            # 检查冷却期
            if rule.last_triggered_at:
                cooldown_end = rule.last_triggered_at + timedelta(minutes=rule.cooldown_minutes)
                if datetime.utcnow() < cooldown_end:
                    continue
            
            # 获取指标数据
            end_time = datetime.utcnow()
            start_time = end_time - timedelta(minutes=5)  # 最近5分钟
            
            result = await self.db.execute(
                select(MetricDataPoint)
                .where(
                    and_(
                        MetricDataPoint.metric_id == rule.metric_id,
                        MetricDataPoint.timestamp >= start_time,
                        MetricDataPoint.timestamp <= end_time
                    )
                )
            )
            points = result.scalars().all()
            
            if not points:
                continue
            
            # 计算当前值
            values = [p.value for p in points]
            current_value = sum(values) / len(values)
            
            # 检查条件
            triggered = False
            if rule.condition == "gt" and current_value > rule.threshold:
                triggered = True
            elif rule.condition == "lt" and current_value < rule.threshold:
                triggered = True
            elif rule.condition == "gte" and current_value >= rule.threshold:
                triggered = True
            elif rule.condition == "lte" and current_value <= rule.threshold:
                triggered = True
            elif rule.condition == "eq" and current_value == rule.threshold:
                triggered = True
            
            if triggered:
                # 创建告警通知
                notification = AlertNotification(
                    tenant_id=rule.tenant_id,
                    alert_rule_id=rule.id,
                    severity=rule.severity,
                    title=f"告警: {rule.name}",
                    message=f"指标值 {current_value:.2f} 触发条件 {rule.condition} {rule.threshold}",
                    metric_value=current_value,
                    threshold=rule.threshold
                )
                self.db.add(notification)
                
                # 更新规则最后触发时间
                rule.last_triggered_at = datetime.utcnow()
                
                triggered_alerts.append({
                    "rule_id": rule.id,
                    "rule_name": rule.name,
                    "severity": rule.severity,
                    "current_value": current_value,
                    "threshold": rule.threshold
                })
        
        await self.db.commit()
        return triggered_alerts
    
    async def generate_usage_report(
        self,
        tenant_id: str,
        period_type: str,
        period_start: datetime,
        period_end: datetime
    ) -> Dict[str, Any]:
        """生成使用报告"""
        # 收集各类指标
        metrics = {}
        
        # API调用次数
        api_calls = await self.get_metric_summary(
            "api_calls",
            period_start,
            period_end,
            "count"
        )
        metrics["api_calls"] = api_calls.get("value", 0)
        
        # Token使用量
        token_usage = await self.get_metric_summary(
            "token_usage",
            period_start,
            period_end,
            "sum"
        )
        metrics["token_usage"] = token_usage.get("value", 0)
        
        # 活跃用户
        active_users = await self.get_metric_summary(
            "active_users",
            period_start,
            period_end,
            "max"
        )
        metrics["active_users"] = int(active_users.get("value", 0))
        
        # 计算成本
        cost_data = {
            "api_cost": metrics["api_calls"] * 0.001,  # 假设单价
            "token_cost": metrics["token_usage"] * 0.0001,
            "total": 0
        }
        cost_data["total"] = cost_data["api_cost"] + cost_data["token_cost"]
        
        # 创建或更新使用摘要
        summary = UsageSummary(
            tenant_id=tenant_id,
            period_type=period_type,
            period_start=period_start,
            period_end=period_end,
            metrics=metrics,
            cost_data=cost_data
        )
        self.db.add(summary)
        await self.db.commit()
        
        return {
            "period_type": period_type,
            "period_start": period_start.isoformat(),
            "period_end": period_end.isoformat(),
            "metrics": metrics,
            "cost_data": cost_data
        }
    
    async def get_realtime_stats(self, tenant_id: str) -> Dict[str, Any]:
        """获取实时统计"""
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(minutes=5)
        
        # 最近5分钟的请求数
        recent_requests = await self.get_metric_summary(
            "api_calls",
            start_time,
            end_time,
            "count"
        )
        
        # 平均延迟
        latency = await self.get_metric_summary(
            "request_latency_ms",
            start_time,
            end_time,
            "avg"
        )
        
        # 错误率
        errors = await self.get_metric_summary(
            "api_errors",
            start_time,
            end_time,
            "count"
        )
        
        total_requests = recent_requests.get("value", 0)
        error_count = errors.get("value", 0)
        error_rate = (error_count / total_requests * 100) if total_requests > 0 else 0
        
        return {
            "timestamp": end_time.isoformat(),
            "requests_per_minute": total_requests / 5,
            "average_latency_ms": latency.get("value", 0),
            "error_rate_percent": error_rate,
            "total_requests_5m": total_requests,
            "error_count_5m": error_count
        }
