"""
对话相关的Pydantic模型
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


class ChatBase(BaseModel):
    """对话基础模型"""
    title: Optional[str] = "新对话"
    role_id: Optional[str] = None


class ChatCreate(ChatBase):
    """创建对话模型"""
    model: Optional[str] = "gpt-3.5-turbo"
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 2048


class ChatUpdate(BaseModel):
    """更新对话模型"""
    title: Optional[str] = None
    role_id: Optional[str] = None
    tags: Optional[List[str]] = None
    is_starred: Optional[bool] = None
    model: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class ChatResponse(ChatBase):
    """对话响应模型"""
    id: str
    user_id: str
    tags: Optional[List[str]] = []
    is_starred: bool = False
    is_archived: bool = False
    model: str = "gpt-3.5-turbo"
    temperature: float = 0.7
    max_tokens: int = 2048
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class MessageBase(BaseModel):
    """消息基础模型"""
    role: str = Field(..., regex="^(user|assistant|system)$")
    content: str


class MessageCreate(MessageBase):
    """创建消息模型"""
    reasoning: Optional[str] = None
    attachments: Optional[List[Dict[str, Any]]] = None


class MessageResponse(MessageBase):
    """消息响应模型"""
    id: str
    chat_id: str
    reasoning: Optional[str] = None
    tool_results: Optional[List[Dict[str, Any]]] = None
    attachments: Optional[List[Dict[str, Any]]] = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class FavoriteCreate(BaseModel):
    """创建收藏模型"""
    message_id: str
    note: Optional[str] = None


class FavoriteResponse(BaseModel):
    """收藏响应模型"""
    id: str
    user_id: str
    message_id: str
    chat_id: str
    note: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True
