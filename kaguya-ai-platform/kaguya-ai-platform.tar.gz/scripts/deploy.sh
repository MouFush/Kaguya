#!/bin/bash

# Kaguya AI Platform 部署脚本

set -e

echo "🚀 开始部署 Kaguya AI Platform..."

# 检查Docker和Docker Compose
if ! command -v docker &> /dev/null; then
    echo "❌ Docker未安装，请先安装Docker"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose未安装，请先安装Docker Compose"
    exit 1
fi

# 创建环境变量文件（如果不存在）
if [ ! -f .env ]; then
    echo "📝 创建环境变量文件..."
    cat > .env << EOF
# JWT密钥（生产环境请修改）
JWT_SECRET_KEY=your-secret-key-change-in-production

# OpenAI API密钥（可选）
OPENAI_API_KEY=

# DeepSeek API密钥（可选）
DEEPSEEK_API_KEY=
EOF
fi

# 拉取最新代码
echo "📥 拉取最新代码..."
git pull origin main 2>/dev/null || echo "⚠️ 不是git仓库，跳过拉取"

# 构建并启动服务
echo "🔨 构建并启动服务..."
docker-compose down
docker-compose build --no-cache
docker-compose up -d

# 等待服务启动
echo "⏳ 等待服务启动..."
sleep 10

# 检查服务状态
echo "🔍 检查服务状态..."
docker-compose ps

# 显示访问信息
echo ""
echo "✅ 部署完成！"
echo ""
echo "🌐 访问地址:"
echo "   - 前端: http://localhost"
echo "   - 后端API: http://localhost:8000"
echo "   - API文档: http://localhost:8000/api/docs"
echo ""
echo "📊 监控地址:"
echo "   - RabbitMQ管理: http://localhost:15672 (kaguya/kaguya123)"
echo ""
echo "🛠️ 常用命令:"
echo "   - 查看日志: docker-compose logs -f"
echo "   - 停止服务: docker-compose down"
echo "   - 重启服务: docker-compose restart"
echo ""
