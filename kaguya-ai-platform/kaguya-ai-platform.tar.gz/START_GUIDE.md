# Kaguya AI Platform 启动指南

## 项目概述

Kaguya AI Platform 是一个企业级AI对话平台，包含以下9大专业级功能模块：

1. **多租户SaaS架构** - 完整的企业级租户管理
2. **计费与配额系统** - 灵活的订阅和用量计费
3. **插件市场** - 可扩展的插件生态系统
4. **AI工作流引擎** - 可视化流程编排
5. **企业级安全** - 审计日志、SSO、RBAC权限
6. **数据分析平台** - 实时监控和告警
7. **团队协作** - 工作空间、评论、实时协作
8. **模型管理系统** - 模型部署、微调、A/B测试
9. **API开发者平台** - 完整的API生命周期管理

## 技术栈

- **后端**: FastAPI + SQLAlchemy + PostgreSQL + Redis + Milvus
- **前端**: React 18 + TypeScript + Vite + TailwindCSS
- **基础设施**: Docker + Docker Compose

## 快速启动

### 方式一：Docker Compose（推荐）

确保已安装 Docker 和 Docker Compose，然后运行：

```bash
cd kaguya-ai-platform
docker-compose up -d --build
```

服务将启动在：
- 前端: http://localhost
- 后端API: http://localhost:8000
- API文档: http://localhost:8000/api/docs

### 方式二：本地开发环境

#### 1. 安装后端依赖

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

#### 2. 配置环境变量

创建 `.env` 文件：

```env
DATABASE_URL=postgresql+asyncpg://kaguya:kaguya123@localhost:5432/kaguya_ai
REDIS_URL=redis://localhost:6379/0
JWT_SECRET_KEY=your-secret-key-change-in-production
OPENAI_API_KEY=your-openai-api-key
DEEPSEEK_API_KEY=your-deepseek-api-key
```

#### 3. 启动后端服务

```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

#### 4. 安装前端依赖

```bash
cd frontend
npm install
```

#### 5. 启动前端开发服务器

```bash
npm run dev
```

前端将运行在 http://localhost:5173

## 项目结构

```
kaguya-ai-platform/
├── backend/              # FastAPI后端
│   ├── app/
│   │   ├── api/v1/      # API路由
│   │   ├── models/      # 数据库模型
│   │   ├── services/    # 业务服务
│   │   └── main.py      # 应用入口
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/             # React前端
│   ├── src/
│   │   ├── pages/       # 页面组件
│   │   ├── store/       # 状态管理
│   │   └── api/         # API客户端
│   ├── package.json
│   └── Dockerfile
├── infra/               # 基础设施配置
├── docker-compose.yml   # Docker编排
└── README.md
```

## API端点概览

### 基础模块
- `POST /api/v1/auth/login` - 用户登录
- `POST /api/v1/auth/register` - 用户注册
- `GET /api/v1/chats` - 获取对话列表
- `POST /api/v1/messages` - 发送消息

### 企业级功能
- `GET /api/v1/tenants` - 租户管理
- `GET /api/v1/billing/subscriptions` - 订阅管理
- `GET /api/v1/security/audit-logs` - 审计日志
- `GET /api/v1/analytics/metrics` - 数据分析
- `GET /api/v1/collaboration/workspaces` - 工作空间
- `GET /api/v1/models/ai-models` - AI模型管理
- `GET /api/v1/api-platform/products` - API产品

## 开发说明

### 数据库迁移

```bash
cd backend
alembic revision --autogenerate -m "Initial migration"
alembic upgrade head
```

### 运行测试

```bash
cd backend
pytest
```

### 代码规范

- 后端: PEP 8
- 前端: ESLint + Prettier

## 生产部署

1. 修改环境变量为生产配置
2. 使用 HTTPS
3. 配置反向代理（Nginx）
4. 设置监控和日志收集
5. 配置备份策略

## 许可证

MIT License
